onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_paper_uart.sv
vsim -voptargs=+acc -onfinish stop work.tb_paper_uart
view wave
add wave -noupdate -color Green -radix bin sim:/tb_paper_uart/clk
add wave -noupdate -color Green -radix bin sim:/tb_paper_uart/rx
add wave -noupdate -color Green -radix bin sim:/tb_paper_uart/valid
add wave -noupdate -color Green -radix unsigned sim:/tb_paper_uart/seq
add wave -noupdate -color Green -radix signed sim:/tb_paper_uart/goal
add wave -noupdate -color Green -radix unsigned sim:/tb_paper_uart/speed
configure wave -timelineunits us
update
run -all
wave zoom full

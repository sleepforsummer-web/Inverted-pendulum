onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_paper_io.sv
vsim -voptargs=+acc -onfinish stop work.tb_paper_io
view wave
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/clk
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/valid
add wave -noupdate -color Green -radix signed sim:/tb_paper_io/command
add wave -noupdate -color Green -radix signed sim:/tb_paper_io/duty
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/pwm
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/in1
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/in2
configure wave -timelineunits us
update
run -all
wave zoom full

@echo off
cd /d "%~dp0..\sim"
start "" "F:\ModelSim_10.4\win64\vsim.exe" -do "../paper_waves/01_pid.do"

onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_paper_pid.sv
vsim -voptargs=+acc -onfinish stop work.tb_paper_pid
view wave
add wave -noupdate -color Green -radix bin sim:/tb_paper_pid/clk
add wave -noupdate -color Green -radix bin sim:/tb_paper_pid/dut/tick
add wave -noupdate -color Green -radix bin sim:/tb_paper_pid/dut/pos_tick
add wave -noupdate -color Green -radix signed sim:/tb_paper_pid/position
add wave -noupdate -color Green -radix signed sim:/tb_paper_pid/theta
add wave -noupdate -color Green -radix signed sim:/tb_paper_pid/dut/theta_ref
add wave -noupdate -color Green -radix bin sim:/tb_paper_pid/dut/theta_ref_valid
add wave -noupdate -color Green -radix signed sim:/tb_paper_pid/dut/error
add wave -noupdate -color Green -radix bin sim:/tb_paper_pid/dut/pid_valid
add wave -noupdate -color Green -radix signed sim:/tb_paper_pid/dut/duty
configure wave -timelineunits ms
update
run -all
wave zoom full

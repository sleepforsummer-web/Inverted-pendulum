onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_paper_io.sv
vsim -voptargs=+acc -onfinish stop work.tb_paper_io
view wave
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/clk
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/adc_clk
add wave -noupdate -color Green -radix unsigned sim:/tb_paper_io/data
add wave -noupdate -color Green -radix unsigned sim:/tb_paper_io/raw
add wave -noupdate -color Green -radix unsigned sim:/tb_paper_io/filtered
add wave -noupdate -color Green -radix signed sim:/tb_paper_io/theta
add wave -noupdate -color Green -radix bin sim:/tb_paper_io/adc_valid
configure wave -timelineunits us
update
run -all
wave zoom full

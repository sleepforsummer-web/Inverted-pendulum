onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_recovery_target.sv
vsim -voptargs=+acc -onfinish stop work.tb_recovery_target
view wave
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/clk
add wave -noupdate -color Green -radix signed sim:/tb_recovery_target/position
add wave -noupdate -color Green -radix signed sim:/tb_recovery_target/theta
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/dut/running
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/dut/recovery_waiting
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/dut/recovery_anchor_pending
add wave -noupdate -color Green -radix signed sim:/tb_recovery_target/dut/recovery_saved_target
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/dut/recovery_target_ready
add wave -noupdate -color Green -radix signed sim:/tb_recovery_target/dut/position_target_q16
add wave -noupdate -color Green -radix bin sim:/tb_recovery_target/dut/control_enable
configure wave -timelineunits us
update
run -all
wave zoom full

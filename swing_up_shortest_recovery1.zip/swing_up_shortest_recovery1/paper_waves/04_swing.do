onerror {resume}
if {![file exists work]} {vlib work}
eval vlog [glob ../src/*.v]
vlog -sv tb_swing_top.sv
vsim -voptargs=+acc -onfinish stop work.tb_swing_top
view wave
add wave -noupdate -color Green -radix bin sim:/tb_swing_top/clk
add wave -noupdate -color Green -radix bin sim:/tb_swing_top/tick
add wave -noupdate -color Green -radix unsigned sim:/tb_swing_top/adc
add wave -noupdate -color Green -radix unsigned sim:/tb_swing_top/dut/swing_state
add wave -noupdate -color Green -radix bin sim:/tb_swing_top/dut/swing_peak
add wave -noupdate -color Green -radix signed sim:/tb_swing_top/dut/swing_duty
add wave -noupdate -color Green -radix bin sim:/tb_swing_top/dut/pid_enable
add wave -noupdate -color Green -radix signed sim:/tb_swing_top/dut/duty
configure wave -timelineunits us
update
run -all
wave zoom full

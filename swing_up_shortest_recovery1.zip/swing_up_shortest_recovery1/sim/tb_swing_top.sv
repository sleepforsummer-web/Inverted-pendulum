`timescale 1ns/1ps
module tb_swing_top;
 reg clk=0;
 always #10 clk=~clk;
 reg rst_n=0, tick=0;
 reg [2:0] keys=7;
 reg [11:0] adc=3000;
 reg signed [12:0] angle=-1042;
 wire pwm, in1, in2;
 wire signed [16:0] expected_left = dut.LEFT_FIRST_POSITIVE ? dut.SWING_DUTY : -dut.SWING_DUTY;
 wire signed [16:0] expected_seed = dut.START_KICK_POSITIVE ? dut.START_KICK_DUTY : -dut.START_KICK_DUTY;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.AUTO_RECOVER_ENABLE(0)) dut(
  .clk_50m(clk),.rst_n(rst_n),.key_sw({1'b1,keys}),.adc_data_in(10'd750),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(pwm),.AN1(in1),.AN2(in2),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task key1;
  @(negedge clk); keys=6; clocks(12);
  @(negedge clk); keys=7; clocks(12);
 endtask
 task key2;
  @(negedge clk); keys=5; clocks(12);
  @(negedge clk); keys=7; clocks(12);
 endtask
 task ms(input integer n);
  repeat(n) begin
   @(negedge clk); tick=1; clocks(1);
   @(negedge clk); tick=0; clocks(4);
  end
 endtask
 task set_adc(input integer value);
  @(negedge clk); adc=value; angle=dut.UPRIGHT_ADC-value;
 endtask
 task sample(input integer value);
  set_adc(value); ms(dut.SWING_SAMPLE_MS);
 endtask
 initial begin
  // Inject aligned ADC outputs and an accelerated 1ms tick; use real PID/driver.
  force dut.filtered_raw=adc;
  force dut.theta=angle;
  force dut.adc_valid=1'b1;
  force dut.tick=tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12);
  key1();
  if(!dut.running || !dut.enable || dut.pid_enable || dut.in_range)
   $fatal(1,"must start swing-up outside original PID stop range");
  sample(3000); sample(2900); sample(2800);
  if(dut.swing_state!=1 || dut.duty!=0) $fatal(1,"monotonic approach triggered early");
  sample(2900); // Peak at third sample: old non-overlapping groups missed it.
  if(dut.swing_state!=2 || dut.duty!=expected_left || dut.pid_enable)
   $fatal(1,"first pulse failed to reach real PWM driver");
  ms(100);
  if(dut.swing_state!=3 || dut.duty!=-expected_left)
   $fatal(1,"reverse pulse failed signed Q16 conversion");
  // Capture midway through second pulse, without waiting the full100ms.
  sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable || dut.swing_state!=3) $fatal(1,"top captured after first20ms sample");
  sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable || dut.swing_state!=3) $fatal(1,"top captured after second20ms sample");
  set_adc(dut.UPRIGHT_ADC); ms(19);
  if(dut.pid_enable) $fatal(1,"top captured before third20ms sample");
  ms(1);
  if(!dut.pid_enable || dut.swing_state!=4 || dut.duty!=0)
   $fatal(1,"capture failed to clear old pulse and enable PID");
  set_adc(2000); ms(2);
  if(dut.duty==0 || dut.motor_sum!==dut.pid_sum || dut.target_adc!=dut.UPRIGHT_ADC)
   $fatal(1,"PID not connected after capture or upright calibration wrong");
  set_adc(3200); clocks(4);
  if(dut.running || dut.enable || dut.duty!=0 || dut.stop_reason!=3 || dut.stop_theta!=angle)
   $fatal(1,"PID angle stop/latch broken");
  set_adc(dut.UPRIGHT_ADC); ms(3);
  if(dut.running) $fatal(1,"fall must not automatically restart");
  set_adc(1000); key1();
  sample(800); sample(1000); sample(900);
  if(dut.duty!=-expected_left) $fatal(1,"right-region pulse wrong");
  // KEY1 stops even in the middle of an active pulse.
  key1();
  if(dut.running || dut.enable || dut.duty!=0 || dut.stop_reason!=1 || pwm || in1 || in2)
   $fatal(1,"KEY1 did not stop active pulse");
  key1();
  sample(800); sample(1000); sample(900);
  @(negedge clk); keys=6; clocks(16);
  if(dut.running || dut.duty!=0 || dut.stop_reason!=1)
   $fatal(1,"debounced KEY2 did not stop active pulse");
  @(negedge clk); keys=7; clocks(16);
  // Out-of-range KEY2 must not arm automatic mode or PID.
  set_adc(3200); key2();
  if(dut.running || dut.manual_mode || dut.pid_enable || dut.duty!=0)
   $fatal(1,"KEY2 must reject manual start outside PID angle range");
  // A sub-debounce low pulse must not start.
  set_adc(2000);
  @(negedge clk); keys=5; clocks(2);
  @(negedge clk); keys=7; clocks(12);
  if(dut.running) $fatal(1,"KEY2 debounce accepted short glitch");
  // KEY2 directly starts PID outside the automatic +/-300 capture window.
  set_adc(2400); key2();
  if(!dut.running || !dut.manual_mode || !dut.pid_enable || dut.swing_state!=0)
   $fatal(1,"KEY2 must directly enter original manual PID mode");
  ms(3);
  if(dut.duty==0 || dut.motor_sum!==dut.pid_sum || dut.swing_pulse_active)
   $fatal(1,"manual mode did not drive PID exclusively");
  // KEY2现在只负责手动启动，运行时再按必须保持平衡；KEY1仍可主动停机。
  key2();
  if(!dut.running || !dut.manual_mode) $fatal(1,"KEY2 still stops manual PID");
  key1();
  if(dut.running || dut.manual_mode || dut.duty!=0 || dut.stop_reason!=1)
   $fatal(1,"second KEY2 press must stop with reason4");
  set_adc(dut.UPRIGHT_ADC);
  @(negedge clk); keys=5; clocks(12); ms(10);
  if(!dut.running || !dut.manual_mode) $fatal(1,"held KEY2 retriggered stop");
  @(negedge clk); keys=7; clocks(12);
  set_adc(3200); clocks(4);
  if(dut.running || dut.stop_reason!=3 || dut.stop_theta!=angle)
   $fatal(1,"manual PID must retain angle stop and latch");
  set_adc(dut.UPRIGHT_ADC); ms(3);
  if(dut.running) $fatal(1,"manual angle recovery restarted automatically");
  // Both start keys pressed together must stay stopped.
  @(negedge clk); keys=4; clocks(12);
  if(dut.running) $fatal(1,"simultaneous start ambiguity must not start");
  @(negedge clk); keys=7; clocks(12);
  // 自动起摆期间KEY2不切换或停止；KEY1仍可停止脉冲。
  set_adc(3000); key1();
  sample(3000); sample(2800); sample(2900);
  if(dut.manual_mode || dut.duty!=expected_left) $fatal(1,"KEY1 did not restore auto mode");
  key2();
  if(!dut.running || dut.manual_mode) $fatal(1,"KEY2 interfered with automatic swing-up");
  key1();
  if(dut.running || dut.duty!=0 || dut.stop_reason!=1)
   $fatal(1,"KEY2 did not cancel auto pulse");
  // KEY1 bottom startup reaches the real motor with the smaller seed command.
  set_adc(0); key1(); ms(1);
  if(dut.swing_state!=5 || dut.duty!=expected_seed || dut.pid_enable)
   $fatal(1,"initial nudge did not reach PWM driver");
  ms(dut.START_KICK_MS-1); if(dut.duty!=expected_seed) $fatal(1,"top seed first ended early");
  ms(1); if(dut.duty!=-expected_seed || dut.swing_state!=7 || !dut.swing_pulse_active)
   $fatal(1,"top seed reverse failed signed PWM conversion");
  ms(dut.START_KICK_MS-1); if(dut.duty!=-expected_seed) $fatal(1,"top seed reverse ended early");
  ms(1); if(dut.duty!=0 || dut.swing_state!=1) $fatal(1,"top seed pair failed to end");
  ms(160); if(dut.duty!=0 || dut.swing_state!=1) $fatal(1,"nudge repeated without restart");
  key1();
  // Manual mode must bypass the seed controller entirely.
  set_adc(2000); key2(); ms(60);
  if(!dut.manual_mode || dut.swing_state!=0 || dut.swing_pulse_active)
   $fatal(1,"KEY2 manual mode must bypass startup nudge");
  key1();
  set_adc(4092); key1(); ms(1);
  if(dut.duty!=expected_seed) $fatal(1,"high endpoint did not nudge");
  ms(dut.START_KICK_MS);
  if(dut.duty!=-expected_seed || dut.swing_state!=7) $fatal(1,"top high endpoint reverse");
  key2();
  if(!dut.running) $fatal(1,"KEY2 stopped initial kick");
  key1();
  if(dut.running || dut.duty!=0 || dut.stop_reason!=1)
   $fatal(1,"KEY2 must stop startup nudge too");
  // 初始第一段、最高点第一段也必须满足连续三个20ms采样点，捕获后撤销旧脉冲。
  set_adc(0); key1(); ms(1);
  sample(dut.UPRIGHT_ADC); sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable || dut.swing_state!=5) $fatal(1,"seed first capture too early");
  sample(dut.UPRIGHT_ADC);
  if(!dut.pid_enable || dut.swing_state!=4 || dut.duty!=0) $fatal(1,"seed first capture failed");
  key1();
  set_adc(3000); key1(); sample(3000); sample(2800); sample(2900);
  sample(dut.UPRIGHT_ADC); sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable || dut.swing_state!=2) $fatal(1,"peak first capture too early");
  sample(dut.UPRIGHT_ADC);
  if(!dut.pid_enable || dut.swing_state!=4 || dut.duty!=0) $fatal(1,"peak first capture failed");
  key1();
  // 出区与停机均清除累计次数，不把上次运行的两点带到下一次启动。
  set_adc(dut.UPRIGHT_ADC); key1(); sample(dut.UPRIGHT_ADC); sample(dut.UPRIGHT_ADC); sample(2259);
  sample(dut.UPRIGHT_ADC); sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable) $fatal(1,"top exit did not reset count");
  key1(); key1(); sample(dut.UPRIGHT_ADC); sample(dut.UPRIGHT_ADC);
  if(dut.pid_enable) $fatal(1,"top restart retained capture count");
  sample(dut.UPRIGHT_ADC);
  if(!dut.pid_enable) $fatal(1,"top third consecutive sample failed capture");
  $display("PASS top: three consecutive20ms capture samples, first/reverse pulse preemption, exit/restart reset, KEY1/KEY2/KEY2 and real PID/PWM regression");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

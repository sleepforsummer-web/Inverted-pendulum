`timescale 1ns/1ps
module tb_paper_io;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,valid=0; reg [9:0] data=490;
 reg signed [50:0] command=0;
 wire adc_clk,adc_valid,pwm,in1,in2;
 wire [11:0] raw,filtered; wire signed [12:0] theta; wire signed [16:0] duty;
 adc_v2 #(.OFFSET(1960),.INVERT(1)) adc(.clk_50m(clk),.rst_n(rst_n),.adc_data_in(data),
  .adc_clk(adc_clk),.adc_oe_n(),.adc_stby_n(),.theta_raw(raw),.theta_filtered(filtered),
  .theta(theta),.data_valid(adc_valid),.block_min(),.block_max(),.block_sum(),.block_count());
 motor_pwm #(.FALL_THRESH(1000),.MOTOR_SIGN(1)) motor(.clk(clk),.rst_n(rst_n),.enable(1'b1),
  .theta(13'sd0),.pid_sum(command),.pid_valid(valid),.pwm_out(pwm),.in1(in1),.in2(in2),.duty_out(duty));
 initial begin
  #100; rst_n=1; #100; command=51'sd32768000; valid=1; #20; valid=0;
  #80000; data=470;
  #40000; command=-51'sd32768000;valid=1; #20;valid=0;
  #80000; if(duty!=-500 || filtered>=1960) $fatal(1,"ADC or PWM response wrong");
  $display("PASS paper ADC and PWM"); $finish;
 end
endmodule

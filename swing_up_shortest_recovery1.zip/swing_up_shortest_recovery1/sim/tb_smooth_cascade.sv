`timescale 1ns/1ps
module tb_smooth_cascade;
    reg clk=0;
    always #10 clk=~clk;
    reg rst=1, enable=0, tick=0, pos_tick=0;
    reg signed [16:0] actual=1958, position=0;
    wire signed [16:0] angle_ref, error;
    wire signed [16:0] target=17'sd1958-angle_ref;
    wire signed [50:0] sum;
    wire valid, ref_valid, limited;
    wire signed [15:0] pm, im, dm;
    wire signed [31:0] opm, odm;
    pid_adc_controller #(.KP_Q(32'sd406323),.KI_Q(0),.KD_Q(32'sd6029312),
        .D_FILTER_SHIFT(3),.ERROR_INPUT_LIMIT(17'sd100)) inner(
        .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),
        .target_adc(target),.actual_adc(actual),.error_out(error),
        .pid_sum(sum),.pid_valid(valid),.p_mon(pm),.i_mon(im),.d_mon(dm));
    position_controller #(.Kp_pos(32'sd15729),.Kd_pos(32'sd557056),
        .D_FILTER_SHIFT(1)) outer(
        .clk(clk),.rst(rst),.enable(enable),.sample_tick(pos_tick),
        .position_error(position),.position_error_q16(33'sd0),.position_measurement(17'sd0),.integral_clear(1'b0),.motion_active(1'b0),.i_pos_mon(),
        .theta_ref(angle_ref),.theta_ref_valid(ref_valid),
        .p_pos_mon(opm),.d_pos_mon(odm),.limited_mon(limited),
        .active_limit_mon(),.boost_active_mon());

    longint q=0, oq=0, prev=0, oprev=0, expected_ref=0;
    longint e, ep, p, d, total, op, od, r, qpm, qdm;
    integer n, sample_n=0;
    bit have=0, ohave=0, outer_now;
    function automatic longint smooth(input longint state, delta, input integer shift);
        longint diff, mag, correction;
        begin
            if(delta==0 && state>-(1<<shift) && state<(1<<shift)) smooth=0;
            else begin
                diff=delta*256-state;
                mag=diff<0 ? -diff : diff;
                correction=(mag+(1<<(shift-1))) >>> shift;
                smooth=state+(diff<0 ? -correction : correction);
            end
        end
    endfunction
    function automatic longint monitor(input longint value);
        begin
            if(value>134217728) monitor=32767;
            else if(value < -134217728) monitor=-32768;
            else monitor=value >>> 12;
        end
    endfunction
    task clocks(input integer count);
        repeat(count) begin @(posedge clk); #2; end
    endtask
    task reset_control;
        @(negedge clk); enable=0; tick=0; pos_tick=0;
        clocks(4);
        if(sum!==0 || angle_ref!==0 || valid || ref_valid || pm || dm || opm || odm)
            $fatal(1,"stop failed to clear pipeline/monitors");
        q=0; oq=0; have=0; ohave=0; expected_ref=0;
        @(negedge clk); enable=1;
    endtask
    task sample_control(input integer adc, pos, input bit outer_sample);
        begin
            @(negedge clk); actual=adc; position=pos; tick=1; pos_tick=outer_sample;
            // 与MATLAB一致：内外环同拍时，内环读取更新前的外环目标。
            e=adc-1958+expected_ref;
            ep=e>100 ? 100 : e < -100 ? -100 : e;
            p=ep*406323;
            if(have) q=smooth(q,adc-prev,3); else q=0;
            d=(q*6029312) >>> 8;
            prev=adc; have=1;
            total=p+d;
            if(total>65536000) total=65536000;
            if(total < -65536000) total=-65536000;
            if(outer_sample) begin
                op=pos*64'sd15729;
                if(ohave) oq=smooth(oq,pos-oprev,1); else oq=0;
                od=(oq*557056) >>> 8;
                oprev=pos; ohave=1;
                r=(op+od) >>> 16;
                expected_ref=r>40 ? 40 : r < -40 ? -40 : r;
            end
            clocks(1);
            if(valid || ref_valid) $fatal(1,"output valid before pipeline completed");
            @(negedge clk); tick=0; pos_tick=0;
            clocks(3);
            if(!valid || sum!==total || pm!==monitor(p) || im!==0 || dm!==monitor(d))
                $fatal(1,"inner sample=%0d sum=%0d/%0d P=%0d D=%0d/%0d",sample_n,sum,total,pm,dm,monitor(d));
            clocks(1); // 外环为积分输入换算新增1个50MHz寄存级，内环延迟不变。
            if(angle_ref!==expected_ref || ref_valid!==outer_sample)
                $fatal(1,"outer sample=%0d angle_ref=%0d/%0d valid=%0d",sample_n,angle_ref,expected_ref,ref_valid);
            if(outer_sample && (opm!==(op >>> 8) || odm!==(od >>> 8) || limited!==((r>40)||(r < -40))))
                $fatal(1,"outer monitor or limit mismatch");
            clocks(2);
            if(valid || ref_valid) $fatal(1,"valid must be one clock pulse");
            sample_n=sample_n+1;
        end
    endtask
    initial begin
        clocks(3); @(negedge clk); rst=0;
        reset_control();
        // 实际角度恒定，只改变外环目标，内环D必须保持0。
        for(n=0;n<30;n=n+1) sample_control(1958,n<15 ? n*30 : -n*30,1);
        if(dm!==0) $fatal(1,"target step leaked into inner D");
        reset_control();
        // 正负摆角、P误差限幅、总输出限幅、外环10:1节拍和停机重启。
        for(n=0;n<1000;n=n+1) begin
            if(n==500) reset_control();
            sample_control(1958+((n*29)%401)-200,((n*17)%1201)-600,(n%10)==0);
        end
        reset_control();
        sample_control(1958,0,1);
        if(dm || odm) $fatal(1,"first sample derivative must be zero");
        // 停在差分/滤波之间，不得在重启后吐出旧D指令。
        @(negedge clk); actual=2058; tick=1;
        clocks(1); reset_control();
        sample_control(1958,0,1);
        if(sum || dm) $fatal(1,"pending old D survived disable");
        $display("PASS cascade: %0d samples, target-independent D, paired P/I/D, limits, 10:1 ticks, monitors and restart",sample_n);
        $finish;
    end
    initial begin #1000000; $fatal(1,"timeout"); end
endmodule

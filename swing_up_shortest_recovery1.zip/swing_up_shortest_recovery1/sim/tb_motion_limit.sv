`timescale 1ns/1ps
// 运动期间无论误差/旧计时如何均为40；完成后从零开始恢复原AND规则。
module motion_limit_case #(parameter integer SHIFT=0, FAR=110)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1, enable=0, tick=0, moving=0;
 reg signed [16:0] pos=0;
 wire signed [16:0] target, cap;
 wire valid,boosted,limited;
 position_controller #(.Kp_pos(131072),.Kd_pos(0),.D_FILTER_SHIFT(SHIFT),
  .LIMIT_SWITCH_ENABLE(1),.THETA_REF_BOOST_MAX(FAR)) dut(
  .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),.position_error(pos),
  .position_error_q16(33'sd0),.position_measurement(17'sd0),.integral_clear(1'b0),
  .motion_active(moving),.theta_ref(target),.theta_ref_valid(valid),
  .p_pos_mon(),.d_pos_mon(),.i_pos_mon(),.limited_mon(limited),
  .active_limit_mon(cap),.boost_active_mon(boosted));
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 integer demand,expected;
 task sample(input integer value, move, limit_value, boost);
  @(negedge clk); pos=value; moving=move; tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(8);
  demand=2*value;
  expected=demand>limit_value ? limit_value : demand < -limit_value ? -limit_value : demand;
  if(cap!==limit_value || boosted!==boost || target!==expected)
   $fatal(1,"shift%0d far%0d pos%0d moving%0d cap%0d/%0d boost%0d/%0d target%0d/%0d",
    SHIFT,FAR,value,move,cap,limit_value,boosted,boost,target,expected);
  if(move && (dut.boost_mode || dut.boost_elapsed_ticks)) $fatal(1,"motion retained boost/timer");
 endtask
 integer n;
 initial begin
  clocks(3); @(negedge clk); rst=0; enable=1;
  sample(100,0,FAR,1);
  repeat(20) sample(0,0,FAR,1);
  // 原大限幅尚未满1秒时，运动优先进入小限幅。
  sample(100,1,40,0);
  for(n=0;n<150;n=n+1) sample(n%2 ? -100 : 100,1,40,0);
  sample(0,0,40,0); // 完成时误差在区内，不继承旧大限幅
  sample(-51,0,FAR,1);
  for(n=1;n<100;n=n+1) sample(0,0,FAR,1);
  sample(0,0,40,0); // 满1秒且回区内才退出
  sample(100,0,FAR,1);
  repeat(130) sample(100,0,FAR,1); // 超时仍在区外继续大限幅
  sample(-100,1,40,0);
  sample(-100,0,FAR,1); // 完成时仍在区外，立即重新进入大限幅、计时从零开始
  if(dut.boost_elapsed_ticks) $fatal(1,"finished motion inherited elapsed time");
  for(n=1;n<100;n=n+1) sample(-50,0,FAR,1);
  sample(-50,0,40,0);
  sample(100,1,40,0);
  @(negedge clk); enable=0; clocks(5);
  if(target || valid || boosted || cap!=40 || dut.boost_elapsed_ticks) $fatal(1,"disable failed");
  @(negedge clk); enable=1; moving=0;
  sample(0,0,40,0);
  @(negedge clk); rst=1; clocks(5);
  if(target || valid || boosted || cap!=40) $fatal(1,"reset failed");
  done=1;
 end
endmodule
module tb_motion_limit;
 wire a,b,c;
 motion_limit_case #(.SHIFT(0)) direct_case(a);
 motion_limit_case #(.SHIFT(1)) filtered_case(b);
 motion_limit_case #(.SHIFT(1),.FAR(40)) equal_limits_case(c);
 initial begin wait(a && b && c);
  $display("PASS motion limit: forced40, old boost cleared, both signs, >1s motion, exact fresh1s AND exit, timeout outside, equal limits, reset/disable");
  $finish;
 end
 initial begin #2000000; $fatal(1,"timeout"); end
endmodule

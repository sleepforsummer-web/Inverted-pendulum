onerror {quit -code 1}
onbreak {quit -code 1}
if {![file exists work]} {vlib work}
if {![info exists source_dir]} {set source_dir ../src}
vlog $source_dir/disturbance_limit.v
vlog $source_dir/uart_target_rx.v $source_dir/serial_position.v
vlog $source_dir/swing_up.v $source_dir/PID.v $source_dir/adc_v2.v $source_dir/encoder.v $source_dir/motor_pwm.v $source_dir/pid_trial.v
vlog $source_dir/key_press.v $source_dir/move90.v
vlog $source_dir/sine_motion.v
vlog $source_dir/auto_recover.v
vlog $source_dir/shortest_recovery.v
vlog -sv tb_d_filter.sv tb_swing_up.sv tb_swing_top.sv tb_smooth_cascade.sv
vlog -sv tb_timed_limit.sv tb_timed_limit_top.sv
vlog -sv tb_move90.sv tb_move90_top.sv tb_motion_pd.sv
vlog -sv tb_move90_parameters.sv
vlog -sv tb_outer_integral.sv tb_outer_integral_top.sv
vlog -sv tb_auto_recover.sv tb_auto_recover_top.sv
vlog -sv tb_recovery_target.sv tb_motion_load.sv
vlog -sv tb_shortest_recovery.sv
vlog -sv tb_uart_outer_i.sv
vlog -sv tb_motion_limit.sv
vlog -sv tb_motion_limit_top.sv
vlog -sv tb_motion_arrival_top.sv
vlog -sv tb_disturbance_limit.sv
vlog -sv tb_startup150_once.sv tb_startup150_top.sv
vlog sine_reference_original.v
vlog -sv tb_sine_equivalence.sv tb_sine_keys_top.sv
vlog -sv tb_uart_target_rx.sv tb_serial_position.sv tb_serial_target_top.sv
quit -code 0

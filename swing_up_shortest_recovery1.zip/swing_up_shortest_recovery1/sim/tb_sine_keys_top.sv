`timescale 1ns/1ps
module tb_sine_keys_top;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,ptick=0,mtick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=0;
 reg signed [15:0] speed=0;
 reg signed [12:0] theta=0;
 reg [11:0] adc=1957;
 wire pwm,in1,in2;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.KEY4_LONG_CYCLES(40),.AUTO_RECOVER_ENABLE(0)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),.PWMA(pwm),.AN1(in1),.AN2(in2),
  .PWMB(),.BN1(),.BN2());
 defparam dut.sine_path.PERIOD_TICKS=100;
 defparam dut.motion.MOVE_TICKS=4;
 task clocks(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
 task press(input integer index);
  @(negedge clk);keys=15^(1<<index);clocks(12);@(negedge clk);keys=15;clocks(12);
 endtask
 task sample;
  @(negedge clk);ptick=1;clocks(1);@(negedge clk);ptick=0;clocks(40);
 endtask
 task start_manual;
  @(negedge clk);theta=0;adc=dut.UPRIGHT_ADC;speed=0;press(1);sample();
  if(!dut.running || !dut.manual_mode || !dut.control_enable) $fatal(1,"KEY2 manual start failed");
 endtask
 integer n;
 longint base,max_offset,offset;
 initial begin
  force dut.position=pos;force dut.speed=speed;force dut.theta=theta;force dut.filtered_raw=adc;
  force dut.adc_valid=1'b1;force dut.pos_tick=ptick;force dut.tick=mtick;
  clocks(3);@(negedge clk);rst_n=1;clocks(12);
  press(2);sample();press(3);sample();
  if(dut.running || dut.sine_busy || dut.motion_busy) $fatal(1,"motion key started stopped hardware");
  @(negedge clk);theta=1500;adc=457;press(1);
  if(dut.running) $fatal(1,"out-of-range manual start accepted");
  start_manual();
  // KEY2已不具备运行中停机/切换模式功能，长按也不会停止平衡。
  @(negedge clk);keys=13;clocks(40);sample();
  if(!dut.running || !dut.manual_mode) $fatal(1,"KEY2 still stops running system");
  @(negedge clk);keys=15;clocks(12);
  theta=101;press(2);sample();
  if(!dut.sine_request_rejected || dut.sine_busy || !dut.running) $fatal(1,"sine angle guard failed");
  theta=0;speed=4;press(2);sample();
  if(!dut.sine_request_rejected || dut.sine_busy) $fatal(1,"sine speed guard failed");
  speed=0;
  // 保留KEY4单次运动；运动过程中KEY3不能抢占或排队。
  press(3);sample();
  if(dut.key4_center_offset != -20 || dut.target_adc + dut.theta_ref != 1960) $fatal(1,"forward center wrong off=%d target=%d ref=%d active=%b limit=%b",dut.key4_center_offset,dut.target_adc,dut.theta_ref,dut.key4_center_active,dut.motion_limit_active);
  press(2);repeat(3)sample();
  if(dut.key4_center_offset != -20) $fatal(1,"forward center lost before arrival");
  base=dut.motion.STEP_COUNTS*64'sd65536;
  if(dut.position_target_q16!=base || dut.sine_busy || dut.single_busy) $fatal(1,"KEY4 target or sine interlock wrong");
  @(negedge clk);pos=dut.motion.STEP_COUNTS;sample();
  if(dut.motion_limit_active || dut.key4_center_offset != 0 || dut.target_adc + dut.theta_ref != 1980) $fatal(1,"single motion arrival did not restore center");
  // 在KEY4终点周围启动正弦，不能突然跳回全局零点。
  press(2);
  if(!dut.sine_busy || dut.position_target_q16!=base || !dut.running) $fatal(1,"sine start anchor changed");
  repeat(20)sample();
  press(2);
  if(dut.sine_busy || dut.position_target_q16!=base || !dut.running) $fatal(1,"fade-in stop not immediate");
  sample();press(2);
  if(!dut.sine_busy) $fatal(1,"sine restart after immediate stop failed");
  max_offset=0;
  for(n=0;n<220;n=n+1)begin
   sample();offset=dut.position_target_q16-base;if(offset<0)offset=-offset;
   if(offset>max_offset)max_offset=offset;
   if(dut.outer_active_limit!=40 || !dut.motion_limit_active || !dut.running) $fatal(1,"sine lost balance/small-limit override");
  end
  if(dut.sine_state!=2 || max_offset<dut.sine_path.AMPLITUDE_Q16*99/100 || max_offset>dut.sine_path.AMPLITUDE_Q16)
   $fatal(1,"sine amplitude/steady state wrong");
  press(3);sample();
  if(dut.single_busy || dut.motion.pending_start || dut.motion.target_q16!=base) $fatal(1,"KEY4 interfered with sine");
  press(1);sample();if(!dut.running || !dut.sine_busy) $fatal(1,"KEY2 stopped sine balance");
  @(negedge clk);pos=dut.motion.STEP_COUNTS+100;
  press(2);
  if(dut.sine_busy || dut.position_target_q16!=base || !dut.running || !dut.motion_limit_active)
   $fatal(1,"immediate stop failed to restore center or retain arrival limit");
  repeat(5)sample();
  if(dut.position_target_q16!=base || !dut.motion_limit_active) $fatal(1,"stale sine pipeline or early limit release");
  @(negedge clk);pos=dut.motion.STEP_COUNTS;sample();
  if(dut.motion_limit_active) $fatal(1,"limit did not release after actual arrival");
  // 再次KEY4必须从正弦中心接续，不能丢失累计位置。
  press(3);repeat(4)sample();
  if(dut.position_target_q16!=2*base) $fatal(1,"KEY4 after sine used stale origin");
  @(negedge clk);pos=2*dut.motion.STEP_COUNTS;sample();
  // Long KEY4 reverses exactly one turn, without a preceding forward turn.
  @(negedge clk);keys=7;clocks(20);
  if(dut.single_busy || dut.motion.pending_start || dut.position_target_q16!=2*base)
   $fatal(1,"KEY4 moved before short/long decision");
  clocks(40);sample();
  if(dut.key4_center_offset != 20 || dut.target_adc + dut.theta_ref != 2000) $fatal(1,"reverse center wrong");
  repeat(3)sample();
  if(dut.key4_center_offset != 20) $fatal(1,"reverse center lost before arrival");
  if(dut.position_target_q16!=base || dut.single_busy)
   $fatal(1,"long KEY4 failed reverse one revolution");
  repeat(6)sample();
  if(dut.position_target_q16!=base) $fatal(1,"held long KEY4 repeated");
  @(negedge clk);keys=15;clocks(12);repeat(4)sample();
  if(dut.position_target_q16!=base) $fatal(1,"long release also triggered short");
  @(negedge clk);pos=dut.motion.STEP_COUNTS;sample();
  if(dut.key4_center_offset != 0 || dut.target_adc + dut.theta_ref != 1980) $fatal(1,"reverse arrival failed to restore center");
  @(negedge clk);keys=3;clocks(12);@(negedge clk);keys=15;clocks(12);sample();
  if(dut.sine_busy || dut.single_busy) $fatal(1,"simultaneous KEY3/4 selected conflicting trajectories");
  press(2);repeat(20)sample();
  // KEY5是现有rst_n，异步撤销PWM并清除全部模式/目标；松开不自动重启。
  @(negedge clk);rst_n=0;#2;
  if(dut.running || pwm || in1 || in2 || dut.duty || dut.sine_busy || dut.single_busy || dut.position_target_q16)
   $fatal(1,"KEY5 failed immediate stop/reset");
  clocks(5);keys=9;rst_n=1;clocks(30); // KEY2/3复位期间一直按住，不能自动启动
  if(dut.running || dut.motion_busy) $fatal(1,"held keys restarted after reset");
  @(negedge clk);keys=15;pos=0;clocks(12);start_manual();press(2);repeat(15)sample();
  @(negedge clk);theta=1500;adc=457;clocks(8);
  if(dut.running || dut.motion_busy || dut.position_target_q16 || dut.duty || dut.stop_reason!=3)
   $fatal(1,"angle protection failed in sine mode");
  start_manual();sample();if(dut.sine_busy) $fatal(1,"fault retained sine request");
  press(0);if(dut.running) $fatal(1,"KEY1 explicit stop no longer works");
  $display("PASS sine/key integration: immediate KEY3 return in fade-in and run, pipeline flush, arrival gating, KEY4 interlock, reset and angle protection");$finish;
 end
 initial begin #20000000;$fatal(1,"timeout");end
endmodule


`timescale 1ns/1ps
module tb_auto_recover_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,pos_tick=0,ms_tick=0;
 reg [3:0] keys=15;
 reg signed [15:0] speed=0;
 reg signed [16:0] position=0;
 reg signed [12:0] theta=0;
 reg [11:0] adc=1954;
 wire pwm,in1,in2;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.RECOVER_SPEED_MAX(1),.RECOVER_LOW_SAMPLES(3)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(pwm),.AN1(in1),.AN2(in2),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task press(input integer index);
  @(negedge clk); keys=15^(1<<index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 task velocity_sample(input integer value);
  @(negedge clk); speed=value; pos_tick=1; clocks(1);
  @(negedge clk); pos_tick=0; clocks(6);
 endtask
 task ms(input integer n);
  repeat(n) begin
   @(negedge clk); ms_tick=1; clocks(1);
   @(negedge clk); ms_tick=0; clocks(5);
  end
 endtask
 task fall;
  @(negedge clk); theta=1954; adc=0; speed=5; clocks(5);
  if(dut.running || dut.enable || dut.pid_enable || !dut.recovery_waiting ||
     dut.stop_reason!=3 || dut.duty || pwm || in1 || in2 ||
     dut.outer_i_mon || dut.position_target_q16 || dut.motion_busy)
   $fatal(1,"fall did not stop driver/clear control state and arm recovery");
 endtask
 task manual_start;
  @(negedge clk); theta=0; adc=dut.UPRIGHT_ADC; speed=0;
  press(1);
  if(!dut.running || !dut.manual_mode || !dut.pid_enable) $fatal(1,"manual start failed");
 endtask
 integer n,key_index;
 initial begin
  force dut.position=position; force dut.speed=speed;
  force dut.theta=theta; force dut.filtered_raw=adc;
  force dut.adc_valid=1'b1; force dut.pos_tick=pos_tick; force dut.tick=ms_tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12);
  repeat(5) velocity_sample(0);
  if(dut.running || dut.recovery_waiting) $fatal(1,"power-up restarted automatically");
  manual_start();
  press(3); velocity_sample(0);
  if(!dut.motion_busy) $fatal(1,"motion did not start before fault test");
  fall();
  repeat(5) velocity_sample(5);
  if(dut.running) $fatal(1,"restarted while arm fast");
  velocity_sample(1); velocity_sample(-1);
  if(dut.running) $fatal(1,"not enough consecutive low samples");
  velocity_sample(2); velocity_sample(0); velocity_sample(0);
  if(dut.running) $fatal(1,"high speed failed to reset qualifying count");
  velocity_sample(0); clocks(5);
  if(!dut.running || dut.manual_mode || dut.pid_enable || dut.stop_reason || dut.motion_busy)
   $fatal(1,"qualified recovery did not enter auto swing with fresh control state");
  ms(1);
  if(!dut.swing_pulse_active || dut.duty==0) $fatal(1,"recovery never reached real swing PWM path");
  @(negedge clk); adc=dut.UPRIGHT_ADC; theta=0; ms(60);
  if(!dut.pid_enable || !dut.running || dut.recovery_waiting || dut.position_target_q16)
   $fatal(1,"recovered swing did not capture back into PID/zero target");
  // KEY1/KEY2在等待中取消恢复；KEY3仅是运动请求，不取消恢复也不排队。
  for(key_index=0;key_index<2;key_index=key_index+1) begin
   fall(); press(key_index);
   if(dut.running || dut.recovery_waiting || dut.recovery_restart)
    $fatal(1,"waiting cancellation failed for key %0d",key_index+1);
   repeat(5) velocity_sample(0);
   if(dut.running) $fatal(1,"canceled recovery restarted later");
   manual_start();
  end
  fall();press(2);
  if(dut.running || !dut.recovery_waiting || dut.sine_busy) $fatal(1,"KEY3 queued motion/canceled recovery while waiting");
  press(0);manual_start();
  // 主动停机不进入恢复；即使theta随后越界，也不应偷偷重新起摆。
  press(0); @(negedge clk); theta=1954; adc=0; clocks(5);
  repeat(5) velocity_sample(0);
  if(dut.running || dut.recovery_waiting) $fatal(1,"manual stop armed recovery");
  manual_start(); fall(); @(negedge clk); rst_n=0; clocks(4);
  if(dut.running || dut.recovery_waiting || dut.duty) $fatal(1,"reset failed during waiting");
  $display("PASS recovery top: fall PWM/I/motion reset, speed gate, actual swing/capture, manual cancellation and explicit-stop interlocks");
  $finish;
 end
 initial begin #2000000; $fatal(1,"timeout"); end
endmodule

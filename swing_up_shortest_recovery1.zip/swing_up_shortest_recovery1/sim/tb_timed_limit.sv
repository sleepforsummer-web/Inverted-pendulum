`timescale 1ns/1ps
// 以一次采样代表实际外环的10ms；同时检查未滤波和已滤波的流水线。
module timed_limit_case #(parameter integer SHIFT=0, SWITCH=1)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1, enable=0, tick=0;
 reg signed [16:0] pos=0;
 wire signed [16:0] target, cap;
 wire valid, limited, boosted;
 wire signed [31:0] pm, dm;
 position_controller #(.Kp_pos(131072),.Kd_pos(0),.D_FILTER_SHIFT(SHIFT),
  .LIMIT_SWITCH_ENABLE(SWITCH)) dut(
  .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),.position_error(pos),
  .position_error_q16(33'sd0),.position_measurement(17'sd0),.integral_clear(1'b0),.motion_active(1'b0),.i_pos_mon(),
  .theta_ref(target),.theta_ref_valid(valid),.p_pos_mon(pm),.d_pos_mon(dm),
  .limited_mon(limited),.active_limit_mon(cap),.boost_active_mon(boosted));
 integer n, reads=0, writes=0;
 integer expected_pos[0:4095], expected_cap[0:4095];
 integer demand, expected_target;
 // 输出检查队列能发现限幅状态与P/D流水线错拍，包括连续有效采样。
 always @(posedge clk) begin
  #2;
  if(enable && valid) begin
   if(reads>=writes) $fatal(1,"unexpected output");
   demand=2*expected_pos[reads];
   expected_target=demand>expected_cap[reads] ? expected_cap[reads] :
      demand < -expected_cap[reads] ? -expected_cap[reads] : demand;
   if(cap!==expected_cap[reads] || target!==expected_target ||
      boosted!==(SWITCH && expected_cap[reads]==80) ||
      limited!==((demand>expected_cap[reads])||(demand < -expected_cap[reads])) ||
      pm!==demand*256 || dm!==0)
    $fatal(1,"shift=%0d switch=%0d sample=%0d pos=%0d cap=%0d/%0d target=%0d/%0d",
     SHIFT,SWITCH,reads,expected_pos[reads],cap,expected_cap[reads],target,expected_target);
   reads=reads+1;
  end
 end
 task clocks(input integer count);
  repeat(count) begin @(posedge clk); #3; end
 endtask
 task sample(input integer value, limit_value, gap);
  @(negedge clk);
  pos=value; tick=1;
  expected_pos[writes]=value; expected_cap[writes]=SWITCH ? limit_value : 40;
  writes=writes+1;
  clocks(1);
  if(gap>0) begin @(negedge clk); tick=0; clocks(gap); end
 endtask
 task drain;
  @(negedge clk); tick=0; clocks(8);
  if(reads!=writes) $fatal(1,"missing output");
 endtask
 task disable_control;
  drain(); @(negedge clk); enable=0; clocks(4);
  if(target || valid || boosted || cap!=40 || dut.boost_elapsed_ticks || dut.boost_mode)
   $fatal(1,"disable retained boost history");
  @(negedge clk); enable=1;
 endtask
 initial begin
  clocks(3); @(negedge clk); rst=0; enable=1;
  sample(50,40,6); sample(-50,40,6);
  // 进入后提前回到区间内，不足1秒仍为80；第100个后续节拍才允许40。
  sample(51,80,6);
  for(n=1;n<100;n=n+1) sample(50,80,6);
  sample(50,40,6);
  // 已超时但仍在区间外：必须继续80；误差变号或出入区均不重置计时。
  sample(-51,80,6);
  for(n=1;n<=150;n=n+1) sample(n%2 ? -60 : 60,80,0);
  sample(-50,40,0); sample(51,80,0);
  for(n=1;n<100;n=n+1) sample(n%2 ? 0 : -60,80,0);
  sample(0,40,0); drain();
  // 负向最大误差无绝对值溢出；中途停机和复位均清除已完成的计时。
  sample(-65536,80,6); disable_control();
  sample(0,40,6); sample(51,80,6);
  for(n=1;n<20;n=n+1) sample(51,80,0);
  drain(); @(negedge clk); rst=1; clocks(4);
  if(boosted || cap!=40 || dut.boost_mode || dut.boost_elapsed_ticks)
   $fatal(1,"reset retained boost history");
  @(negedge clk); rst=0;
  sample(50,40,6); sample(65535,80,6); disable_control();
  sample(0,40,6); drain();
  done=1;
 end
endmodule

module tb_timed_limit;
 wire a,b,c;
 timed_limit_case #(.SHIFT(0)) direct_case(a);
 timed_limit_case #(.SHIFT(1)) filtered_case(b);
 timed_limit_case #(.SHIFT(1),.SWITCH(0)) fixed_case(c);
 initial begin
  wait(a && b && c);
  $display("PASS timed limit: AND exit, exact 1s, inclusive +/-50, long timeout outside, re-entry, signs, reset and pipeline alignment");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

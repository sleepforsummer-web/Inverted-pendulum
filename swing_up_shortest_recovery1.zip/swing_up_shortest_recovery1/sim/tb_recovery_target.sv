`timescale 1ns/1ps
module tb_recovery_target;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,pos_tick=0,ms_tick=0;
 reg [3:0] keys=15;
 reg signed [15:0] speed=0;
 reg signed [16:0] position=0;
 reg signed [12:0] theta=0;
 reg [11:0] adc=1954;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.RECOVER_SPEED_MAX(1),.RECOVER_LOW_SAMPLES(2)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task press(input integer key_index);
  @(negedge clk); keys=15^(1<<key_index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 task outer_sample;
  @(negedge clk); pos_tick=1; clocks(1);
  @(negedge clk); pos_tick=0; clocks(8);
 endtask
 task ms(input integer n);
  repeat(n) begin
   @(negedge clk); ms_tick=1; clocks(1);
   @(negedge clk); ms_tick=0; clocks(5);
  end
 endtask
 task recover_to(input integer start_position, capture_position, expected_target);
  @(negedge clk); position=start_position; theta=1954; adc=0; speed=5; clocks(5);
  if(dut.running || !dut.recovery_waiting || dut.position_target_q16)
   $fatal(1,"fault did not clear previous motion target");
  @(negedge clk); speed=0; outer_sample(); outer_sample(); clocks(5);
  if(!dut.running || !dut.recovery_anchor_pending || dut.control_enable)
   $fatal(1,"recovery did not arm target anchor while swing-up active");
  ms(1);
  // 起摆过程继续改变旋臂位置，新目标必须在捕获时取值，不能提前锁存旧位置。
  @(negedge clk); position=capture_position; theta=0; adc=dut.UPRIGHT_ADC;
  ms(58); // 加上前面的1ms，当前采样相位到59ms，尚未到第三次中心采样。
  if(dut.control_enable) $fatal(1,"capture confirmed before third20ms sample");
  @(negedge clk); ms_tick=1; clocks(1);
  if(!dut.pid_enable || dut.control_enable || dut.recovery_load_target)
   $fatal(1,"first PID clock not gated before new target load");
  // 故意使外环/内环节拍与装载目标同拍；不能先用旧零点计算一组PID。
  @(negedge clk); ms_tick=0; pos_tick=1; clocks(1);
  if(dut.control_enable) $fatal(1,"control enabled before nearest target ready");
  @(negedge clk); pos_tick=0; clocks(45);
  if(!dut.control_enable || dut.recovery_anchor_pending || dut.position_target_q16!==(expected_target*64'sd65536))
   $fatal(1,"incorrect nearest equivalent recovery target: got %0d expected %0d",dut.position_target_q16>>>16,expected_target);
  outer_sample();
  if(dut.position_error!=(capture_position-expected_target) ||
     dut.position!==capture_position)
   $fatal(1,"capture target error or encoder count changed");
 endtask
 integer n;
 initial begin
  force dut.position=position; force dut.speed=speed;
  force dut.theta=theta; force dut.filtered_raw=adc; force dut.adc_valid=1'b1;
  force dut.pos_tick=pos_tick; force dut.tick=ms_tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12); press(1);
  if(!dut.control_enable || dut.position_target_q16) $fatal(1,"ordinary manual start changed zero");
  recover_to(800,950,1080);
  @(negedge clk); position=952; outer_sample();
  if(dut.position_error!=-128 || dut.position_target_q16!=1080*64'sd65536)
   $fatal(1,"recovery target kept following actual position");
  press(3); repeat(dut.motion.MOVE_TICKS) outer_sample();
  if(dut.position_target_q16!=(1080+dut.motion.STEP_COUNTS)*64'sd65536 || dut.motion_busy)
   $fatal(1,"KEY4 did not increment from recovered target");
  recover_to(-300,-700,-1080);
  press(3); repeat(dut.motion.MOVE_TICKS) outer_sample();
  if(dut.position_target_q16!=(-1080+dut.motion.STEP_COUNTS)*64'sd65536 || dut.motion_busy)
   $fatal(1,"KEY4 after repeated negative recovery used stale origin");
  // 等待中的人工取消不能留下待装载标志，后续普通启动仍使用原零点。
  @(negedge clk); theta=1954; adc=0; clocks(5); press(0);
  if(dut.recovery_anchor_pending || dut.recovery_waiting) $fatal(1,"cancel left anchor pending");
  @(negedge clk); theta=0; adc=dut.UPRIGHT_ADC; press(1); outer_sample();
  if(dut.position_target_q16) $fatal(1,"ordinary restart retained recovered anchor unexpectedly");
  @(negedge clk); rst_n=0; clocks(3);
  if(dut.position_target_q16 || dut.recovery_anchor_pending || dut.duty)
   $fatal(1,"reset retained target");
  $display("PASS recovery target: capture-time signed anchor, encoder continuity, first-sample interlock, fixed hold, KEY4 relative motion, repeated recovery and cancel/reset");
  $finish;
 end
 initial begin #3000000; $fatal(1,"timeout"); end
endmodule

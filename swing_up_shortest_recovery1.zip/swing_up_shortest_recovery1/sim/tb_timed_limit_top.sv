`timescale 1ns/1ps
module tb_timed_limit_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0, pos_tick=0;
 reg [2:0] keys=7;
 reg signed [16:0] pos=0;
 wire tx;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw({1'b1,keys}),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(tx),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer count);
  repeat(count) begin @(posedge clk); #2; end
 endtask
 task sample(input integer value, cap, boosted);
  @(negedge clk); pos=value; pos_tick=1; clocks(1);
  @(negedge clk); pos_tick=0; clocks(40);
  if(dut.outer_active_limit!=cap || dut.outer_boost_active!=boosted)
   $fatal(1,"top limit %0d expected %0d",dut.outer_active_limit,cap);
  // 强制串口快照时刻，验证沿用的57字节帧中限幅标志。
  force dut.byte_index=0; force dut.bit_index=0; force dut.baud_count=0;
  clocks(2);
  if(dut.frame_flags[7]!=boosted || dut.frame_flags[6] || !dut.frame_flags[0])
   $fatal(1,"top UART boost status wrong");
  if(dut.frame_limit_status[4:2]!=(boosted ? 7 : 6))
   $fatal(1,"legacy limit diagnostic phase wrong");
  release dut.byte_index; release dut.bit_index; release dut.baud_count;
 endtask
 integer n;
 initial begin
  force dut.position=pos;
  force dut.theta=13'sd0;
  force dut.filtered_raw=dut.UPRIGHT_ADC;
  force dut.adc_valid=1'b1;
  force dut.pos_tick=pos_tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12);
  @(negedge clk); keys=5; clocks(12);
  @(negedge clk); keys=7; clocks(12);
  if(!dut.pid_enable || !dut.manual_mode) $fatal(1,"manual start failed");
  sample(0,40,0); sample(dut.OUTER_LIMIT_POSITION_COUNTS+1,dut.OUTER_LIMIT_FAR_ADC,1);
  for(n=1;n<=105;n=n+1) sample(dut.OUTER_LIMIT_POSITION_COUNTS+10,dut.OUTER_LIMIT_FAR_ADC,1);
  sample(dut.OUTER_LIMIT_POSITION_COUNTS,40,0);
  sample(-dut.OUTER_LIMIT_POSITION_COUNTS-1,dut.OUTER_LIMIT_FAR_ADC,1);
  for(n=1;n<(dut.OUTER_LIMIT_MIN_MS+9)/10;n=n+1) sample(0,dut.OUTER_LIMIT_FAR_ADC,1);
  sample(0,40,0); sample(60,dut.OUTER_LIMIT_FAR_ADC,1);
  // 反复受扰均重新进入110；到时仍在区外不能掉回40或进入等待状态。
  for(n=1;n<=150;n=n+1) sample(n%2 ? 60 : -60,dut.OUTER_LIMIT_FAR_ADC,1);
  sample(-dut.OUTER_LIMIT_POSITION_COUNTS,40,0);
  sample(-60,dut.OUTER_LIMIT_FAR_ADC,1);
  @(negedge clk); keys=6; clocks(16);
  if(dut.running || dut.duty || dut.outer_boost_active || dut.outer_active_limit!=40)
   $fatal(1,"KEY2 failed to clear active boost");
  @(negedge clk); keys=7; pos=0; clocks(16);
  @(negedge clk); keys=5; clocks(12);
  @(negedge clk); keys=7; clocks(12);
  sample(0,40,0); sample(60,dut.OUTER_LIMIT_FAR_ADC,1); sample(0,dut.OUTER_LIMIT_FAR_ADC,1);
  @(negedge clk); rst_n=0; clocks(5);
  if(dut.outer_boost_active || dut.outer_active_limit!=40 || dut.duty)
   $fatal(1,"top reset failed");
  $display("PASS top restored40/110: exact1s AND exit, repeated disturbances, no200/no waiting, UART phase6/7, filtered/fuzzy pipeline and KEY2/reset clearing");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

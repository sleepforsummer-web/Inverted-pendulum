"""仅生成新旧平衡通路对照仿真文件，不修改工程源码或位流。"""
from pathlib import Path
import re

here=Path(__file__).resolve().parent
before=here.parent/'backups/before_sine_keys_20261025/src'
source='\n'.join((before/name).read_text(encoding='utf-8-sig') for name in ('PID.v','fuzzy_pd.v','pid_trial.v'))
modules=re.findall(r'\bmodule\s+(\w+)',source)
source=re.sub(r'\b('+'|'.join(modules)+r')\b',lambda m:'audit_old_'+m[0],source)
(here/'audit_idle_reference.v').write_text(source,encoding='utf-8')

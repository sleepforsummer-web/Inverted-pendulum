"""从ModelSim VCD生成论文时序图；横轴使用VCD的真实仿真时间。"""
from pathlib import Path
from collections import defaultdict
import bisect
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent / 'paper_waves'
plt.rcParams.update({'font.sans-serif':['Microsoft YaHei','SimHei'], 'axes.unicode_minus':False,
                     'font.size':10, 'figure.facecolor':'white', 'savefig.facecolor':'white'})

def read_vcd(path):
    ids, width, series = {}, {}, defaultdict(list)
    grouped=defaultdict(dict); scope=[]; header=True; timestamp=0
    with path.open(encoding='ascii', errors='replace') as stream:
        for line in stream:
            line=line.strip()
            if header:
                if line.startswith('$scope '): scope.append(line.split()[2])
                elif line.startswith('$upscope'): scope.pop()
                elif line.startswith('$var '):
                    parts=line.split(); bits=int(parts[2]); ident=parts[3]; name=parts[4]
                    suffix=parts[5] if len(parts)>5 and parts[5].startswith('[') else ''
                    m=re.fullmatch(r'\[(\d+)\]',suffix)
                    key='.'.join(scope+[name]); index=int(m.group(1)) if m else None
                    ids[ident]=(key,index,bits)
                    width[key]=max(width.get(key,0), index+1 if index is not None else bits)
                elif line.startswith('$enddefinitions'): header=False
                continue
            if line.startswith('#'): timestamp=int(line[1:]); continue
            if not line or line[0]=='$': continue
            if line[0] in '01xXzZ': value=line[0].lower(); ident=line[1:]
            elif line[0] in 'bB':
                parts=line[1:].split()
                if len(parts)!=2: continue
                value,ident=parts
            else: continue
            if ident not in ids: continue
            key,index,bits=ids[ident]
            grouped[timestamp][(key,index)]=value.lower()
    values=defaultdict(dict)
    for t,updates in sorted(grouped.items()):
        dirty=set()
        for (key,index),value in updates.items():
            if index is None: values[key]['all']=value
            else: values[key][index]=value
            dirty.add(key)
        for key in dirty:
            if 'all' in values[key]: bits=values[key]['all']
            else: bits=''.join(values[key].get(i,'x') for i in range(width[key]-1,-1,-1))
            val=None if any(ch not in '01' for ch in bits) else int(bits,2)
            series[key].append((t/1e6,val)) # 1ps -> 微秒
    return series,width

def find(data,name):
    matches=[k for k in data if k.endswith('.'+name)]
    if len(matches)!=1: raise ValueError(f'{name}: {matches}')
    return matches[0]

def numeric(data,width,name,signed=False,div=1):
    key=find(data,name); w=width[key]; out=[]
    for t,v in data[key]:
        if v is not None and signed and v & (1<<(w-1)): v-=1<<w
        out.append((t,None if v is None else v/div))
    return out

def draw(filename,title,subtitle,vcd,rows,window,unit='μs',scale=1):
    data,width=read_vcd(ROOT/(vcd+'.vcd'))
    fig,axes=plt.subplots(len(rows),1,figsize=(13,1.0*len(rows)+1.7),sharex=True,
                          gridspec_kw={'hspace':0.12},squeeze=False)
    axes=axes[:,0]; left,right=window
    for ax,(name,label,kind,signed,div) in zip(axes,rows):
        values=numeric(data,width,name,signed,div)
        pre=[(t,v) for t,v in values if t<left]
        sel=[(t,v) for t,v in values if left<=t<=right]
        if pre: sel.insert(0,(left,pre[-1][1]))
        if not sel: raise ValueError(f'no samples for {name}')
        xs=[x/scale for x,v in sel]+[right/scale]; ys=[np.nan if v is None else v for x,v in sel]+[np.nan if sel[-1][1] is None else sel[-1][1]]
        ax.step(xs,ys,where='post',lw=1.35,color='#1766a3')
        if kind=='pulse':
            for t,v in sel:
                if v==1: ax.axvline(t/scale,color='#e35a33',lw=0.8,alpha=.9)
            ax.set_ylim(-.18,1.4); ax.set_yticks([0,1])
        else:
            ax.yaxis.set_major_locator(plt.MaxNLocator(3))
        ax.set_ylabel(label,rotation=0,ha='right',va='center',fontsize=9,labelpad=10)
        ax.tick_params(labelsize=8); ax.grid(axis='x',color='#dce4ec',lw=.5)
        for side in ('top','right'):ax.spines[side].set_visible(False)
    axes[-1].set_xlim(left/scale,right/scale);axes[-1].set_xlabel(f'仿真时间（{unit}）')
    fig.suptitle(title,fontsize=15,weight='bold',y=.99)
    fig.text(.5,.925,subtitle,ha='center',fontsize=9,color='#536475')
    fig.subplots_adjust(left=.21,right=.98,top=.88,bottom=.09)
    fig.savefig(ROOT/(filename+'.png'),dpi=180)
    plt.close(fig)

def row(n,l,k='bus',s=False,d=1): return (n,l,k,s,d)
draw('01_PID采样时序','双环 PID 采样与更新时序','50 MHz 实际节拍；测试平台注入角度和位置，脉冲用橙线标出', 'pid',
 [row('tick','内环使能 tick','pulse'),row('pos_tick','外环使能 pos_tick','pulse'),row('position','旋臂位置',s=True),row('theta','摆角 theta',s=True),row('theta_ref','目标角',s=True),row('pid_valid','PID 有效','pulse'),row('duty','电机指令',s=True)],(0,21000),'ms',1000)
draw('02_PID计算细节','双环 PID 一次更新的局部时序','10 ms 附近放大；目标角与 PID 结果的先后顺序以仿真数据为准', 'pid',
 [row('tick','内环使能','pulse'),row('pos_tick','外环使能','pulse'),row('theta_ref_valid','外环结果有效','pulse'),row('theta_ref','目标角',s=True),row('pid_valid','内环结果有效','pulse'),row('duty','电机指令',s=True)],(9999.8,10001.0))
draw('03_ADC采样滤波','ADC 采样与滤波时序','50 MHz 主时钟；每32次采样生成一组平均值，测试平台在80 μs改变ADC输入', 'io',
 [row('data','ADC 输入（10位）'),row('raw','块平均值'),row('filtered','IIR 滤波值'),row('theta','摆角 theta',s=True),row('adc_valid','数据有效','pulse')],(0,200))
draw('04_PWM输出','PWM 与电机方向时序','20 kHz PWM；测试指令从 +500 切换为 −500，输入为人工测试激励', 'io',
 [row('duty','电机指令',s=True),row('in1','方向 AN1','pulse'),row('in2','方向 AN2','pulse'),row('pwm','PWMA','pulse')],(60,190))
draw('05_起摆与切换','自动起摆与 PID 切换时序','加速仿真：1 ms 使能由测试平台加速注入，横轴不能当作实物运行时间', 'swing',
 [row('adc','滤波 ADC'),row('swing_state','起摆状态'),row('swing_peak','最高点事件','pulse'),row('swing_duty','起摆指令',s=True),row('pid_enable','PID 使能','pulse'),row('duty','电机指令',s=True)],(0,25))
draw('06_自动恢复最短回位','自动恢复后最短角度回位时序','加速仿真：捕获位置 950、失稳前目标 0，最近等效目标为 1080 计数', 'recovery',
 [row('position','旋臂位置',s=True),row('theta','摆角 theta',s=True),row('running','运行状态','pulse'),row('recovery_waiting','恢复等待','pulse'),row('recovery_anchor_pending','等待目标计算','pulse'),row('recovery_target_ready','目标计算完成','pulse'),row('position_target_q16','位置目标',s=True,d=65536),row('control_enable','PID 使能','pulse')],(0,10))
draw('07_UART下发','UART 位置命令接收时序','115200 baud，11字节 8N1；命令 90°、45°/s，目标采用 Q8 表示', 'uart',
 [row('rx','UART RX','pulse'),row('valid','命令有效','pulse'),row('seq','命令序号'),row('goal','目标 Q8',s=True),row('speed','速度 Q8')],(0,960))
print('PASS: rendered seven ModelSim-derived figures')

`timescale 1ns/1ps
module tb_serial_target_top;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,rx=1,ptick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=0;
 reg signed [15:0] speed=0;
 reg signed [12:0] theta=0;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.AUTO_RECOVER_ENABLE(0)) dut(
  .clk_50m(clk),.rst_n(rst_n),.uart_rx(rx),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 defparam dut.motion.MOVE_TICKS=4;
 defparam dut.sine_path.PERIOD_TICKS=100;
 task clocks(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
 task press(input integer key);
  @(negedge clk);keys=15^(1<<key);clocks(12);@(negedge clk);keys=15;clocks(12);
 endtask
 task sample;
  @(negedge clk);ptick=1;clocks(1);@(negedge clk);ptick=0;clocks(40);
 endtask
 task byte_send(input [7:0] b);
  integer j;@(negedge clk);rx=0;clocks(434);
  for(j=0;j<8;j=j+1)begin @(negedge clk);rx=b[j];clocks(434);end
  @(negedge clk);rx=1;clocks(434);
 endtask
 task command(input integer g,input [7:0] seq,input integer expected);
  reg [7:0] check;integer k;
  check=8'd1^seq;byte_send(8'hA5);byte_send(8'h5A);byte_send(1);byte_send(seq);
  for(k=0;k<4;k=k+1)begin byte_send((g>>(k*8))&255);check=check^((g>>(k*8))&255);end
  byte_send(8'h57);byte_send(8'h01);check=check^8'h57^8'h01;byte_send(check);clocks(20);
  if(dut.remote_reply_seq!=seq || dut.remote_reply_status!=expected)
   $fatal(1,"top command status seq%0d status%0d/%0d",seq,dut.remote_reply_status,expected);
 endtask
 integer n;longint finish_target;
 initial begin
  force dut.position=pos;force dut.speed=speed;force dut.theta=theta;
  force dut.filtered_raw=dut.UPRIGHT_ADC;force dut.adc_valid=1'b1;
  force dut.pos_tick=ptick;force dut.tick=1'b0;
  clocks(3);@(negedge clk);rst_n=1;clocks(12);
  command(68672,1,2);if(dut.running || dut.position_target_q16)$fatal(1,"UART started stopped plant");
  press(1);sample();if(!dut.control_enable)$fatal(1,"manual PID start failed");
  theta=101;command(68672,2,5);theta=0;
  command(68672,3,1);press(2);press(3);
  if(dut.sine_busy || dut.single_busy || !dut.remote_busy)$fatal(1,"keys stole UART motion");
  for(n=0;n<5000 && dut.remote_busy;n=n+1)begin
   sample();if(dut.outer_active_limit!=40 || !dut.control_enable)$fatal(1,"remote motion lost small limit/balance");
  end
  clocks(5);finish_target=68672*64'sd256;
  if(dut.remote_busy || dut.remote_reply_status!=7 || dut.position_target_q16!==finish_target)
   $fatal(1,"remote endpoint not absolute/fractional");
  command(0,4,3); // 目标轨迹虽已结束，实际旋臂未到位，禁止抢占。
  @(negedge clk);pos=268;sample();
  if(dut.motion_limit_active)$fatal(1,"physical arrival not released");
  // KEY4必须从含小数的新终点接续，不能沿用串口之前的零目标。
  press(3);repeat(4)sample();clocks(4);
  finish_target=finish_target+dut.motion.STEP_COUNTS*64'sd65536;
  if(dut.position_target_q16!==finish_target)$fatal(1,"KEY4 lost UART fractional anchor");
  @(negedge clk);pos=1348;sample();press(2);sample();
  if(!dut.sine_busy)$fatal(1,"sine after UART unavailable");
  // 渐入期间请求停止：沿用原模块，先完成渐入，再等待周期边界并渐出，最长约3周期。
  command(0,5,3);press(2);repeat(310)sample();
  if(dut.sine_busy)$fatal(1,"sine stop failed");
  sample();command(-68672,6,1);sample();press(0);clocks(5);
  if(dut.running || dut.remote_busy || dut.position_target_q16 || dut.remote_reply_status!=8)
   $fatal(1,"stop did not cancel UART profile");
  press(1);sample();if(dut.remote_busy)$fatal(1,"manual restart resumed old UART command");
  @(negedge clk);rst_n=0;clocks(4);
  if(dut.remote_reply_status || dut.remote_busy)$fatal(1,"KEY5 not clear command state");
  $display("PASS UART top: actual115200 commands,manual guard,40 limit,KEY3/4 interlock,absolute endpoint,Q16 KEY4 anchor,sine coexistence,physical arrival,stop/reset,no queued restart");$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule

`timescale 1ns/1ps
module tb_outer_integral_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,tick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=10;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(7);
 endtask
 task press(input integer index);
  @(negedge clk); keys=15^(1<<index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 integer n;
 initial begin
  force dut.position=pos; force dut.theta=13'sd0;
  force dut.filtered_raw=dut.UPRIGHT_ADC; force dut.adc_valid=1'b1;
  force dut.pos_tick=tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12); press(1);
  for(n=1;n<=200;n=n+1) begin
   sample();
   if(dut.outer_i_mon!==((n*10*dut.OUTER_KI_Q)>>>8)) $fatal(1,"top I gain/connection wrong");
  end
  if(dut.theta_ref<4 || dut.outer_i_mon<=0) $fatal(1,"I not included in target");
  press(3); sample(); sample();
  if(!dut.motion_busy || dut.outer_i_mon!==0) $fatal(1,"moving target accumulated I");
  press(0); clocks(5);
  if(dut.running || dut.outer_i_mon || dut.theta_ref || dut.position_target_q16)
   $fatal(1,"KEY2 failed to clear I/motion");
  @(negedge clk); pos=-10;
  press(1); sample();
  if(dut.outer_i_mon>=0) $fatal(1,"negative position error I polarity wrong");
  @(negedge clk); pos=50; sample();
  if(dut.outer_i_mon) $fatal(1,"separation boundary failed");
  @(negedge clk); rst_n=0; clocks(4);
  if(dut.outer_i_mon || dut.duty) $fatal(1,"reset failed");
  $display("PASS top outer I: Ki65, 10ms integration, P+I target, motion inhibit, signed error, separation and stop/reset");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

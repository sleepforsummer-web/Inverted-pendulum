"""独立整数参考：逐拍验证D滤波、定点舍入、复位与使能。无需第三方库。"""
from pathlib import Path
import random

HERE = Path(__file__).resolve().parent
CONFIGS = [(0, 6029312), (1, 557056), (3, 6029312), (8, 6029312), (3, -2147483648)]
states = [dict(prev=None, q8=0, d=0, out=0, pending=[None, None]) for _ in CONFIGS]
rows = []


def emit(rst, enable, tick, value):
    expected = []
    valids = []
    for (shift, gain), s in zip(CONFIGS, states):
        if rst or not enable:
            s.update(prev=None, q8=0, d=0, out=0, pending=[None, None])
            output = None
        else:
            output = s['pending'].pop(0) if shift else None
            if output is not None:
                s['out'] = output
        if not rst and enable and tick:
            if s['prev'] is None:
                s.update(q8=0, d=0)
            else:
                delta = value-s['prev']
                if shift:
                    divisor = 1 << shift
                    if delta == 0 and abs(s['q8']) < divisor:
                        s['q8'] = 0
                    else:
                        innovation = delta*256-s['q8']
                        correction = (abs(innovation)+divisor//2)//divisor
                        s['q8'] += correction if innovation >= 0 else -correction
                    s['d'] = (s['q8']*gain)//256
                else:
                    s['d'] = delta*gain
            s['prev'] = value
            if not shift:
                s['out'] = s['d']
                output = s['d']
        if not rst and enable and shift:
            s['pending'].append(s['d'] if tick else None)
        expected.append(s['out'])
        valids.append(int(output is not None))
    rows.append(' '.join(map(str, [rst, enable, tick, value, *expected, *valids])))


emit(1, 0, 0, 1958)
for sign in (1, -1):
    emit(0, 0, 1, 1958)
    for value in (1958, 1958+sign, 1958, 1958+4*sign, 1958+2*sign):
        emit(0, 1, 1, value)
        emit(0, 1, 0, -value)  # 非采样拍的变化不得进入差分
    for _ in range(3000):
        emit(0, 1, 1, 1958)
    assert all(s['d'] == 0 for s in states), '零速必须最终归零'

# 输入的有符号极值、正负半数舍入、随机停机/重启。
for value in (-65536, 65535, -65536, 0, 65535, 0):
    emit(0, 1, 1, value)
rng = random.Random(20261016)
for i in range(2000):
    emit(int(i % 311 == 0), int(i % 127 != 0), int(i % 5 != 0), rng.randrange(-65536, 65536))
(HERE/'d_vectors.txt').write_text('\n'.join(rows)+'\n', encoding='ascii')
print(f'Generated {len(rows)} cycles, {len(CONFIGS)} independent D references')

`timescale 1ns/1ps
module disturbance_case #(parameter integer SHIFT=0, FUZZY=0, MS=1000)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1, en=0, tick=0, moving=0;
 reg signed [16:0] pos=0;
 reg signed [32:0] pos_q16=0;
 wire signed [16:0] cap, target;
 wire boosted, valid, limited;
 wire [12:0] gain;
 wire [2:0] phase;
 position_controller #(.Kp_pos(131072),.Kd_pos(0),.Ki_pos(0),
  .USE_Q16_POSITION(1),.D_FILTER_SHIFT(SHIFT),.LIMIT_SWITCH_ENABLE(1),
  .THETA_REF_MAX(40),.THETA_REF_BOOST_MAX(110),.LIMIT_POSITION_THRESHOLD(10),
  .DISTURB_LIMIT_ENABLE(1),.DISTURB_LIMIT_MAX(200),.DISTURB_LIMIT_RAMP_MS(MS)
  ) dut(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.position_error(pos),
  .position_error_q16(pos_q16),.position_measurement(pos),.integral_clear(1'b0),
  .motion_active(moving),.theta_ref(target),.theta_ref_valid(valid),
  .p_pos_mon(),.d_pos_mon(),.i_pos_mon(),.limited_mon(limited),
  .active_limit_mon(cap),.boost_active_mon(boosted),.limit_phase_mon(phase));
 task clocks(input integer n); repeat(n) begin @(posedge clk); #2; end endtask
 task sample_q(input longint value, input integer expected_cap);
  @(negedge clk);pos_q16=value;pos=value>>>16;tick=1;clocks(1);
  @(negedge clk);tick=0;clocks(40);
  if(cap!==expected_cap || boosted!==(expected_cap>40) || target>cap || target< -cap)
   $fatal(1,"shift%0d fuzzy%0d ms%0d posQ%0d cap%0d/%0d target%0d boost%0d",
       SHIFT,FUZZY,MS,value,cap,expected_cap,target,boosted);
  if(value==0 && target!=0) $fatal(1,"limit incorrectly forces a nonzero target");
 endtask
 task sample(input integer value, expected_cap);sample_q(value*64'sd65536,expected_cap);endtask
 integer n, steps;
 initial begin
  steps=(MS+9)/10;
  clocks(3);@(negedge clk);rst=0;en=1;
  // 起摆阶段不允许200：满1秒但仍在区外必须保持110。
  sample(1000,110);
  for(n=1;n<=120;n=n+1) sample(n%2 ? -1000 : 1000,110);
  if(phase!=1) $fatal(1,"startup diagnostic phase wrong");
  sample(10,40);sample(-10,40);
  if(phase!=2) $fatal(1,"armed diagnostic phase wrong");
  // 负10.5计数也应触发；不能把Q16小数截成阈值边界。
  sample_q(-64'sd688128,200);
  if(phase!=3) $fatal(1,"decay diagnostic phase wrong");
  for(n=1;n<=steps;n=n+1)
   sample(n==steps/2 ? 0 : (n%2 ? 1000 : -1000),200-(160*n)/steps);
  // 到期强制40，不因仍偏离而重新触发200。
  repeat(120) sample(1000,40);
  if(phase!=4) $fatal(1,"waiting-for-reentry diagnostic phase wrong");
  sample(-10,40);sample_q(64'sd688128,200);
  // 运动优先终止包络；即使没有采样，也要清空旧状态。
  @(negedge clk);moving=1;clocks(3);
  repeat(120) sample(1000,40);
  if(phase!=5) $fatal(1,"motion diagnostic phase wrong");
  @(negedge clk);moving=0;
  sample(1000,110);
  for(n=1;n<100;n=n+1) sample(0,110);
  sample(0,40);sample(-1000,200);
  // 刚触发后停机，重新启用不能继承200或包络计时。
  @(negedge clk);en=0;clocks(8);
  if(cap!=40 || boosted || target || valid) $fatal(1,"disable failed");
  @(negedge clk);en=1;
  sample(1000,110);
  for(n=1;n<100;n=n+1) sample(0,110);
  sample(0,40);sample(1000,200);
  @(negedge clk);rst=1;clocks(8);
  if(cap!=40 || boosted || target || valid) $fatal(1,"reset failed");
  @(negedge clk);rst=0;
  // 起点原本就在范围内：满1秒后才允许认定后续偏离。
  repeat(100) sample(0,40);
  sample(1000,200);
  for(n=1;n<=steps;n=n+1) sample(0,200-(160*n)/steps);
  sample(-1000,200);
  done=1;
 end
endmodule
module tb_disturbance_limit;
 wire a,b,c,d;
 disturbance_case #(.SHIFT(0),.FUZZY(0),.MS(1000)) c0(a);
 disturbance_case #(.SHIFT(2),.FUZZY(0),.MS(500)) c1(b);
 disturbance_case #(.SHIFT(2),.FUZZY(1),.MS(1000)) c2(c);
 disturbance_case #(.SHIFT(0),.FUZZY(1),.MS(500)) c3(d);
 initial begin wait(a&&b&&c&&d);
  $display("PASS disturbance envelope: startup110 AND exit, 200-to40 exact500/1000ms, fractional boundaries, no retrigger, motion override, reset/disable, fixed/fuzzy pipelines");
  $finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

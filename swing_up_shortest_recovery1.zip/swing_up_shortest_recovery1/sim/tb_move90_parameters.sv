`timescale 1ns/1ps
// 反向、不能整除的时长、单拍运动：检查参数化后的符号、终点和固定步长。
module accumulator_case #(parameter integer DISTANCE=-260, TICKS=300)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0, enable=0,tick=0,event_in=0;
 wire signed [32:0] target;
 wire busy,valid,rejected;
 move90 #(.STEP_COUNTS(DISTANCE),.MOVE_TICKS(TICKS)) dut(
  .clk(clk),.rst_n(rst_n),.enable(enable),.sample_tick(tick),.start_event(event_in),.load_target(1'b0),.load_position(17'sd0),
  .target_q16(target),.busy(busy),.target_valid(valid),.range_rejected(rejected),.motion_active());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 longint total, step, expected, before_target;
 integer n, repeat_n;
 initial begin
  total=DISTANCE*64'sd65536; step=total/TICKS;
  clocks(3); @(negedge clk); rst_n=1; enable=1;
  for(repeat_n=0;repeat_n<2;repeat_n=repeat_n+1) begin
   @(negedge clk); event_in=1; clocks(1);
   @(negedge clk); event_in=0; clocks(3);
   for(n=1;n<=TICKS;n=n+1) begin
    before_target=target;
    clocks(5); if(target!==before_target || valid) $fatal(1,"changed without sample tick");
    @(negedge clk); tick=1; clocks(1);
    expected=repeat_n*total+(n==TICKS ? total : n*step);
    if(target!==expected || !valid || busy!==(n<TICKS) || rejected)
     $fatal(1,"distance=%0d ticks=%0d n=%0d target=%0d expected=%0d",DISTANCE,TICKS,n,target,expected);
    @(negedge clk); tick=0; clocks(2);
   end
  end
  @(negedge clk); enable=0; clocks(3);
  if(target || busy || valid || dut.remaining) $fatal(1,"disable retained accumulator");
  @(negedge clk); rst_n=0; clocks(3);
  if(target || busy || rejected) $fatal(1,"reset failed");
  done=1;
 end
endmodule
module tb_move90_parameters;
 wire a,b,c;
 accumulator_case #(.DISTANCE(-260),.TICKS(300)) reverse_case(a);
 accumulator_case #(.DISTANCE(17),.TICKS(7)) odd_duration_case(b);
 accumulator_case #(.DISTANCE(260),.TICKS(1)) single_tick_case(c);
 initial begin
  wait(a && b && c);
  $display("PASS accumulator parameters: negative direction, non-divisible increments, one-tick motion, repeat, tick gaps and disable/reset");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

`timescale 1ns/1ps
module tb_move90_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,tick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=0;
 reg signed [12:0] theta=0;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task press(input integer key_index);
  @(negedge clk); keys=15 ^ (1<<key_index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(8);
 endtask
 integer n;
 initial begin
  force dut.position=pos; force dut.theta=theta;
  force dut.filtered_raw=dut.UPRIGHT_ADC; force dut.adc_valid=1'b1;
  force dut.pos_tick=tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12);
  press(3); sample(); if(dut.running || dut.motion_busy) $fatal(1,"KEY4 started stopped system");
  press(1); if(!dut.pid_enable) $fatal(1,"KEY3 manual start");
  // 无500ms等待门槛；短毛刺不启动，消抖后的KEY4立即锁存至下一位置节拍。
  @(negedge clk); keys=7; clocks(2);
  @(negedge clk); keys=15; clocks(12); sample();
  if(dut.motion_busy) $fatal(1,"KEY4 glitch accepted");
  press(3);
  for(n=1;n<=dut.motion.MOVE_TICKS;n=n+1) begin
   sample();
   if(dut.outer_d_mon!==0 || !dut.running) $fatal(1,"moving reference corrupted D or stopped balance");
   if(dut.outer_active_limit!=40 || dut.outer_boost_active || dut.position_control.boost_elapsed_ticks)
    $fatal(1,"motion did not force small limit and clear timer");
  end
  if(dut.motion_busy || dut.position_target_q16!=(dut.motion.STEP_COUNTS*64'sd65536) ||
     dut.position_error!= -dut.motion.STEP_COUNTS || dut.outer_active_limit!=40 ||
     dut.theta_ref>=0) $fatal(1,"full-turn target not connected to correct-sign outer loop");
  // 目标刚到终点但实际尚未到位，继续小限幅，不能按时间结束切回大限幅。
  sample();
  if(dut.outer_active_limit!=40 || dut.outer_boost_active || !dut.motion_limit_active ||
     dut.position_control.boost_elapsed_ticks!=0) $fatal(1,"normal rule resumed before actual arrival");
  // 真实位置到达目标后，P误差归零并恢复小限幅，目标保持不返回。
  @(negedge clk); pos=dut.motion.STEP_COUNTS; sample(); sample();
  if(dut.position_error || dut.outer_active_limit!=40 || dut.position_target_q16!=(dut.motion.STEP_COUNTS*64'sd65536))
   $fatal(1,"target tracking or limit error uses absolute position instead of tracking error");
  // 串口误差字段仍可反推出新位置目标。
  force dut.byte_index=0; force dut.bit_index=0; force dut.baud_count=0;
  clocks(2);
  if(dut.frame_pos32!=dut.motion.STEP_COUNTS || dut.frame_pos_error32!=0) $fatal(1,"UART wrong tracking error");
  release dut.byte_index; release dut.bit_index; release dut.baud_count;
  // 未达到长按阈值时保持不运动，松开后才执行短按。
  @(negedge clk); keys=7; clocks(12);
  repeat(dut.motion.MOVE_TICKS+10) sample();
  if(dut.position_target_q16!=(dut.motion.STEP_COUNTS*64'sd65536) || dut.motion_busy)
   $fatal(1,"held KEY4 repeated motion");
  @(negedge clk); keys=15; clocks(12);
  repeat(dut.motion.MOVE_TICKS) sample();
  if(dut.position_target_q16!=(dut.motion.STEP_COUNTS*64'sd131072)) $fatal(1,"short release failed");
  press(3); repeat(50) sample(); press(0); clocks(5);
  if(dut.running || dut.position_target_q16 || dut.motion_busy || dut.duty)
   $fatal(1,"KEY2 failed to stop and clear motion");
  @(negedge clk); pos=0;
  press(1); sample(); if(dut.position_target_q16 || dut.motion_busy) $fatal(1,"old pending start survived stop");
  press(3); sample(); @(negedge clk); theta=1500; clocks(5);
  if(dut.running || dut.position_target_q16 || dut.motion_busy || dut.stop_reason!=3)
   $fatal(1,"angle stop failed during motion");
  // 起摆时KEY4不排队，之后切入PID不会自己启动轨迹。
  @(negedge clk); theta=0; clocks(8); press(0); press(3);
  if(dut.motion_busy || dut.motion.pending_start) $fatal(1,"swing-up queued KEY4");
  @(negedge clk); rst_n=0; clocks(5);
  if(dut.position_target_q16 || dut.motion_busy) $fatal(1,"reset failed");
  $display("PASS move90 top: KEY4 debounce/hold, immediate PID-only start, full-turn target, fractional PD, limit tracking, UART and stop interlocks");
  $finish;
 end
 initial begin #10000000; $fatal(1,"timeout"); end
endmodule

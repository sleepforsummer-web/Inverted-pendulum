`timescale 1ns/1ps
// 实际50MHz、1ms/10ms使能节拍；人工注入传感器数据，不代表物理摆杆运动。
module tb_paper_pid;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0; reg [3:0] keys=15;
 reg signed [16:0] position=0; reg signed [12:0] theta=0;
 reg [11:0] adc=1960;
 wire pwm,a,b;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.AUTO_RECOVER_ENABLE(0)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),.uart_rx(1'b1),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(pwm),.AN1(a),.AN2(b),.PWMB(),.BN1(),.BN2());
 initial begin
  force dut.position=position; force dut.speed=16'sd0;
  force dut.theta=theta; force dut.filtered_raw=adc; force dut.adc_valid=1'b1;
  #100; rst_n=1; #300; keys=13; #300; keys=15;
  #3000000; position=100; adc=1950; theta=10;
  #9000000; position=-50; adc=1970; theta=-10;
  #9000000; if(!dut.control_enable) $fatal(1,"PID not enabled");
  $display("PASS paper PID real sample timing"); $finish;
 end
 initial begin #23000000;$fatal(1,"timeout");end
endmodule

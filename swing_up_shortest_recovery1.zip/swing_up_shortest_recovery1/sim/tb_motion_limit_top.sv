`timescale 1ns/1ps
// 顶层使用不同大小限幅测试，避免用户当前40/40设置掩盖接线错误。
module tb_motion_limit_top;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,tick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=200;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 defparam dut.position_control.THETA_REF_BOOST_MAX=110;
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(40);
 endtask
 task press(input integer index);
  @(negedge clk); keys=15^(1<<index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 integer n;
 initial begin
  force dut.position=pos; force dut.theta=13'sd0;
  force dut.filtered_raw=dut.UPRIGHT_ADC; force dut.adc_valid=1'b1;
  force dut.pos_tick=tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12); press(1);
  repeat(20) sample();
  if(dut.outer_active_limit!=110 || !dut.outer_boost_active || dut.position_control.boost_elapsed_ticks==0)
   $fatal(1,"pre-motion boost not established");
  press(3);
  if(dut.motion_busy || !dut.motion.pending_start || !dut.motion_limit_active ||
     dut.position_control.boost_mode || dut.position_control.boost_elapsed_ticks)
   $fatal(1,"pending KEY4 did not override old timer before first sample");
  for(n=0;n<dut.motion.MOVE_TICKS;n=n+1) begin
   sample();
   if(dut.outer_active_limit!=40 || dut.outer_boost_active || dut.position_control.boost_elapsed_ticks ||
      dut.theta_ref>40 || dut.theta_ref < -40) $fatal(1,"top movement exceeded40");
  end
  if(dut.motion_busy || !dut.motion_limit_active || dut.position_target_q16!=(dut.motion.STEP_COUNTS*64'sd65536))
   $fatal(1,"motion target completion not propagated");
  repeat(150) sample(); // 即使已超过1秒，实际未到位也不能切换
  if(dut.outer_active_limit!=40 || dut.outer_boost_active || !dut.motion_limit_active ||
     dut.position_control.boost_elapsed_ticks) $fatal(1,"trajectory timeout bypassed arrival");
  @(negedge clk); pos=dut.motion.STEP_COUNTS-dut.MOTION_ARRIVE_COUNTS-1; sample();
  if(!dut.motion_limit_active) $fatal(1,"arrival tolerance too wide");
  @(negedge clk); pos=dut.motion.STEP_COUNTS-dut.MOTION_ARRIVE_COUNTS; sample();
  if(dut.motion_limit_active || dut.motion_arrival_wait ||
     dut.outer_active_limit!=(dut.MOTION_ARRIVE_COUNTS>dut.OUTER_LIMIT_POSITION_COUNTS ? 110 : 40) ||
     dut.outer_boost_active!=(dut.MOTION_ARRIVE_COUNTS>dut.OUTER_LIMIT_POSITION_COUNTS))
   $fatal(1,"inclusive arrival boundary did not release motion limit");
  // 若到位容差大于限幅切换阈值，到位当拍可合法进入大限幅；先回目标并完成保持时间。
  @(negedge clk); pos=dut.motion.STEP_COUNTS; repeat(100) sample();
  // 到位后再次受扰立即使用110，不进入200包络或等待回区状态。
  @(negedge clk); pos=dut.motion.STEP_COUNTS-100; sample();
  if(dut.outer_active_limit!=110 || !dut.outer_boost_active)
   $fatal(1,"post-arrival normal rule did not restore fresh boost");
  @(negedge clk); pos=dut.motion.STEP_COUNTS;
  repeat((dut.OUTER_LIMIT_MIN_MS+9)/10-1) sample();
  if(dut.outer_active_limit!=110) $fatal(1,"fresh110 boost returned early");
  sample(); if(dut.outer_active_limit!=40 || dut.outer_boost_active) $fatal(1,"fresh AND exit failed");
  // 运动中人工停机仍清除运动、限幅计时与电机输出。
  press(3); sample(); press(0); clocks(5);
  if(dut.running || dut.motion_limit_active || dut.motion_busy || dut.duty ||
     dut.outer_boost_active || dut.position_control.boost_elapsed_ticks)
   $fatal(1,"manual stop did not clear motion limit state");
  $display("PASS motion limit top: pending KEY4, forced40 until physical arrival, inclusive tolerance, restored110 for repeated disturbances, AND exit and stop");
  $finish;
 end
 initial begin #10000000; $fatal(1,"timeout"); end
endmodule

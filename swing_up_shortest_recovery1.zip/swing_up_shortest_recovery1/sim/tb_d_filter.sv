`timescale 1ns/1ps
module tb_d_filter;
    reg clk=0;
    always #10 clk=~clk;
    reg rst=1, enable=0, tick=0;
    reg signed [16:0] value=0;
    wire signed [49:0] d [0:4];
    wire [4:0] valid;
    reg signed [63:0] expected [0:4];
    integer expected_valid [0:4];
    integer fd, n, count=0, r, en, t, v, i;
    genvar g;
    generate for(g=0;g<5;g=g+1) begin : units
        localparam integer SHIFT = g==0 ? 0 : g==1 ? 1 : g==3 ? 8 : 3;
        localparam signed [31:0] GAIN = g==1 ? 32'sd557056 :
                                         g==4 ? -32'sd2147483648 : 32'sd6029312;
        pid_d #(.Kd(GAIN),.FILTER_SHIFT(SHIFT)) dut(
            .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),
            .error(value),.d(d[g]),.d_valid(valid[g]));
    end endgenerate
    initial begin
        fd=$fopen("d_vectors.txt","r");
        if(!fd) $fatal(1,"cannot open independent reference vectors");
        while(!$feof(fd)) begin
            @(negedge clk);
            n=$fscanf(fd,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d\n",
                r,en,t,v,expected[0],expected[1],expected[2],expected[3],expected[4],
                expected_valid[0],expected_valid[1],expected_valid[2],expected_valid[3],expected_valid[4]);
            if(n!=14) $fatal(1,"bad reference row");
            rst=r; enable=en; tick=t; value=v;
            @(posedge clk); #2;
            for(i=0;i<5;i=i+1) begin
                if($signed(d[i]) !== expected[i])
                    $fatal(1,"cycle=%0d unit=%0d actual=%0d expected=%0d",count,i,d[i],expected[i]);
                if(valid[i] !== (expected_valid[i]!=0))
                    $fatal(1,"valid timing changed cycle=%0d unit=%0d",count,i);
            end
            count=count+1;
        end
        $fclose(fd);
        $display("PASS D filter: %0d cycles x 5 references, signed extremes, rounding, decay, reset, enable and tick gaps",count);
        $finish;
    end
    initial begin #1000000; $fatal(1,"timeout"); end
endmodule

`timescale 1ns/1ps
module tb_move90;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,enable=0,tick=0,event_in=0;
 wire signed [32:0] target;
 wire busy,valid,rejected;
 reg sample_valid;
 move90 #(.STEP_COUNTS(1073)) dut(.clk(clk),.rst_n(rst_n),.enable(enable),.sample_tick(tick),
  .start_event(event_in),.load_target(1'b0),.load_position(17'sd0),.target_q16(target),.busy(busy),.target_valid(valid),.range_rejected(rejected),.motion_active());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task press;
  @(negedge clk); event_in=1; clocks(1);
  @(negedge clk); event_in=0; clocks(2);
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  sample_valid=valid;
  @(negedge clk); tick=0; clocks(2);
 endtask
 task motion(input integer origin);
  integer i;
  longint previous, expected, difference;
  previous=origin*64'sd65536;
  press();
  for(i=1;i<=dut.MOVE_TICKS;i=i+1) begin
   if(i==40 || i==150) press(); // 忙时不得排队或叠加另一段运动。
   sample();
   expected=origin*64'sd65536+(i==dut.MOVE_TICKS ? 64'sd70320128 : i*(64'sd70320128/dut.MOVE_TICKS));
   difference=target-expected;
   if(difference!=0 || target<previous || target-previous>(64'sd70320128/dut.MOVE_TICKS+dut.MOVE_TICKS) ||
      busy!==(i<dut.MOVE_TICKS) || !sample_valid || rejected)
    $fatal(1,"motion sample %0d target %0d expected %0d busy=%0d",i,target,expected,busy);
   previous=target;
  end
  if(target!==(origin+1073)*64'sd65536) $fatal(1,"not exactly1073 counts");
  repeat(400) begin
   sample();
   if(target!==(origin+1073)*64'sd65536 || busy || sample_valid) $fatal(1,"automatic return/restart");
  end
 endtask
 initial begin
  clocks(3); @(negedge clk); rst_n=1;
  press(); sample(); if(target || busy) $fatal(1,"disabled event started motion");
  @(negedge clk); enable=1; clocks(2);
  motion(0); motion(1073);
  press(); repeat(100) sample();
  @(negedge clk); enable=0; clocks(3);
  if(target || busy || valid || rejected) $fatal(1,"stop failed to clear target");
  @(negedge clk); enable=1; clocks(3); sample();
  if(target || busy) $fatal(1,"old event survived restart");
  // 接近累计位置上界时拒绝整次运动，保持原目标，不发生有符号回卷。
  @(negedge clk); dut.target_q16=33'sd4292608000; // 65500计数
  press(); sample();
  if(!rejected || busy || target!=33'sd4292608000) $fatal(1,"range protection failed");
  @(negedge clk); rst_n=0; clocks(3);
  if(target || busy || rejected) $fatal(1,"reset failed");
  $display("PASS move90: configured constant increments, exact1073 counts, repeated full turn, no return, no queued events, stop/reset and range guard");
  $finish;
 end
 initial begin #10000000; $fatal(1,"timeout"); end
endmodule

`timescale 1ns/1ps
module startup150_case #(parameter integer SHIFT=0, START_MS=1000, ONCE=1)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1,en=0,tick=0,arm=0,moving=0;
 reg signed [16:0] pos=0;
 wire signed [16:0] cap,target;
 wire valid,boosted;
 wire [2:0] phase;
 position_controller #(.Kp_pos(131072),.Kd_pos(0),.D_FILTER_SHIFT(SHIFT),
  .LIMIT_SWITCH_ENABLE(1),
  .THETA_REF_MAX(40),.THETA_REF_BOOST_MAX(110),.LIMIT_POSITION_THRESHOLD(10),
  .STARTUP_BOOST_ENABLE(ONCE),.STARTUP_BOOST_MAX(150),.STARTUP_BOOST_MS(START_MS)) dut(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.position_error(pos),
  .position_error_q16(33'sd0),.position_measurement(pos),.integral_clear(1'b0),
  .motion_active(moving),.startup_boost_arm(arm),
  .theta_ref(target),.theta_ref_valid(valid),.p_pos_mon(),.d_pos_mon(),.i_pos_mon(),
  .limited_mon(),.active_limit_mon(cap),.boost_active_mon(boosted),.limit_phase_mon(phase));
 task clocks(input integer n);repeat(n) begin @(posedge clk);#2;end endtask
 task sample(input integer value, expected_cap, expected_phase);
  @(negedge clk);pos=value;tick=1;clocks(1);
  @(negedge clk);tick=0;clocks(40);
  if(cap!==expected_cap || phase!==expected_phase || boosted!==(expected_cap>40) || target>cap || target< -cap)
   $fatal(1,"startup150 shift%0d ms%0d enabled%0d cap%0d/%0d phase%0d/%0d",SHIFT,START_MS,ONCE,cap,expected_cap,phase,expected_phase);
 endtask
 task arm_once;
  @(negedge clk);arm=1;clocks(1);@(negedge clk);arm=0;clocks(3);
 endtask
 integer n;
 initial begin
  clocks(3);@(negedge clk);rst=0;en=1;
  sample(0,40,6);arm_once();
  if(ONCE) begin
   // 位置条件不能延长150；第100个后续采样（1秒）必须直接进入常规大限幅。
   sample(0,150,1);
   for(n=1;n<START_MS/10;n=n+1) sample(n%2 ? 10 : -10,150,1);
   sample(11,110,7);
   for(n=1;n<100;n=n+1) sample(0,110,7);
   sample(-10,40,6);
  end else sample(0,40,6);
  // 后续每轮偏离均为110，不得再次出现150或等待回区状态。
  sample(11,110,7);
  for(n=1;n<100;n=n+1) sample(0,110,7);
  sample(0,40,6);sample(-11,110,7);
  repeat(110) sample(-11,110,7);
  sample(0,40,6);
  // 另一轮固定时长结束时已在区内，应立即40，无额外常规大限幅。
  if(ONCE) begin
   arm_once();sample(0,150,1);
   for(n=1;n<START_MS/10;n=n+1) sample(0,150,1);
   sample(0,40,6);sample(0,40,6);
  end
  @(negedge clk);moving=1;
  repeat(110) sample(1000,40,5);
  @(negedge clk);moving=0;
  sample(11,110,7);
  for(n=1;n<100;n=n+1) sample(0,110,7);
  sample(0,40,6);
  // 重新自动起摆的独立事件才可再次150；中途停机、复位必须清除。
  arm_once();sample(0,ONCE ? 150 : 40,ONCE ? 1 : 6);
  @(negedge clk);en=0;clocks(8);
  if(cap!=40 || phase!=0 || boosted || target || valid) $fatal(1,"disable retained first-startup state");
  @(negedge clk);en=1;sample(0,40,6); // 未收到自动起摆事件的手动PID不走150
  // 自动接管与外环采样同拍也不得漏掉第一次150。
  @(negedge clk);arm=1;pos=0;tick=1;clocks(1);
  @(negedge clk);arm=0;tick=0;clocks(40);
  if(cap!=(ONCE ? 150 : 40)) $fatal(1,"coincident arm/sample lost startup limit");
  @(negedge clk);rst=1;clocks(8);
  if(cap!=40 || phase!=0 || boosted || target) $fatal(1,"reset retained startup state");
  @(negedge clk);rst=0;sample(11,110,7);
  done=1;
 end
endmodule
module tb_startup150_once;
 wire a,b,c,d;
 startup150_case #(.SHIFT(0)) c0(a);
 startup150_case #(.SHIFT(2),.START_MS(500)) c1(b);
 startup150_case #(.SHIFT(2),.START_MS(1500)) c2(c);
 startup150_case #(.SHIFT(2),.ONCE(0)) c3(d);
 initial begin wait(a&&b&&c&&d);
  $display("PASS startup150: fixed1s ends outside, immediate regular boost with fresh AND timer, one-shot,rearm,reset,motion and simultaneous sample");$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

`timescale 1ns/1ps
module tb_uart_outer_i;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0;
 wire tx;
 pid_trial dut(.clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(4'b1111),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(tx),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 reg [7:0] frame[0:75];
 reg [7:0] value,x;
 integer k,j,fd;
 task byte_receive(output reg [7:0] result);
  integer bit_n;
  @(negedge tx);
  repeat(651) @(posedge clk); #2;
  result[0]=tx;
  for(bit_n=1;bit_n<8;bit_n=bit_n+1) begin repeat(434) @(posedge clk); #2; result[bit_n]=tx; end
  repeat(434) @(posedge clk); #2;
  if(tx!==1'b1) $fatal(1,"UART stop bit invalid");
 endtask
 initial begin
  fd=$fopen("uart_outer_i.hex","w");
  if(!fd) $fatal(1,"cannot create UART capture");
  force dut.outer_i_mon=32'sd384; // 实际ADC贡献+1.5
  force dut.control_enable=1'b1; force dut.outer_active_limit=17'sd200; force dut.outer_limit_phase=3'd3;
  force dut.remote_goal_q8=32'sd68672;force dut.position_target_q16=33'sd3309568;
  force dut.remote_reply_seq=8'd17;force dut.remote_reply_status=8'd1;
  fork
   begin repeat(4) @(posedge clk); @(negedge clk); rst_n=1; end
   begin
    for(k=0;k<2;k=k+1) begin
     for(j=0;j<76;j=j+1) begin
      byte_receive(value); frame[j]=value; $fwrite(fd,"%02x\n",value);
      if(k==0 && j==1) begin // 帧内变化不能破坏限幅、阶段、积分的快照
       force dut.outer_i_mon=-32'sd640;
       force dut.outer_active_limit=17'sd40; force dut.outer_limit_phase=3'd4;
       force dut.remote_goal_q8=-32'sd137344;force dut.position_target_q16=-33'sd655360;
       force dut.remote_reply_seq=8'd18;force dut.remote_reply_status=8'd7;
      end
     end
     if(frame[0]!=8'hAA || frame[1]!=8'h5E) $fatal(1,"AA5E header invalid");
     if({frame[61],frame[60]}!=16'd4096 || frame[62][1:0]!=2'd0) $fatal(1,"reserved fixed-PD telemetry invalid");
     if({frame[64],frame[63]}!=(k==0 ? 200 : 40) || frame[62][4:2]!=(k==0 ? 3 : 4))
      $fatal(1,"limit cap/phase snapshot wrong");
     x=0; for(j=2;j<75;j=j+1) x=x^frame[j];
     if(x!==frame[75]) $fatal(1,"76-byte UART checksum invalid");
     if($signed({frame[68],frame[67],frame[66],frame[65]})!==(k==0 ? 68672 : -137344) ||
        $signed({frame[72],frame[71],frame[70],frame[69]})!==(k==0 ? 12928 : -2560) ||
        frame[73]!=(k==0 ? 17 : 18) || frame[74]!=(k==0 ? 1 : 7))
       $fatal(1,"remote goal/trajectory/ack snapshot invalid");
     if(k==0 && {frame[59],frame[58],frame[57],frame[56]}!==32'd384)
      $fatal(1,"positive I or frame snapshot invalid");
     if(k==1 && $signed({frame[59],frame[58],frame[57],frame[56]})!==-32'sd640)
      $fatal(1,"negative I or next frame update invalid");
    end
   end
  join
  $fclose(fd);
  $display("PASS UART diagnostics: real115200 8N1,76 bytes,signed Q8,goal/trajectory/ack/limit snapshots,checksum,two-frame capture");
  $finish;
 end
 initial begin #30000000; $fatal(1,"timeout"); end
endmodule

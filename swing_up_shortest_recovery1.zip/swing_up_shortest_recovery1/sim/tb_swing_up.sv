`timescale 1ns/1ps
module tb_swing_up;
 reg clk=0;
 always #10 clk=~clk;
 reg rst_n=0, enable=0, tick=0, adc_valid=0;
 reg [11:0] adc=3000;
 wire balance, pulse, peak;
 wire signed [16:0] duty;
 wire [2:0] state;
 wire [1:0] peak_region;
 integer peaks=0, before_peaks;
 swing_up dut(.clk(clk),.rst_n(rst_n),.enable(enable),.tick_1ms(tick),
  .adc_valid(adc_valid),.adc_value(adc),.balance_mode(balance),
  .pulse_active(pulse),.duty_command(duty),.state(state),
  .peak_event(peak),.peak_region(peak_region));
 always @(posedge clk) begin
  #1;
  if(peak) peaks=peaks+1;
  if(!enable && duty!==0) $fatal(1,"disable must cancel command immediately");
 end
 task ms(input integer n);
  repeat(n) begin
   @(negedge clk); tick=1;
   @(posedge clk); #2;
   @(negedge clk); tick=0;
   @(posedge clk); #2;
  end
 endtask
 task restart(input integer value);
  @(negedge clk); enable=0; tick=0; adc=value; adc_valid=1;
  repeat(2) @(posedge clk);
  @(negedge clk); enable=1;
  repeat(2) @(posedge clk); #2;
  if(state!==1 || duty!==0) $fatal(1,"start must enter quiet JUDGE state");
 endtask
 task sample(input integer value);
  @(negedge clk); adc=value;
  ms(40);
 endtask
 task expect_quiet;
  if(state!==1 || pulse || duty!==0) $fatal(1,"unqualified group triggered pulse");
 endtask
 initial begin
  repeat(3) @(posedge clk);
  @(negedge clk); rst_n=1;
  // No measurement yet: reset ADC value must not cause false capture.
  adc=1958; enable=1; ms(5);
  if(balance) $fatal(1,"capture before first ADC valid");

  restart(3000); before_peaks=peaks;
  sample(3000); expect_quiet();
  sample(2800); expect_quiet();
  sample(2900);
  if(state!==2 || duty!==500 || peaks!=before_peaks+1 || peak_region!=1)
   $fatal(1,"left minimum must trigger +500 first pulse at third sample");
  ms(99); if(state!==2 || duty!==500) $fatal(1,"first pulse shorter than100ms");
  ms(1); if(state!==3 || duty!==-500) $fatal(1,"first pulse longer than100ms");
  ms(99); if(state!==3 || duty!==-500) $fatal(1,"reverse shorter than100ms");
  ms(1); expect_quiet();
  if(peaks!=before_peaks+1) $fatal(1,"retrigger during pair");
  // After the pair, constant/decreasing history must not trigger a new peak.
  sample(2700); expect_quiet(); sample(2600); expect_quiet();
  sample(2500); expect_quiet();

  restart(800);
  sample(800); sample(1000); sample(900);
  if(state!==2 || duty!==-500 || peak_region!=2) $fatal(1,"right maximum polarity");
  ms(100); if(duty!==500 || state!==3) $fatal(1,"right reverse polarity");
  ms(100); expect_quiet();

  restart(3000); before_peaks=peaks;
  sample(3000); sample(1000); sample(3000); expect_quiet();
  sample(3500); sample(3400); sample(3300); expect_quiet();
  sample(800); sample(1000); sample(1000); expect_quiet();
  sample(4090); sample(4000); sample(4080); expect_quiet();
  sample(10); sample(20); sample(0); expect_quiet();
  if(peaks!=before_peaks) $fatal(1,"mixed, monotonic, equal or invalid group accepted");

  // Regression: a peak crossing the old group boundary must now be caught.
  restart(3000); before_peaks=peaks;
  sample(3000); sample(2900); sample(2800);
  sample(2900);
  if(state!==2 || peaks!=before_peaks+1) $fatal(1,"sliding window missed old group-boundary peak");

  // Retain samples during the initial pair: detect on the first new sample
  // after completion, rather than waiting for three entirely new samples.
  @(negedge clk); enable=0; adc=0; ms(1);
  @(negedge clk); enable=1; ms(1);
  ms(118); @(negedge clk); adc=3000; ms(1);
  ms(39); @(negedge clk); adc=2800; ms(1);
  ms(39); @(negedge clk); adc=2700; ms(1);
  ms(1);
  if(state!==1 || duty!==0) $fatal(1,"initial pair completion");
  sample(2800);
  if(state!==2 || duty!==500) $fatal(1,"pulse-time sampling history was lost");

  restart(3000); sample(3000); sample(2800); sample(2900);
  sample(1958); if(balance) $fatal(1,"capture after only one sample");
  sample(1958); if(balance) $fatal(1,"capture after only two samples");
  @(negedge clk); adc=1958; ms(39);
  if(balance) $fatal(1,"capture before third scheduled sample");
  ms(1);
  if(!balance || pulse || duty!==0 || state!==4) $fatal(1,"third capture sample must interrupt pulse pair");
  @(negedge clk); adc=2600; ms(10);
  if(!balance) $fatal(1,"BALANCE must retain PID ownership outside capture window");

  restart(800); sample(800); sample(1000); sample(900); ms(100);
  sample(2258); if(balance) $fatal(1,"upper boundary first sample captured early");
  sample(2258); if(balance) $fatal(1,"upper boundary second sample captured early");
  @(negedge clk); adc=2258; ms(20);
  if(!balance || duty!==0) $fatal(1,"upper capture boundary/reverse interruption");
  restart(1200); sample(1658); sample(1658);
  if(balance) $fatal(1,"lower boundary captured early");
  sample(1658);
  if(!balance) $fatal(1,"lower capture boundary");

  // 任一周期采样点离开区间，都打断连续计数；上下边界之外一计数也算出区。
  restart(3000); sample(1958); sample(1958); sample(2259);
  sample(1958); sample(1958);
  if(balance) $fatal(1,"outside upper boundary did not reset capture count");
  sample(1657); sample(1958); sample(1958);
  if(balance) $fatal(1,"outside lower boundary did not reset capture count");
  sample(1958); if(!balance) $fatal(1,"three new consecutive samples failed capture");
  // 短暂进入中心区但没有碰到采样点，不能累计次数。
  restart(3000); @(negedge clk); adc=1958; ms(1);
  @(negedge clk); adc=3000; ms(39);
  if(dut.capture_count!=0 || balance) $fatal(1,"unscheduled center spike counted");
  sample(1958); sample(1958); restart(1958);
  sample(1958); sample(1958);
  if(balance) $fatal(1,"restart retained old capture count");
  sample(1958); if(!balance) $fatal(1,"restart capture failed");

  restart(3000); sample(3000); sample(2800); sample(2900);
  @(negedge clk); enable=0; #2;
  if(duty!==0 || pulse) $fatal(1,"stop did not cancel live pulse");
  ms(1); if(state!==0) $fatal(1,"stop state");
  // Bottom startup: one pair only, exact100ms per phase, then fresh peak detection.
  @(negedge clk); enable=0; adc=0; ms(1);
  @(negedge clk); enable=1; ms(1);
  if(state!==5 || duty!==300 || !pulse) $fatal(1,"bottom startup first phase");
  ms(99); if(state!==5 || duty!==300) $fatal(1,"seed first shorter than100ms");
  ms(1); if(state!==7 || duty!==-300 || !pulse) $fatal(1,"seed reverse transition");
  ms(99); if(state!==7 || duty!==-300) $fatal(1,"seed reverse shorter than100ms");
  ms(1); expect_quiet();
  ms(500); expect_quiet(); // Do not repeat while the ADC remains near bottom.
  // High endpoint and each threshold boundary must also qualify on a new run.
  @(negedge clk); enable=0; adc=4092; ms(1);
  @(negedge clk); enable=1; ms(1);
  if(state!==5 || duty!==300) $fatal(1,"high bottom endpoint not recognized");
  sample(1958); sample(1958);
  if(balance) $fatal(1,"startup captured before third sample");
  sample(1958);
  if(!balance || duty!==0) $fatal(1,"capture must preempt startup nudge");
  @(negedge clk); enable=0; adc=200; ms(1);
  @(negedge clk); enable=1; ms(1);
  if(state!==5) $fatal(1,"lower bottom boundary");
  @(negedge clk); enable=0; #2;
  if(duty!==0) $fatal(1,"disable must cancel startup nudge");
  ms(1);
  restart(201); ms(1); expect_quiet();
  restart(3889); ms(1); expect_quiet();
  @(negedge clk); enable=0; adc=3890; ms(1);
  @(negedge clk); enable=1; ms(1);
  if(state!==5) $fatal(1,"upper bottom boundary");
  ms(100); if(state!==7 || duty!==-300) $fatal(1,"high endpoint seed reverse");
  sample(1958); sample(1958);
  if(balance) $fatal(1,"startup reverse captured before third sample");
  @(negedge clk); adc=1958; ms(18);
  if(balance) $fatal(1,"startup reverse captured before sample boundary");
  ms(1);
  if(!balance || duty!==0 || pulse) $fatal(1,"capture must preempt seed reverse");
  @(negedge clk); enable=0; adc=0; ms(1);
  @(negedge clk); enable=1; ms(101);
  if(state!==7) $fatal(1,"seed reverse setup");
  @(negedge clk); enable=0; #2;
  if(duty!==0 || pulse) $fatal(1,"disable must cancel seed reverse");
  $display("PASS swing_up: three consecutive scheduled capture samples, reset on exit/restart, inclusive boundaries, pulse preemption, peak/timing/stop regression");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

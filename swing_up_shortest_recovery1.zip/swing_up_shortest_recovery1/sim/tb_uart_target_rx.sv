`timescale 1ns/1ps
module tb_uart_target_rx;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,rx=1;
 wire valid;wire [7:0] seq;wire signed [31:0] goal;wire [15:0] speed;
 uart_target_rx dut(.clk(clk),.rst_n(rst_n),.rx(rx),.command_valid(valid),
  .command_seq(seq),.command_goal_q8(goal),.command_step_q8(speed));
 reg [7:0] vector[0:21];integer i,count=0;
 always @(posedge clk) begin #2;if(valid) count=count+1;end
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task byte_send(input [7:0] b,input bit stop_good=1);
  integer j;
  rx=0;clocks(434);
  for(j=0;j<8;j=j+1)begin rx=b[j];clocks(434);end
  rx=stop_good;clocks(434);rx=1;
 endtask
 initial begin
  $readmemh("serial_commands.hex",vector);
  clocks(5);rst_n=1;clocks(5);
  // 毛刺、错误停止位及杂字节都不能产生有效命令。
  rx=0;clocks(20);rx=1;clocks(500);
  byte_send(8'hA5,0);clocks(500);byte_send(8'h45);
  for(i=0;i<11;i=i+1)byte_send(i==10 ? (vector[i]^8'h01) : vector[i]);
  clocks(5);if(count!=0)$fatal(1,"noise or bad checksum accepted");
  // 截断包超时后，下一条完整命令仍可识别。
  for(i=0;i<5;i=i+1)byte_send(vector[i]);clocks(2500010);
  for(i=0;i<11;i=i+1)byte_send(vector[i]);clocks(5);
  if(count!=1 || seq!=17 || goal!=69120 || speed!=346)$fatal(1,"Python positive command decode");
  for(i=11;i<22;i=i+1)byte_send(vector[i]);clocks(5);
  if(count!=2 || seq!=18 || goal!=-138240 || speed!=2765)$fatal(1,"negative signed Q8 command decode at360 degrees/s");
  rst_n=0;clocks(5);if(valid || seq || goal || speed)$fatal(1,"reset not clear");
  $display("PASS UART RX: real115200 Python packets,signed fractional goals,noise,framing,checksum,timeout,resync and reset");$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule

$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 & 'C:/Users/93061/AppData/Local/Programs/Python/Python313/python.exe' make_vectors.py
 if($LASTEXITCODE -ne 0){throw 'vectors failed'}
 & 'C:/Users/93061/AppData/Local/Programs/Python/Python313/python.exe' make_serial_vectors.py
 if($LASTEXITCODE -ne 0){throw 'serial vectors failed'}
 & 'F:/ModelSim_10.4/win64/vsim.exe' -c -l compile_all.log -do run_checks.do > compile_console.log
 if($LASTEXITCODE -ne 0){throw 'compile failed'}
 $tests=@('tb_d_filter','tb_smooth_cascade','tb_swing_up','tb_swing_top',
 'tb_timed_limit','tb_timed_limit_top','tb_move90','tb_move90_top','tb_motion_pd','tb_move90_parameters',
 'tb_outer_integral','tb_outer_integral_top','tb_auto_recover','tb_auto_recover_top','tb_recovery_target','tb_shortest_recovery',
 'tb_motion_load','tb_uart_outer_i','tb_motion_limit','tb_motion_limit_top','tb_motion_arrival_top','tb_disturbance_limit',
 'tb_startup150_once','tb_startup150_top','tb_sine_equivalence','tb_sine_keys_top',
 'tb_uart_target_rx','tb_serial_position','tb_serial_target_top')
 # 基准模块只供仿真，不列入Gowin工程。
 foreach($test in $tests){
  & 'F:/ModelSim_10.4/win64/vsim.exe' -c -onfinish exit -l "$test.log" -do "vsim work.$test; run -all; quit -code 1" > "$test.console.log"
  $body=Get-Content -LiteralPath "$test.log" -Raw
  if($LASTEXITCODE -ne 0 -or $body -notmatch '# PASS' -or $body -match '\*\* (Error|Fatal):'){throw "test failed: $test"}
  Write-Output "PASS $test"
 }
}finally{Pop-Location}

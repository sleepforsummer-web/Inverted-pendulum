module audit_old_pid_p #
(
    parameter signed [31:0] Kp=32'sd524231// Q16比例系数：实际Kp为本参数除以65536
)
(
    input wire clk,//主时钟
    input wire rst,//复位
    input wire enable,//PID正常工作
    input wire sample_tick,// 采样使能脉冲，持续一个主时钟周期
    input wire signed[16:0] error,
    output reg signed[48:0] p,
    output reg p_valid
);
always@(posedge clk)begin
    if(rst||!enable)begin
        p<=49'sd0;
        p_valid<=1'b0;
    end
    else begin
        p_valid<=1'b0;
        if(sample_tick)begin
            p<=error*Kp;
            p_valid<=1'b1;
        end
    end
end
endmodule

module audit_old_pid_d#
(
    parameter signed [31:0] Kd = 32'sd867527,
    // 0关闭滤波；1~8表示新差值权重为1/(2^FILTER_SHIFT)。
    parameter integer FILTER_SHIFT = 0
)
(
    input wire clk,
    input wire rst,
    input wire enable,
    input wire sample_tick,
    input wire signed[16:0] error,
    output reg signed[49:0] d,
    output reg d_valid,
    output wire signed [25:0] velocity_q8_mon
);
    reg signed[16:0] error_prev;
    reg have_prev;
    // 差分前显式扩展，覆盖17位有符号输入两端之间的变化。
    wire signed [17:0] delta = $signed({error[16],error}) -
                               $signed({error_prev[16],error_prev});
    reg signed [17:0] delta_sample;
    reg [1:0] filter_pending;
    // Q8保留不足一个ADC/编码器计数的差值，避免小速度被整数截断。
    // 18位差分乘256恰好需要26位；滤波为凸组合，不会超出差分输入范围。
    reg signed [25:0] filter_q8;
    // 复用D模块现有差分/滤波状态，避免模糊调度器另建速度滤波器。
    assign velocity_q8_mon=(FILTER_SHIFT==0) ? {delta_sample,8'b0} : filter_q8;
    wire signed [25:0] filter_next;
    wire signed [49:0] d_next;
    generate
        if (FILTER_SHIFT == 0) begin : unfiltered
            assign filter_next = 26'sd0;
            assign d_next = delta * Kd;
        end else begin : filtered
            wire signed [25:0] delta_q8 = {delta_sample,8'b0};
            wire signed [26:0] innovation =
                $signed({delta_q8[25],delta_q8}) - $signed({filter_q8[25],filter_q8});
            // 对称四舍五入：正负半数均远离0，避免直接算术右移造成负向偏置。
            wire signed [27:0] magnitude = innovation[26] ?
                -$signed({innovation[26],innovation}) : $signed({innovation[26],innovation});
            wire signed [27:0] rounded =
                (magnitude + (28'sd1 <<< (FILTER_SHIFT-1))) >>> FILTER_SHIFT;
            wire signed [27:0] correction = innovation[26] ? -rounded : rounded;
            wire signed [27:0] candidate =
                $signed({{2{filter_q8[25]}},filter_q8}) + correction;
            // 零速时清除量化残留，使正负方向都能回到真正的0。
            wire clear_residue = (delta_sample == 18'sd0) &&
                (filter_q8 > -(26'sd1 <<< FILTER_SHIFT)) &&
                (filter_q8 <  (26'sd1 <<< FILTER_SHIFT));
            assign filter_next = clear_residue ? 26'sd0 : candidate[25:0];
            // 差分、滤波、乘法分三个主时钟执行，避免单周期组合路径过长。
            // 相比原版只增加两个50MHz时钟（40ns），不是增加两个1ms采样周期。
            wire signed [57:0] product_q24 = filter_q8 * Kd;
            wire signed [57:0] product_q16 = product_q24 >>> 8;
            assign d_next = product_q16[49:0];
        end
    endgenerate
always@(posedge clk)begin
    if(rst||!enable)begin
        error_prev<=17'sd0;
        have_prev<=1'b0;
        filter_q8<=26'sd0;
        delta_sample<=18'sd0;
        filter_pending<=2'b00;
        d<=50'sd0;
        d_valid<=1'b0;
    end
    else begin
        d_valid<=1'b0;
        if(FILTER_SHIFT != 0) begin
            filter_pending <= {filter_pending[0],sample_tick};
            if(filter_pending[0]) filter_q8<=filter_next;
            if(filter_pending[1]) begin
                d<=d_next;
                d_valid<=1'b1;
            end
        end
        if(sample_tick)begin
            delta_sample <= have_prev ? delta : 18'sd0;
            if(FILTER_SHIFT == 0) begin
                d <= have_prev ? d_next : 50'sd0;
                d_valid<=1'b1;
            end
            error_prev<=error;
            have_prev<=1'b1;
        end
    end
end
endmodule

module audit_old_pid_i #(
    parameter signed[31:0] Ki=32'sd33,
    parameter signed[48:0] I_MAX=49'sd6553600,//积分限幅
    parameter signed[16:0] I_SEP_THRESHOLD=17'sd50
)
(
    input wire clk,
    input wire rst,
    input wire enable,
    input wire sample_tick,
    input wire signed[16:0] error,
    output reg signed[48:0] i,
    output reg i_valid
);
    // 依据常数系数和积分上限推导乘加位宽，仍保留完整精度和原来的49位接口。
    function integer gain_bits;
        input signed [31:0] value;
        integer bit_n;
        begin
            gain_bits=32;
            for(bit_n=31;bit_n>=1;bit_n=bit_n-1)
                if((value >>> (bit_n-1))==0 || (value >>> (bit_n-1))==-1) gain_bits=bit_n;
        end
    endfunction
    function integer integral_bits;
        input signed [48:0] limit_value;
        integer bit_n;
        begin
            integral_bits=49;
            if(limit_value>=0)
                for(bit_n=49;bit_n>=1;bit_n=bit_n-1)
                    if(limit_value<=( (64'sd1 << (bit_n-1))-1)) integral_bits=bit_n;
        end
    endfunction
    localparam integer I_BITS=integral_bits(I_MAX);
    localparam integer INCREMENT_BITS=17+gain_bits(Ki);
    localparam integer CANDIDATE_BITS=(I_BITS>INCREMENT_BITS ? I_BITS : INCREMENT_BITS)+1;
    wire signed [INCREMENT_BITS-1:0] increment=Ki*error;
    wire signed [CANDIDATE_BITS-1:0] bounded_candidate /* synthesis syn_dspstyle="logic" */;
    assign bounded_candidate=$signed(i[I_BITS-1:0]) + increment;
    // 小常数积分乘加使用普通逻辑，避免整段49位加法占用专用DSP。
    wire signed[49:0] candidate /* synthesis syn_dspstyle="logic" */;//候选积分
    wire integrate_allowed=(error > -I_SEP_THRESHOLD) && (error < I_SEP_THRESHOLD);
    assign candidate=bounded_candidate;
always@(posedge clk)begin
    if(rst||!enable)begin
        i<=49'sd0;
        i_valid<=1'b0;
    end
    else begin
        i_valid<=1'b0;
        if(sample_tick)begin
           // 积分分离
           if(!integrate_allowed)begin
            i<=49'sd0;
           end
           else if(candidate>I_MAX)begin
            i<=I_MAX;
           end
           else if(candidate<-I_MAX)begin
            i<=-I_MAX;
           end
            else begin
                i <= candidate[48:0];
            end
            i_valid<=1'b1;
        end
    end
end
endmodule


//角度内环
module audit_old_pid_controller #
(
    parameter signed [31:0] KP_Q = 32'sd524231,
    parameter signed [31:0] KD_Q = 32'sd867527,
    parameter integer D_FILTER_SHIFT = 0,
    // 实际输出限幅 ±1000，保存值放大 65536 倍
    parameter signed [50:0] OUT_MAX_Q = 51'sd65536000,
    parameter signed [31:0] KI_Q = 32'sd65,
    parameter signed [16:0] I_SEP_THRESHOLD = 17'sd50,
    // 内环P/I误差限幅，单位为ADC计数；0或负值关闭，D使用独立测量输入。
    parameter signed [16:0] ERROR_INPUT_LIMIT = 17'sd0
)
(
    input wire clk,
    input wire rst,
    input wire enable,
    input wire sample_tick,
    input wire signed [16:0] error,
    input wire signed [16:0] d_input,

    // 定义pid输出以及输出有效
    output reg signed [50:0] pid_sum,
    output reg pid_valid,

    // 监视口: P/I/D 各项 (Q16右移12位, 饱和16bit)
    output reg signed [15:0] p_mon,
    output reg signed [15:0] i_mon,
    output reg signed [15:0] d_mon
);

    // 连接三个子模块的输出
    wire signed [48:0] p;
    wire signed [48:0] i;
    wire signed [49:0] d;

    wire p_valid;
    wire i_valid;
    wire d_valid;

    // 滤波D多用两个主时钟；同步延迟P/I的数据与有效位，保持同一次采样求和。
    wire signed [48:0] p_aligned, i_aligned;
    wire p_aligned_valid, i_aligned_valid;
    generate if(D_FILTER_SHIFT == 0) begin : direct_pi
        assign p_aligned=p; assign i_aligned=i;
        assign p_aligned_valid=p_valid; assign i_aligned_valid=i_valid;
    end else begin : align_pi
        reg signed [48:0] p_d0, p_d1, i_d0, i_d1;
        reg [1:0] pv, iv;
        always @(posedge clk) begin
            if(rst || !enable) begin
                p_d0<=0; p_d1<=0; i_d0<=0; i_d1<=0; pv<=0; iv<=0;
            end else begin
                p_d0<=p; p_d1<=p_d0; i_d0<=i; i_d1<=i_d0;
                pv<={pv[0],p_valid}; iv<={iv[0],i_valid};
            end
        end
        assign p_aligned=p_d1; assign i_aligned=i_d1;
        assign p_aligned_valid=pv[1]; assign i_aligned_valid=iv[1];
    end endgenerate

    wire signed [16:0] error_pi;
    assign error_pi = (ERROR_INPUT_LIMIT <= 17'sd0) ? error :
                     (error > ERROR_INPUT_LIMIT) ? ERROR_INPUT_LIMIT :
                     (error < -ERROR_INPUT_LIMIT) ? -ERROR_INPUT_LIMIT : error;
    // 积分分离按实际误差判定；即使限幅设得比积分阈值小，也不能误开启积分。
    wire signed [16:0] error_i;
    assign error_i = (error > -I_SEP_THRESHOLD && error < I_SEP_THRESHOLD) ? error_pi : error;

    // P模块
    audit_old_pid_p #(.Kp(KP_Q)) u_p (
        .clk(clk),
        .rst(rst),
        .enable(enable),
        .sample_tick(sample_tick),
        .error(error_pi),
        .p(p),
        .p_valid(p_valid)
    );

    // I模块
    audit_old_pid_i #(.Ki(KI_Q), .I_SEP_THRESHOLD(I_SEP_THRESHOLD)) u_i (
        .clk(clk),
        .rst(rst),
        .enable(enable),
        .sample_tick(sample_tick),
        .error(error_i),
        .i(i),
        .i_valid(i_valid)
    );

    // D对独立测量输入d_input做差分，不受P/I误差限幅和外环目标角变化的直接影响。
    audit_old_pid_d #(.Kd(KD_Q), .FILTER_SHIFT(D_FILTER_SHIFT)) u_d (
        .clk(clk),
        .rst(rst),
        .enable(enable),
        .sample_tick(sample_tick),
        .error(d_input),
        .d(d),
        .d_valid(d_valid),.velocity_q8_mon()
    );

    // 先扩展到51位，防止求和溢出
    // 因为右边都是signed，这里自动符号扩展
    wire signed [50:0] p_ext;
    wire signed [50:0] i_ext;
    wire signed [50:0] d_ext;
    // 保持位宽与组合表达式不变，仅指定宽位求和使用逻辑进位链。
    wire signed [50:0] sum_next /* synthesis syn_dspstyle="logic" */;

    assign p_ext = p_aligned;
    assign i_ext = i_aligned;
    assign d_ext = d;

    assign sum_next = p_ext + i_ext + d_ext;

    // 等三个结果同时有效，再保存总和
always @(posedge clk) begin
    if (rst || !enable) begin
        pid_sum   <= 51'sd0;
        pid_valid <= 1'b0;
        p_mon <= 16'sd0;
        i_mon <= 16'sd0;
        d_mon <= 16'sd0;
    end
    else begin
        pid_valid <= 1'b0;

        if (p_aligned_valid && i_aligned_valid && d_valid) begin

            // 超过正向上限
            if (sum_next > OUT_MAX_Q)
                pid_sum <= OUT_MAX_Q;

            // 超过负向下限
            else if (sum_next < -OUT_MAX_Q)
                pid_sum <= -OUT_MAX_Q;

            // 没有超出范围，直接保存求和结果
            else
                pid_sum <= sum_next;

            pid_valid <= 1'b1;

            // 监视输出
            p_mon <= (p_ext >  51'sd134217728) ? 16'sd32767 :
                     (p_ext < -51'sd134217728) ? -16'sd32768 : p_ext[27:12];
            i_mon <= (i_ext >  51'sd134217728) ? 16'sd32767 :
                     (i_ext < -51'sd134217728) ? -16'sd32768 : i_ext[27:12];
            d_mon <= (d_ext >  51'sd134217728) ? 16'sd32767 :
                     (d_ext < -51'sd134217728) ? -16'sd32768 : d_ext[27:12];

        end
    end
end
endmodule

// 角度内环接口：接收绝对ADC目标值和实际测量值。
// 保持既有标定方向：INVERT=1时，正向摆角增大对应ADC减小，
// 因此PID误差为实际ADC减去目标ADC；D项只对带方向的实际测量值做差分。
module audit_old_pid_adc_controller #(
    parameter ADC_INVERT = 1,
    parameter signed [31:0] KP_Q = 32'sd524231,
    parameter signed [31:0] KD_Q = 32'sd867527,
    parameter integer D_FILTER_SHIFT = 0,
    parameter signed [50:0] OUT_MAX_Q = 51'sd65536000,
    parameter signed [31:0] KI_Q = 32'sd65,
    parameter signed [16:0] I_SEP_THRESHOLD = 17'sd50,
    parameter signed [16:0] ERROR_INPUT_LIMIT = 17'sd0
)(
    input wire clk, rst, enable, sample_tick,
    input wire signed [16:0] target_adc,
    input wire signed [16:0] actual_adc,
    output wire signed [16:0] error_out,
    output wire signed [50:0] pid_sum,
    output wire pid_valid,
    output wire signed [15:0] p_mon, i_mon, d_mon
);
    wire signed [16:0] adc_error = target_adc - actual_adc;
    assign error_out = ADC_INVERT ? -adc_error : adc_error;
    // D使用测量值；方向与原来的误差微分保持一致
    wire signed [16:0] d_input;
    assign d_input = ADC_INVERT ? actual_adc : -actual_adc;

    audit_old_pid_controller #(
        .KP_Q(KP_Q), .KD_Q(KD_Q), .D_FILTER_SHIFT(D_FILTER_SHIFT),
        .OUT_MAX_Q(OUT_MAX_Q), .KI_Q(KI_Q),
        .I_SEP_THRESHOLD(I_SEP_THRESHOLD), .ERROR_INPUT_LIMIT(ERROR_INPUT_LIMIT)
    ) inner_pid (
        .clk(clk), .rst(rst), .enable(enable), .sample_tick(sample_tick),
        .error(error_out), .pid_sum(pid_sum), .pid_valid(pid_valid),
        .p_mon(p_mon), .i_mon(i_mon), .d_mon(d_mon),.d_input(d_input)
    );
endmodule

//位置外环
module audit_old_position_controller #(
    // 外环参数，Q16
    parameter signed [31:0] Kp_pos = 32'sd0,  // Q16比例系数：实际Kp为本参数除以65536
    parameter signed [31:0] Kd_pos = 32'sd0, // Q16差分系数：乘相邻外环采样的位置误差变化量
    // theta_ref 限
    parameter signed [16:0] THETA_REF_MAX = 17'sd40,
    parameter integer D_FILTER_SHIFT = 0,
    // 开关关闭时保持固定限幅，便于与原PD对照；顶层显式开启动态限幅。
    parameter LIMIT_SWITCH_ENABLE = 0,
    parameter signed [16:0] THETA_REF_BOOST_MAX = 17'sd80,
    parameter signed [16:0] LIMIT_POSITION_THRESHOLD = 17'sd50,
    parameter integer LIMIT_BOOST_MIN_MS = 1000,
    parameter integer POSITION_SAMPLE_MS = 10,
    // 自动起摆接管时由独立脉冲触发一次150，退出后永久回到常规40/110直到下次起摆。
    parameter STARTUP_BOOST_ENABLE = 0,
    parameter signed [16:0] STARTUP_BOOST_MAX = 17'sd150,
    // 0保留旧双限幅；1在起摆收敛后启用独立的受扰限幅包络。
    parameter DISTURB_LIMIT_ENABLE = 0,
    parameter signed [16:0] DISTURB_LIMIT_MAX = 17'sd200,
    parameter integer DISTURB_LIMIT_RAMP_MS = 1000,
    // 运动目标保留Q16小数；D只对实际位置差分，防止目标运动产生微分冲击。
    parameter USE_Q16_POSITION = 0,
    parameter D_ON_MEASUREMENT = 0,
    parameter signed [31:0] Ki_pos = 32'sd0,
    parameter signed [48:0] I_POS_MAX_Q = 49'sd524288, // 外环I独立限幅±8 ADC，Q16
    parameter signed [16:0] I_POS_SEP_THRESHOLD = 17'sd50, // 圆整位置误差小于50计数才积分
    parameter FUZZY_ENABLE=0,
    parameter integer FUZZY_MAX_DELTA_Q12=2048,
    parameter integer FUZZY_SLEW_Q12=4
)
(
    input  wire clk,
    input  wire rst,
    input  wire enable,
    input  wire sample_tick,

    // 位置误差
    input  wire signed [16:0] position_error,
    input  wire signed [32:0] position_error_q16,
    input  wire signed [16:0] position_measurement,
    input  wire integral_clear, // 运动时清除积分；仍按正常节拍产生有效零I
    input  wire motion_active, // 运动请求至目标轨迹完成：强制小限幅并清除大限幅计时
    input  wire fuzzy_request,
    input  wire startup_boost_arm, // 仅自动起摆进入PID时一拍；默认关闭，不影响旧接口实例

    // 外环输出，给内环作为目标角度
    output reg  signed [16:0] theta_ref,
    output reg                theta_ref_valid,
    // 仅供上位机诊断：P/D项为目标角限幅前的贡献值，采用Q8格式，真实值需除以256。
    output reg signed [31:0] p_pos_mon,
    output reg signed [31:0] d_pos_mon,
    output reg signed [31:0] i_pos_mon,
    output reg              limited_mon,
    // 与theta_ref同一帧的限幅状态；大限幅保持至少1秒且回到阈值内才退出。
    output reg signed [16:0] active_limit_mon,
    output reg              boost_active_mon,
    output reg [12:0]       fuzzy_gain_mon,
    output reg [2:0]        limit_phase_mon // 仅诊断，不参与控制计算
);

    // 进入条件：|位置误差|>50。退出条件：已满1秒 AND |位置误差|<=50。
    // 进入后的计时连续进行，不因提前进入小误差区、再次出区或误差变号而重置。
    localparam integer BOOST_HOLD_TICKS =
        (LIMIT_BOOST_MIN_MS+POSITION_SAMPLE_MS-1)/POSITION_SAMPLE_MS;
    // 计数到门限后饱和，默认100个节拍只需7位；零/负门限沿用原32位语义。
    localparam integer BOOST_COUNT_BITS = BOOST_HOLD_TICKS > 0 ? $clog2(BOOST_HOLD_TICKS+1) : 32;
    wire signed [32:0] limit_position_q16=$signed({LIMIT_POSITION_THRESHOLD,16'b0});
    wire position_outside = USE_Q16_POSITION ?
                            ((position_error_q16>limit_position_q16) ||
                             (position_error_q16< -limit_position_q16)) :
                            ((position_error > LIMIT_POSITION_THRESHOLD) ||
                             (position_error < -LIMIT_POSITION_THRESHOLD));
    reg boost_mode;
    reg startup_boost_active;
    wire startup_requested=STARTUP_BOOST_ENABLE && (startup_boost_active || startup_boost_arm);
    reg [BOOST_COUNT_BITS-1:0] boost_elapsed_ticks;
    reg boost_next;
    reg [BOOST_COUNT_BITS-1:0] elapsed_next;
    always @* begin
        boost_next=boost_mode;
        elapsed_next=boost_elapsed_ticks;
        if(!LIMIT_SWITCH_ENABLE || motion_active) begin boost_next=0; elapsed_next=0; end
        else if(!boost_mode) begin
            elapsed_next=0;
            if(position_outside || startup_requested) boost_next=1;
        end else begin
            if(boost_elapsed_ticks<BOOST_HOLD_TICKS)
                elapsed_next=boost_elapsed_ticks+1'b1;
            // 第一次大限幅样本为t=0；第100个后续10ms节拍恰好满1秒。
            if((BOOST_HOLD_TICKS==0 || boost_elapsed_ticks>=BOOST_HOLD_TICKS-1) &&
               !position_outside) begin boost_next=0; elapsed_next=0; end
        end
    end
    wire signed [16:0] startup_sample_limit = boost_next ?
        (startup_requested ? STARTUP_BOOST_MAX : THETA_REF_BOOST_MAX) : THETA_REF_MAX;
    wire signed [16:0] sample_limit;
    wire sample_boost;
    wire [2:0] sample_phase;
    generate if(DISTURB_LIMIT_ENABLE && LIMIT_SWITCH_ENABLE) begin : disturbance_envelope
        disturbance_limit #(.NEAR_ADC(THETA_REF_MAX),.DISTURB_ADC(DISTURB_LIMIT_MAX),
            .RAMP_MS(DISTURB_LIMIT_RAMP_MS),.SAMPLE_MS(POSITION_SAMPLE_MS),
            .STARTUP_MIN_MS(LIMIT_BOOST_MIN_MS)) envelope(
            .clk(clk),.rst(rst),.enable(enable),.sample_tick(sample_tick),.motion_active(motion_active),
            .position_outside(position_outside),.startup_limit(startup_sample_limit),
            .startup_boost(boost_next),.sample_limit(sample_limit),.sample_boost(sample_boost),
            .sample_phase(sample_phase));
    end else begin : legacy_limit
        assign sample_limit=startup_sample_limit;
        assign sample_boost=boost_next;
        // 旧双限幅只有常规小/大两种状态，不存在等待回区或受扰回落阶段。
        assign sample_phase=LIMIT_SWITCH_ENABLE ?
            ((boost_next && startup_requested) ? 3'd1 : (boost_next ? 3'd7 : 3'd6)) : 3'd0;
    end endgenerate
    reg signed [16:0] limit_d0, limit_d1, limit_d2, limit_d3;
    reg boost_d0, boost_d1, boost_d2, boost_d3;
    reg [2:0] phase_d0, phase_d1, phase_d2, phase_d3;
    wire signed [16:0] aligned_limit = (D_FILTER_SHIFT==0) ? limit_d1 : limit_d3;
    // 运动开始时也覆盖流水线中尚未输出的旧大限幅样本。
    wire signed [16:0] result_limit = motion_active ? THETA_REF_MAX : aligned_limit;
    wire result_boost = !motion_active && ((D_FILTER_SHIFT==0) ? boost_d1 : boost_d3);
    wire [2:0] result_phase=motion_active ? 3'd5 : ((D_FILTER_SHIFT==0) ? phase_d1 : phase_d3);
    always @(posedge clk) begin
        if(rst || !enable) begin
            boost_mode<=0; boost_elapsed_ticks<=0;
            startup_boost_active<=0;
            limit_d0<=THETA_REF_MAX; limit_d1<=THETA_REF_MAX; limit_d2<=THETA_REF_MAX; limit_d3<=THETA_REF_MAX;
            boost_d0<=0; boost_d1<=0; boost_d2<=0; boost_d3<=0;
            phase_d0<=0; phase_d1<=0; phase_d2<=0; phase_d3<=0;
        end else begin
            if(motion_active) startup_boost_active<=0;
            else if(STARTUP_BOOST_ENABLE && startup_boost_arm) startup_boost_active<=1;
            else if(sample_tick && boost_mode && !boost_next) startup_boost_active<=0;
            // 运动期间每个主时钟都清除，不能把运动前/期间的计时带到运动完成之后。
            if(motion_active) begin boost_mode<=0; boost_elapsed_ticks<=0; end
            if(sample_tick) begin
                boost_mode<=boost_next; boost_elapsed_ticks<=elapsed_next;
                limit_d0<=sample_limit;
                boost_d0<=sample_boost;
                phase_d0<=sample_phase;
            end
            // 随同P/D流水线对齐，避免用新样本的限幅裁剪上一组PID结果。
            limit_d1<=limit_d0; limit_d2<=limit_d1; limit_d3<=limit_d2;
            boost_d1<=boost_d0; boost_d2<=boost_d1; boost_d3<=boost_d2;
            phase_d1<=phase_d0; phase_d2<=phase_d1; phase_d3<=phase_d2;
        end
    end

    // -----------------------------
    // 外环 P、D 输出
    // -----------------------------
    reg sample_d;
    reg signed [16:0] position_error_d, derivative_input_d, integral_error_d;
    reg signed [32:0] position_error_q16_d;
    wire signed [48:0] p_pos;
    wire signed [49:0] d_pos;
    wire signed [48:0] i_pos;
    wire signed [25:0] outer_velocity_q8;

    wire p_pos_valid;
    wire d_pos_valid;
    wire i_pos_valid;
    wire signed [48:0] i_pos_aligned;
    wire i_pos_aligned_valid;
    wire signed [48:0] p_pos_aligned;
    wire p_pos_aligned_valid;
    generate if(D_FILTER_SHIFT == 0) begin : direct_outer_p
        assign p_pos_aligned=p_pos;
        assign p_pos_aligned_valid=p_pos_valid;
        assign i_pos_aligned=i_pos;
        assign i_pos_aligned_valid=i_pos_valid;
    end else begin : align_outer_p
        reg signed [48:0] p_d0, p_d1;
        reg [1:0] pv;
        reg signed [48:0] i_d0, i_d1;
        reg [1:0] iv;
        always @(posedge clk) begin
            if(rst || !enable) begin p_d0<=0; p_d1<=0; pv<=0; i_d0<=0; i_d1<=0; iv<=0; end
            else begin
                p_d0<=p_pos; p_d1<=p_d0; pv<={pv[0],p_pos_valid};
                i_d0<=i_pos; i_d1<=i_d0; iv<={iv[0],i_pos_valid};
            end
        end
        assign p_pos_aligned=p_d1;
        assign p_pos_aligned_valid=pv[1];
        assign i_pos_aligned=i_d1;
        assign i_pos_aligned_valid=iv[1];
    end endgenerate

    // -----------------------------
    // 调用原来的 P 模块
    // -----------------------------
    generate if(USE_Q16_POSITION) begin : fractional_position_p
        reg signed [48:0] p_value;
        reg p_valid;
        wire signed [64:0] product = position_error_q16_d*Kp_pos;
        always @(posedge clk) begin
            if(rst || !enable) begin p_value<=0; p_valid<=0; end
            else begin
                p_valid<=sample_d;
                if(sample_d) p_value<=product>>>16;
            end
        end
        assign p_pos=p_value;
        assign p_pos_valid=p_valid;
    end else begin : integer_position_p
    audit_old_pid_p #(
        .Kp(Kp_pos)
    ) u_pos_p (
        .clk        (clk),
        .rst        (rst),
        .enable     (enable),
        .sample_tick(sample_d),
        .error      (position_error_d),

        .p          (p_pos),
        .p_valid    (p_pos_valid)
    );
    end endgenerate

    // -----------------------------
    // 调用原来的 D 模块
    // -----------------------------
    audit_old_pid_d #(
        .Kd(Kd_pos), .FILTER_SHIFT(D_FILTER_SHIFT)
    ) u_pos_d (
        .clk        (clk),
        .rst        (rst),
        .enable     (enable),
        .sample_tick(sample_d),
        .error      (derivative_input_d),

        .d          (d_pos),
        .d_valid    (d_pos_valid),
        .velocity_q8_mon(outer_velocity_q8)
    );

    // -----------------------------
    // 扩展到统一位宽后求和
    // -----------------------------
    // 复用原pid_i，不修改内环。Q16误差正负对称四舍五入，避免负数截断偏置。
    // 小于半个编码器计数不积分；积分分离及I_MAX由原模块执行。
    wire round_integral_up=position_error_q16[15] &&
        (!position_error_q16[32] || (|position_error_q16[14:0]));
    wire signed [17:0] integral_rounded=
        $signed({position_error_q16[32],position_error_q16[32:16]})+
        (round_integral_up ? 18'sd1 : 18'sd0);
    wire signed [16:0] integral_error_q16=
        integral_rounded>18'sd65535 ? 17'sd65535 :
        integral_rounded< -18'sd65536 ? -17'sd65536 : integral_rounded[16:0];
    wire signed [16:0] integral_error=integral_clear ? I_POS_SEP_THRESHOLD :
        (USE_Q16_POSITION ? integral_error_q16 : position_error);
    // 先锁存同一次采样的全部输入，拆开Q16误差换算与积分乘加路径；仅增加20ns。
    always @(posedge clk) begin
        if(rst || !enable) begin
            sample_d<=0; position_error_d<=0; derivative_input_d<=0;
            integral_error_d<=0; position_error_q16_d<=0;
        end else begin
            sample_d<=sample_tick;
            if(sample_tick) begin
                position_error_d<=position_error; position_error_q16_d<=position_error_q16;
                derivative_input_d<=D_ON_MEASUREMENT ? position_measurement : position_error;
                integral_error_d<=integral_error;
            end
        end
    end
    audit_old_pid_i #(.Ki(Ki_pos),.I_MAX(I_POS_MAX_Q),.I_SEP_THRESHOLD(I_POS_SEP_THRESHOLD)) u_pos_i(
        .clk(clk),.rst(rst),.enable(enable),.sample_tick(sample_d),.error(integral_error_d),
        .i(i_pos),.i_valid(i_pos_valid));

    wire signed [50:0] p_pos_ext ={{2{p_pos_aligned[48]}}, p_pos_aligned};

    wire signed [50:0] d_pos_ext ={{1{d_pos[49]}}, d_pos};
    wire signed [50:0] i_pos_ext ={{2{i_pos_aligned[48]}}, i_pos_aligned};

    wire original_valid=p_pos_aligned_valid && i_pos_aligned_valid && d_pos_valid;
    function integer fuzzy_gain_bits;
        input signed [31:0] value;
        integer bit_n;
        begin
            fuzzy_gain_bits=32;
            for(bit_n=31;bit_n>=1;bit_n=bit_n-1)
                if((value >>> (bit_n-1))==0 || (value >>> (bit_n-1))==-1) fuzzy_gain_bits=bit_n;
        end
    endfunction
    localparam integer FUZZY_P_WIDTH=17+fuzzy_gain_bits(Kp_pos);
    localparam integer FUZZY_D_WIDTH=18+fuzzy_gain_bits(Kd_pos);
    // 另留一位给小于2.0的倍率；当前参数只需41位，省去无效高位寄存器/加法。
    localparam integer FUZZY_WIDTH=(FUZZY_P_WIDTH>FUZZY_D_WIDTH ? FUZZY_P_WIDTH : FUZZY_D_WIDTH)+1;
    wire signed [50:0] selected_p,selected_d;
    wire selected_valid;
    wire [12:0] selected_gain;
    generate if(FUZZY_ENABLE) begin : fuzzy_outer
        audit_old_fuzzy_pd #(.DATA_WIDTH(FUZZY_WIDTH),.MAX_DELTA_Q12(FUZZY_MAX_DELTA_Q12),.SLEW_Q12(FUZZY_SLEW_Q12)) scaler(
            .clk(clk),.rst(rst),.enable(enable),.in_valid(original_valid),
            .adaptive_request(fuzzy_request),
            .error_q16(USE_Q16_POSITION ? position_error_q16_d : {position_error_d,16'b0}),
            .velocity_q8(outer_velocity_q8),.p_in(p_pos_ext),.d_in(d_pos_ext),
            .p_out(selected_p),.d_out(selected_d),.out_valid(selected_valid),.gain_q12(selected_gain));
    end else begin : fixed_outer
        assign selected_p=p_pos_ext;assign selected_d=d_pos_ext;
        assign selected_valid=original_valid;assign selected_gain=13'd4096;
    end endgenerate
    wire signed [50:0] pos_sum_q /* synthesis syn_dspstyle="logic" */;
    assign pos_sum_q =selected_p + i_pos_ext + selected_d;

    // Q16还原
    wire signed [34:0] theta_ref_calc =pos_sum_q >>> 16;
    wire signed [50:0] p_pos_q8 = selected_p >>> 8;
    wire signed [50:0] d_pos_q8 = selected_d >>> 8;
    wire signed [50:0] i_pos_q8 = i_pos_ext >>> 8;

    // -----------------------------
    // 输出 theta_ref + 限幅
    // -----------------------------
    always @(posedge clk) begin
        if(rst || !enable) begin
            theta_ref       <= 17'sd0;
            theta_ref_valid <= 1'b0;
            p_pos_mon <= 32'sd0;
            d_pos_mon <= 32'sd0;
            i_pos_mon <= 32'sd0;
            limited_mon <= 1'b0;
            active_limit_mon <= THETA_REF_MAX;
            boost_active_mon <= 1'b0;
            fuzzy_gain_mon <= 13'd4096;
            limit_phase_mon <= 3'd0;
        end

        else begin
            theta_ref_valid <= 1'b0;

            if(selected_valid) begin
                fuzzy_gain_mon<=selected_gain;
                p_pos_mon <= (p_pos_q8 > 51'sd2147483647) ? 32'sd2147483647 :
                             (p_pos_q8 < -51'sd2147483648) ? -32'sd2147483648 : p_pos_q8[31:0];
                d_pos_mon <= (d_pos_q8 > 51'sd2147483647) ? 32'sd2147483647 :
                             (d_pos_q8 < -51'sd2147483648) ? -32'sd2147483648 : d_pos_q8[31:0];
                i_pos_mon <= (i_pos_q8 > 51'sd2147483647) ? 32'sd2147483647 :
                             (i_pos_q8 < -51'sd2147483648) ? -32'sd2147483648 : i_pos_q8[31:0];
                active_limit_mon <= result_limit;
                limit_phase_mon <= result_phase;
                boost_active_mon <= LIMIT_SWITCH_ENABLE && result_boost;
                limited_mon <= (theta_ref_calc > result_limit) || (theta_ref_calc < -result_limit);

                if(theta_ref_calc > result_limit)
                    theta_ref <= result_limit;

                else if(theta_ref_calc < -result_limit)
                    theta_ref <= -result_limit;

                else
                    theta_ref <= theta_ref_calc[16:0];

                theta_ref_valid <= 1'b1;
            end
        end
    end

endmodule

// 外环共同倍率模糊PD。输入P/D为原参数计算的Q16贡献，I完全不参与缩放。
// 等间距三角隶属度+可分离Sugeno后件，离线化简为两张小的一维表。
// 两项共用一套移位加法器；不增加动态Kp/Kd大乘法器、不占新增DSP。
module audit_old_fuzzy_pd #(
 parameter integer DATA_WIDTH=51, // 由外环常数系数推导实际所需位宽
 parameter integer MAX_DELTA_Q12=2048, // 最大lambda=1.5；支持0~4095，位宽自动推导
 parameter integer SLEW_Q12=4         // 每10ms倍率最多变化4/4096
)(
 input wire clk,rst,enable,in_valid,adaptive_request,
 input wire signed [32:0] error_q16,
 input wire signed [25:0] velocity_q8,
 input wire signed [50:0] p_in,d_in,
 output reg signed [50:0] p_out,d_out,
 output reg out_valid,
 output reg [12:0] gain_q12
);
 // Q12增量最多12位，倍率本身仍由13位表示1.0~小于2.0。
 localparam integer DELTA_BITS=MAX_DELTA_Q12>0 ? $clog2(MAX_DELTA_Q12+1) : 1;
 localparam integer COUNT_BITS=DELTA_BITS>1 ? $clog2(DELTA_BITS) : 1;
 localparam integer EFFECTIVE_SLEW=SLEW_Q12>MAX_DELTA_Q12 ? MAX_DELTA_Q12 : SLEW_Q12;
 wire [32:0] error_abs=error_q16[32] ? -error_q16 : error_q16;
 wire [25:0] velocity_abs=velocity_q8[25] ? -velocity_q8 : velocity_q8;
 wire [6:0] error_index=error_abs>=33'd5242880 ? 7'd80 : error_abs[22:16];
 // 速度表分辨率为1/4计数每10ms；超过8计数每10ms按端点处理。
 wire [5:0] speed_index=velocity_abs>=26'd2048 ? 6'd32 : {1'b0,velocity_abs[10:6]};
 // RULE_FUNCTIONS：由脚本生成常量表；除法只在编译期计算，不综合除法器。
 function [DELTA_BITS-1:0] error_rule;
  input [6:0] index;
  begin
   case(index)
    7'd0: error_rule=(MAX_DELTA_Q12*2*0+200)/400;
    7'd1: error_rule=(MAX_DELTA_Q12*2*1+200)/400;
    7'd2: error_rule=(MAX_DELTA_Q12*2*2+200)/400;
    7'd3: error_rule=(MAX_DELTA_Q12*2*3+200)/400;
    7'd4: error_rule=(MAX_DELTA_Q12*2*4+200)/400;
    7'd5: error_rule=(MAX_DELTA_Q12*2*5+200)/400;
    7'd6: error_rule=(MAX_DELTA_Q12*2*6+200)/400;
    7'd7: error_rule=(MAX_DELTA_Q12*2*7+200)/400;
    7'd8: error_rule=(MAX_DELTA_Q12*2*8+200)/400;
    7'd9: error_rule=(MAX_DELTA_Q12*2*9+200)/400;
    7'd10: error_rule=(MAX_DELTA_Q12*2*10+200)/400;
    7'd11: error_rule=(MAX_DELTA_Q12*2*11+200)/400;
    7'd12: error_rule=(MAX_DELTA_Q12*2*12+200)/400;
    7'd13: error_rule=(MAX_DELTA_Q12*2*13+200)/400;
    7'd14: error_rule=(MAX_DELTA_Q12*2*14+200)/400;
    7'd15: error_rule=(MAX_DELTA_Q12*2*15+200)/400;
    7'd16: error_rule=(MAX_DELTA_Q12*2*16+200)/400;
    7'd17: error_rule=(MAX_DELTA_Q12*2*17+200)/400;
    7'd18: error_rule=(MAX_DELTA_Q12*2*18+200)/400;
    7'd19: error_rule=(MAX_DELTA_Q12*2*19+200)/400;
    7'd20: error_rule=(MAX_DELTA_Q12*2*20+200)/400;
    7'd21: error_rule=(MAX_DELTA_Q12*2*21+200)/400;
    7'd22: error_rule=(MAX_DELTA_Q12*2*22+200)/400;
    7'd23: error_rule=(MAX_DELTA_Q12*2*23+200)/400;
    7'd24: error_rule=(MAX_DELTA_Q12*2*24+200)/400;
    7'd25: error_rule=(MAX_DELTA_Q12*2*25+200)/400;
    7'd26: error_rule=(MAX_DELTA_Q12*2*26+200)/400;
    7'd27: error_rule=(MAX_DELTA_Q12*2*27+200)/400;
    7'd28: error_rule=(MAX_DELTA_Q12*2*28+200)/400;
    7'd29: error_rule=(MAX_DELTA_Q12*2*29+200)/400;
    7'd30: error_rule=(MAX_DELTA_Q12*2*30+200)/400;
    7'd31: error_rule=(MAX_DELTA_Q12*2*31+200)/400;
    7'd32: error_rule=(MAX_DELTA_Q12*2*32+200)/400;
    7'd33: error_rule=(MAX_DELTA_Q12*2*33+200)/400;
    7'd34: error_rule=(MAX_DELTA_Q12*2*34+200)/400;
    7'd35: error_rule=(MAX_DELTA_Q12*2*35+200)/400;
    7'd36: error_rule=(MAX_DELTA_Q12*2*36+200)/400;
    7'd37: error_rule=(MAX_DELTA_Q12*2*37+200)/400;
    7'd38: error_rule=(MAX_DELTA_Q12*2*38+200)/400;
    7'd39: error_rule=(MAX_DELTA_Q12*2*39+200)/400;
    7'd40: error_rule=(MAX_DELTA_Q12*2*40+200)/400;
    7'd41: error_rule=(MAX_DELTA_Q12*2*41+200)/400;
    7'd42: error_rule=(MAX_DELTA_Q12*2*42+200)/400;
    7'd43: error_rule=(MAX_DELTA_Q12*2*43+200)/400;
    7'd44: error_rule=(MAX_DELTA_Q12*2*44+200)/400;
    7'd45: error_rule=(MAX_DELTA_Q12*2*45+200)/400;
    7'd46: error_rule=(MAX_DELTA_Q12*2*46+200)/400;
    7'd47: error_rule=(MAX_DELTA_Q12*2*47+200)/400;
    7'd48: error_rule=(MAX_DELTA_Q12*2*48+200)/400;
    7'd49: error_rule=(MAX_DELTA_Q12*2*49+200)/400;
    7'd50: error_rule=(MAX_DELTA_Q12*2*50+200)/400;
    7'd51: error_rule=(MAX_DELTA_Q12*2*51+200)/400;
    7'd52: error_rule=(MAX_DELTA_Q12*2*52+200)/400;
    7'd53: error_rule=(MAX_DELTA_Q12*2*53+200)/400;
    7'd54: error_rule=(MAX_DELTA_Q12*2*54+200)/400;
    7'd55: error_rule=(MAX_DELTA_Q12*2*55+200)/400;
    7'd56: error_rule=(MAX_DELTA_Q12*2*56+200)/400;
    7'd57: error_rule=(MAX_DELTA_Q12*2*57+200)/400;
    7'd58: error_rule=(MAX_DELTA_Q12*2*58+200)/400;
    7'd59: error_rule=(MAX_DELTA_Q12*2*59+200)/400;
    7'd60: error_rule=(MAX_DELTA_Q12*2*60+200)/400;
    7'd61: error_rule=(MAX_DELTA_Q12*2*61+200)/400;
    7'd62: error_rule=(MAX_DELTA_Q12*2*62+200)/400;
    7'd63: error_rule=(MAX_DELTA_Q12*2*63+200)/400;
    7'd64: error_rule=(MAX_DELTA_Q12*2*64+200)/400;
    7'd65: error_rule=(MAX_DELTA_Q12*2*65+200)/400;
    7'd66: error_rule=(MAX_DELTA_Q12*2*66+200)/400;
    7'd67: error_rule=(MAX_DELTA_Q12*2*67+200)/400;
    7'd68: error_rule=(MAX_DELTA_Q12*2*68+200)/400;
    7'd69: error_rule=(MAX_DELTA_Q12*2*69+200)/400;
    7'd70: error_rule=(MAX_DELTA_Q12*2*70+200)/400;
    7'd71: error_rule=(MAX_DELTA_Q12*2*71+200)/400;
    7'd72: error_rule=(MAX_DELTA_Q12*2*72+200)/400;
    7'd73: error_rule=(MAX_DELTA_Q12*2*73+200)/400;
    7'd74: error_rule=(MAX_DELTA_Q12*2*74+200)/400;
    7'd75: error_rule=(MAX_DELTA_Q12*2*75+200)/400;
    7'd76: error_rule=(MAX_DELTA_Q12*2*76+200)/400;
    7'd77: error_rule=(MAX_DELTA_Q12*2*77+200)/400;
    7'd78: error_rule=(MAX_DELTA_Q12*2*78+200)/400;
    7'd79: error_rule=(MAX_DELTA_Q12*2*79+200)/400;
    7'd80: error_rule=(MAX_DELTA_Q12*2*80+200)/400;
    default: error_rule=0;
   endcase
  end
 endfunction
 function [DELTA_BITS-1:0] speed_rule;
  input [5:0] index;
  begin
   case(index)
    6'd0: speed_rule=(MAX_DELTA_Q12*3*0+80)/160;
    6'd1: speed_rule=(MAX_DELTA_Q12*3*1+80)/160;
    6'd2: speed_rule=(MAX_DELTA_Q12*3*2+80)/160;
    6'd3: speed_rule=(MAX_DELTA_Q12*3*3+80)/160;
    6'd4: speed_rule=(MAX_DELTA_Q12*3*4+80)/160;
    6'd5: speed_rule=(MAX_DELTA_Q12*3*5+80)/160;
    6'd6: speed_rule=(MAX_DELTA_Q12*3*6+80)/160;
    6'd7: speed_rule=(MAX_DELTA_Q12*3*7+80)/160;
    6'd8: speed_rule=(MAX_DELTA_Q12*3*8+80)/160;
    6'd9: speed_rule=(MAX_DELTA_Q12*3*9+80)/160;
    6'd10: speed_rule=(MAX_DELTA_Q12*3*10+80)/160;
    6'd11: speed_rule=(MAX_DELTA_Q12*3*11+80)/160;
    6'd12: speed_rule=(MAX_DELTA_Q12*3*12+80)/160;
    6'd13: speed_rule=(MAX_DELTA_Q12*3*13+80)/160;
    6'd14: speed_rule=(MAX_DELTA_Q12*3*14+80)/160;
    6'd15: speed_rule=(MAX_DELTA_Q12*3*15+80)/160;
    6'd16: speed_rule=(MAX_DELTA_Q12*3*16+80)/160;
    6'd17: speed_rule=(MAX_DELTA_Q12*3*17+80)/160;
    6'd18: speed_rule=(MAX_DELTA_Q12*3*18+80)/160;
    6'd19: speed_rule=(MAX_DELTA_Q12*3*19+80)/160;
    6'd20: speed_rule=(MAX_DELTA_Q12*3*20+80)/160;
    6'd21: speed_rule=(MAX_DELTA_Q12*3*21+80)/160;
    6'd22: speed_rule=(MAX_DELTA_Q12*3*22+80)/160;
    6'd23: speed_rule=(MAX_DELTA_Q12*3*23+80)/160;
    6'd24: speed_rule=(MAX_DELTA_Q12*3*24+80)/160;
    6'd25: speed_rule=(MAX_DELTA_Q12*3*25+80)/160;
    6'd26: speed_rule=(MAX_DELTA_Q12*3*26+80)/160;
    6'd27: speed_rule=(MAX_DELTA_Q12*3*27+80)/160;
    6'd28: speed_rule=(MAX_DELTA_Q12*3*28+80)/160;
    6'd29: speed_rule=(MAX_DELTA_Q12*3*29+80)/160;
    6'd30: speed_rule=(MAX_DELTA_Q12*3*30+80)/160;
    6'd31: speed_rule=(MAX_DELTA_Q12*3*31+80)/160;
    6'd32: speed_rule=(MAX_DELTA_Q12*3*32+80)/160;
    default: speed_rule=0;
   endcase
  end
 endfunction
 wire [DELTA_BITS:0] table_delta={1'b0,error_rule(error_index)}+{1'b0,speed_rule(speed_index)};
 localparam [DELTA_BITS-1:0] MAX_DELTA=MAX_DELTA_Q12;
 localparam [DELTA_BITS:0] SLEW=EFFECTIVE_SLEW;
 wire [DELTA_BITS-1:0] target_delta=adaptive_request ?
     (table_delta>MAX_DELTA ? MAX_DELTA : table_delta[DELTA_BITS-1:0]) : {DELTA_BITS{1'b0}};
 reg [DELTA_BITS-1:0] delta_state;
 reg [DELTA_BITS-1:0] delta_next;
 wire [DELTA_BITS:0] slew_up={1'b0,delta_state}+SLEW;
 wire [DELTA_BITS:0] slew_down={1'b0,delta_state}-SLEW;
 always @* begin
  if({1'b0,target_delta}>slew_up) delta_next=slew_up[DELTA_BITS-1:0];
  else if({1'b0,delta_state}>{1'b0,target_delta}+SLEW) delta_next=slew_down[DELTA_BITS-1:0];
  else delta_next=target_delta;
 end
 reg busy,doing_d;
 reg [COUNT_BITS-1:0] bit_count;
 reg [DELTA_BITS-1:0] factor_bits,factor_hold;
 reg signed [DATA_WIDTH-1:0] operand,d_hold,acc;
 wire signed [DATA_WIDTH:0] add_step /* synthesis syn_dspstyle="logic" */;
 assign add_step=$signed({acc[DATA_WIDTH-1],acc})+
                 (factor_bits[0] ? $signed({operand[DATA_WIDTH-1],operand}) : {(DATA_WIDTH+1){1'b0}});
 wire signed [DATA_WIDTH-1:0] acc_next=add_step>>>1;
 wire signed [DATA_WIDTH-1:0] correction=acc_next>>>(12-DELTA_BITS);
 wire signed [DATA_WIDTH-1:0] scaled /* synthesis syn_dspstyle="logic" */;
 assign scaled=operand+correction;
 // N次LSB优先右移累加后再右移(12-N)位，始终计算Q12增量。默认N=12。
 // 正负数都等价于operand+floor(operand*delta/4096)，保留原Q16精度。
 always @(posedge clk) begin
  if(rst || !enable) begin
   delta_state<=0;busy<=0;doing_d<=0;bit_count<=0;factor_bits<=0;factor_hold<=0;
   operand<=0;d_hold<=0;acc<=0;p_out<=0;d_out<=0;out_valid<=0;gain_q12<=13'd4096;
  end else begin
   out_valid<=0;
   if(in_valid && !busy) begin
    delta_state<=delta_next;gain_q12<=13'd4096+delta_next;
    if(delta_next==0) begin p_out<=p_in;d_out<=d_in;out_valid<=1;end
    else begin
     busy<=1;doing_d<=0;bit_count<=0;operand<=p_in[DATA_WIDTH-1:0];d_hold<=d_in[DATA_WIDTH-1:0];acc<=0;
     factor_bits<=delta_next;factor_hold<=delta_next;
    end
   end else if(busy) begin
    acc<=acc_next;factor_bits<=factor_bits>>1;
    if(bit_count==DELTA_BITS-1) begin
     if(!doing_d) begin
      p_out<=scaled;operand<=d_hold;acc<=0;factor_bits<=factor_hold;
      bit_count<=0;doing_d<=1;
     end else begin d_out<=scaled;busy<=0;out_valid<=1;end
    end else bit_count<=bit_count+1'b1;
   end
  end
 end
endmodule

// 板载J6第一位：两级同步、稳定20ms后确认；复位默认固定PD。
module audit_old_fuzzy_switch #(parameter integer DEBOUNCE_CYCLES=1000000)(
 input wire clk,rst_n,dip_n,
 output wire adaptive_request
);
 localparam integer CW=DEBOUNCE_CYCLES>1 ? $clog2(DEBOUNCE_CYCLES) : 1;
 reg meta,sync,accepted;
 reg [CW-1:0] count;
 assign adaptive_request=~accepted;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin meta<=1;sync<=1;accepted<=1;count<=0;end
  else begin
   meta<=dip_n;sync<=meta;
   if(sync==accepted) count<=0;
   else if(count==DEBOUNCE_CYCLES-1) begin accepted<=sync;count<=0;end
   else count<=count+1'b1;
  end
 end
endmodule

module audit_old_pid_trial #(
 parameter integer KEY_DEBOUNCE_CYCLES=1000000, // 50MHz主时钟下，对应20ms按键消抖
 parameter AUTO_RECOVER_ENABLE=1,              // 失稳自动恢复开关；0保留原来的越界停机不重启
 parameter signed [15:0] RECOVER_SPEED_MAX=16'sd6, // 旋臂速度门限，计数/10ms
 parameter integer RECOVER_LOW_SAMPLES=20      // 连续低速采样次数，20次约200ms
)(
 input wire clk_50m, rst_n,
 input wire [9:0] adc_data_in,
 input wire [3:0] key_sw, // KEY4在PID运行时启动单次90°运动，无LED联动
 input wire fuzzy_sw_n, // J6第一位W20：OFF=1固定PD，ON=0共同倍率自适应PD

 // 旋臂编码器
 input wire enc_a,
 input wire enc_b,

 output wire adc_clk, adc_oe_n,
 output wire uart_tx,
 output wire PWMA, AN1, AN2, PWMB, BN1, BN2
);
 // 统一的竖直向上标定值，同时用于ADC角度换算和内环目标角。
 localparam [11:0] UPRIGHT_ADC = 12'd1957;
 // MATLAB平滑D候选参数，Q16值=实际系数乘65536后取整。
 // 所有调参统一改这里；Kd必须与下方滤波配置配套使用。
 localparam signed [31:0] INNER_KP_Q = 32'sd406323;  // Kp约6.2
 localparam signed [31:0] INNER_KI_Q = 32'sd0;       // 关闭积分
 localparam signed [31:0] INNER_KD_Q = 32'sd9029312; // Kd约137.7764，乘每1ms实际角度差值
 localparam integer INNER_D_FILTER_SHIFT = 2;      // 新差值权重1/4，Q8滤波状态
 localparam signed [31:0] OUTER_KP_Q = 32'sd19661;  // Kp约0.3，保留用户当前值
 localparam signed [31:0] OUTER_KD_Q = 32'sd1564112; // Kd约23.8665，乘每10ms实际位置差值
 localparam integer OUTER_D_FILTER_SHIFT = 2;      // 新差值权重1/2
 // 模糊共同倍率lambda=1+delta/4096；当前上限1.5，两项同比缩放。
 localparam integer FUZZY_MAX_DELTA_Q12=2048; // 支持0~4095；上限=1+本参数/4096，自动扩展位宽
 localparam integer FUZZY_SLEW_Q12=20; // 每10ms最多变化4/4096，切回固定PD也平滑退回
 wire fuzzy_request;
 wire [12:0] fuzzy_gain_q12;
 audit_old_fuzzy_switch #(.DEBOUNCE_CYCLES(KEY_DEBOUNCE_CYCLES)) fuzzy_mode(
  .clk(clk_50m),.rst_n(rst_n),.dip_n(fuzzy_sw_n),.adaptive_request(fuzzy_request));
 // 外环积分复用pid_i：增量=Ki×位置误差，每10ms执行一次，贡献单位为目标角ADC。
 localparam signed [31:0] OUTER_KI_Q = 32'sd80; // 约0.001/采样；设0关闭外环积分
 localparam signed [48:0] OUTER_I_MAX_Q = 49'sd786432; // 12×65536，积分贡献限幅±12 ADC
 localparam signed [16:0] OUTER_I_SEP_COUNTS = 17'sd50; // 圆整误差绝对值<50才积分，否则清零
 // 外环限幅切换：位置误差按编码器计数，倾角限幅按ADC计数，时间按毫秒。
 localparam signed [16:0] OUTER_LIMIT_NEAR_ADC = 17'sd40;//外环目标角小限幅
 localparam signed [16:0] OUTER_LIMIT_FAR_ADC = 17'sd200;//起摆和受扰统一使用110，不平滑
 localparam signed [16:0] OUTER_LIMIT_POSITION_COUNTS = 17'sd10;
 localparam integer OUTER_LIMIT_MIN_MS = 1000;
 localparam integer OUTER_SAMPLE_MS = 10; // 与下方100Hz位置节拍一致，不单独改此值
 // 只在自动起摆/自动恢复接管PID时执行一次；与常规110共用原时间和位置退出条件。
 localparam OUTER_STARTUP_LIMIT_ENABLE = 1;
 localparam signed [16:0] OUTER_STARTUP_LIMIT_ADC = 17'sd150;
 // 已恢复原40/110双限幅；下面的200包络关闭，不参与实际控制或综合。
 localparam OUTER_DISTURB_LIMIT_ENABLE = 0;
 localparam signed [16:0] OUTER_DISTURB_LIMIT_ADC = 17'sd200;
 localparam integer OUTER_DISTURB_RAMP_MS = 1000; // 包络关闭时此值不生效
 localparam signed [16:0] MOTION_ARRIVE_COUNTS = 17'sd50; // 轨迹完成后，实际旋臂进入目标±50计数才退出运动小限幅
 // 起摆参数：角度采用ADC计数，时间采用毫秒，幅值采用电机指令单位。
 localparam [11:0] CAPTURE_RANGE = 12'd250;//切换PID
 localparam integer SWING_SAMPLE_MS = 20;
 localparam integer SWING_PULSE_MS = 100;
 localparam signed [16:0] SWING_DUTY = 17'sd550; // 最高点驱动幅值；500指令约对应40%占空比
 localparam LEFT_FIRST_POSITIVE = 0; // 保留用户方向设置：左侧先负后正，右侧相反
 // 自动模式在底部附近启动时，先执行一次初始正反双脉冲。
 localparam signed [16:0] START_KICK_DUTY = 17'sd700; // 初始驱动幅值，约56%占空比；设0关闭
 localparam integer START_KICK_MS = 200; // 每段200ms，合计400ms；中心捕获或停机可提前结束
 localparam START_KICK_POSITIVE = 1;
 localparam [11:0] START_BOTTOM_LOW = 12'd100;
 localparam [11:0] START_BOTTOM_HIGH = 12'd3990;
 wire [2:0] swing_state;
 wire balance_mode, swing_pulse_active, swing_peak;
 wire [1:0] swing_peak_region;
 wire signed [16:0] swing_duty;
 wire adc_valid;
 // 直接用状态判断是否由PID接管，避免与受角度保护影响的使能信号形成组合依赖。
 reg manual_mode=0;
 wire balance_active = manual_mode || (swing_state == 3'd4);
 wire signed [12:0] theta;
 // KEY1启动自动起摆；KEY3在手动扶好摆杆后直接启动PID。
 // 运行时KEY1和KEY3均用于停机；KEY2始终用于停机或禁止启动。
 // 角度失稳停机后，自动恢复模块仅在旋臂连续低速时请求重新起摆。
 // 等待期间KEY1/KEY2/KEY3均取消恢复；人工停机不会触发自动恢复。
 // 再次接受KEY1按下之前，必须先完成松开消抖。
 reg [2:0] key_meta=3'b111, key_sync=3'b111;
 reg [19:0] press_count=0, release_count=0;
 reg press_ready=0;
 reg [19:0] key3_press_count=0, key3_release_count=0;
 reg key3_press_ready=0;
 reg running=0;
 // KEY2电平连续变化20ms才确认，短暂低电平毛刺不会撤销运行使能。
 reg key2_released=1'b1;
 reg [19:0] key2_debounce_count=0;
 // 停机原因锁存至下次成功启动或复位：1为KEY1，2为KEY2，3为角度越界，4为KEY3。
 reg [7:0] stop_reason=0;
 reg signed [12:0] stop_theta=0;
 wire [11:0] raw, filtered_raw;
 wire [11:0] adc_block_min, adc_block_max;
 wire [17:0] adc_block_sum;
 wire [7:0] adc_block_count;
 reg [11:0] stop_min=0, stop_max=0;
 reg [17:0] stop_sum=0;
 reg [7:0] stop_count=0;
 reg [11:0] stop_raw=0, stop_filtered_raw=0;
 reg [2:0] stop_keys=3'b111; // 停机时的同步按键电平：第0/1/2位对应KEY1/2/3，低电平为按下
 localparam signed [12:0] STOP_THRESHOLD=13'sd1000; // PID模式停机阈值，单位为ADC计数，不是度数
 wire in_range=(theta > -STOP_THRESHOLD && theta < STOP_THRESHOLD);
 wire press_event=press_ready && !key_sync[0] && press_count==KEY_DEBOUNCE_CYCLES-1;
 wire key3_press_event=key3_press_ready && !key_sync[2] &&
                       key3_press_count==KEY_DEBOUNCE_CYCLES-1;
 // 停机时两个启动键同时按下不启动；运行时任意一个按下都停机。
 wire auto_start=press_event && !key3_press_event;
 wire manual_start=key3_press_event && !press_event && in_range;
 wire angle_stop=balance_active && !in_range;
 wire enable=rst_n && running && key2_released && !angle_stop;
 wire pid_enable=enable && balance_active;
 wire recovery_waiting, recovery_restart;
 // 只在自动恢复成功捕获直立时重设目标；首次手动/自动启动仍保留原零点。
 reg recovery_anchor_pending=0;
 wire recovery_load_target=recovery_anchor_pending && pid_enable;
 wire control_enable=pid_enable && !recovery_anchor_pending;
 reg control_enable_d=0;
 always @(posedge clk_50m or negedge rst_n)
  if(!rst_n) control_enable_d<=0;
  else control_enable_d<=control_enable;
 wire startup_once_arm=control_enable && !control_enable_d && !manual_mode;
 always @(posedge clk_50m or negedge rst_n) begin
  if(!rst_n) recovery_anchor_pending<=0;
  else if(recovery_restart && !running) recovery_anchor_pending<=1;
  else if(!running || recovery_load_target) recovery_anchor_pending<=0;
 end
 always @(posedge clk_50m or negedge rst_n) begin
  if(!rst_n) begin
   key_meta<=7; key_sync<=7; press_count<=0; release_count<=0;
   press_ready<=0; running<=0; manual_mode<=0;
   key3_press_count<=0; key3_release_count<=0; key3_press_ready<=0;
   key2_released<=1'b1; key2_debounce_count<=0;
   stop_reason<=0; stop_theta<=0; stop_keys<=3'b111;
   stop_raw<=0; stop_filtered_raw<=0;
   stop_min<=0; stop_max<=0; stop_sum<=0; stop_count<=0;
  end
  else 
    begin
   key_meta<=key_sw[2:0]; key_sync<=key_meta;
   if(key_sync[1]==key2_released) key2_debounce_count<=0;
   else if(key2_debounce_count==KEY_DEBOUNCE_CYCLES-1) begin
    key2_released<=key_sync[1]; key2_debounce_count<=0;
   end
   else key2_debounce_count<=key2_debounce_count+1'b1;
   if(key_sync[0]) 
   begin
    press_count<=0;
    if(release_count<KEY_DEBOUNCE_CYCLES) release_count<=release_count+1'b1;
    if(release_count==KEY_DEBOUNCE_CYCLES-1) press_ready<=1;
   end
    else
       begin
    release_count<=0;
    if(press_count<KEY_DEBOUNCE_CYCLES) press_count<=press_count+1'b1;
   if(press_event) press_ready<=0;
   end
   if(key_sync[2]) begin
    key3_press_count<=0;
    if(key3_release_count<KEY_DEBOUNCE_CYCLES)
     key3_release_count<=key3_release_count+1'b1;
    if(key3_release_count==KEY_DEBOUNCE_CYCLES-1) key3_press_ready<=1;
   end else begin
    key3_release_count<=0;
    if(key3_press_count<KEY_DEBOUNCE_CYCLES)
     key3_press_count<=key3_press_count+1'b1;
    if(key3_press_event) key3_press_ready<=0;
   end
   // 锁存触发停机当时的测量值，避免串口稍后发送的快照掩盖瞬时异常。
   // 角度越界和按键停机同时发生时，优先记录角度越界原因。
   if(running && (angle_stop || !key2_released || press_event || key3_press_event)) begin
    running<=0; manual_mode<=0;
    stop_reason<=angle_stop ? 8'd3 : !key2_released ? 8'd2 : press_event ? 8'd1 : 8'd4;
    stop_theta<=theta; stop_keys<=key_sync;
    // 以下ADC寄存输出与触发停机的theta属于同一组采样。
    stop_raw<=raw; stop_filtered_raw<=filtered_raw;
    stop_min<=adc_block_min; stop_max<=adc_block_max;
    stop_sum<=adc_block_sum; stop_count<=adc_block_count;
   end
   else if(!key2_released || (recovery_waiting && (press_event || key3_press_event))) begin
    running<=0; manual_mode<=0;
   end
   else if(auto_start || manual_start || recovery_restart) begin
    // 自动恢复固定进入起摆模式，不沿用手动PID模式或原运动任务。
    running<=1; manual_mode<=recovery_restart ? 1'b0 : manual_start;
    stop_reason<=0; stop_theta<=0; stop_keys<=3'b111;
    stop_raw<=0; stop_filtered_raw<=0;
   stop_min<=0; stop_max<=0; stop_sum<=0; stop_count<=0;
   end
  end
 end
 
 reg [15:0] tick_count=0;
 wire tick=(tick_count==16'd49999);
 always @(posedge clk_50m or negedge rst_n)
  if(!rst_n) tick_count<=0;
  else if(tick) tick_count<=0;
  else tick_count<=tick_count+1'b1;

 swing_up #(
  .CENTER_ADC(UPRIGHT_ADC), .CAPTURE_RANGE(CAPTURE_RANGE),
  .SAMPLE_PERIOD_MS(SWING_SAMPLE_MS), .PULSE_MS(SWING_PULSE_MS),
  .PULSE_DUTY(SWING_DUTY), .LEFT_FIRST_POSITIVE(LEFT_FIRST_POSITIVE),
  .START_KICK_DUTY(START_KICK_DUTY), .START_KICK_MS(START_KICK_MS),
  .START_KICK_POSITIVE(START_KICK_POSITIVE),
  .START_BOTTOM_LOW(START_BOTTOM_LOW), .START_BOTTOM_HIGH(START_BOTTOM_HIGH)
 ) swing_inst(
  .clk(clk_50m), .rst_n(rst_n), .enable(enable && !manual_mode), .tick_1ms(tick),
  .adc_valid(adc_valid), .adc_value(filtered_raw),
  .balance_mode(balance_mode), .pulse_active(swing_pulse_active),
  .duty_command(swing_duty), .state(swing_state),
  .peak_event(swing_peak), .peak_region(swing_peak_region));
// ============================================================
// 外环 100 Hz 采样脉冲
// 50 MHz / 500000 = 100 Hz
// ============================================================
reg [18:0] pos_tick_count = 0;

wire pos_tick = (pos_tick_count == 19'd499999);

always @(posedge clk_50m or negedge rst_n) 
begin
    if(!rst_n)
        pos_tick_count <= 19'd0;
    else if(pos_tick)
        pos_tick_count <= 19'd0;
    else
        pos_tick_count <= pos_tick_count + 1'b1;
end
 
wire signed [16:0] position;
wire signed [15:0] speed;

auto_recover #(.ENABLE(AUTO_RECOVER_ENABLE),.SPEED_MAX(RECOVER_SPEED_MAX),
              .LOW_SAMPLES(RECOVER_LOW_SAMPLES)) recovery(
 .clk(clk_50m),.rst_n(rst_n),.sample_tick(pos_tick),.speed(speed),.running(running),
 .fault_event(running && angle_stop),
 .cancel(!key2_released || press_event || key3_press_event),
 .waiting(recovery_waiting),.restart_request(recovery_restart));

encoder_decoder encoder_inst (
    .clk      (clk_50m),
    .rst_n    (rst_n),
    .en       (pos_tick),

    .a        (enc_a),
    .b        (enc_b),

    .position (position),
    .speed    (speed)
);

wire signed [16:0] position_error;
wire signed [16:0] theta_ref;
wire theta_ref_valid;
wire signed [31:0] outer_p_mon, outer_d_mon, outer_i_mon;
wire outer_limited;
wire signed [16:0] outer_active_limit;
wire [2:0] outer_limit_phase;
wire outer_boost_active;

// KEY4只改变旋臂位置目标，不能启动电机或绕过起摆/角度保护。
wire move_key_event;
key_press #(.DEBOUNCE_CYCLES(KEY_DEBOUNCE_CYCLES)) move_key(
 .clk(clk_50m),.rst_n(rst_n),.key_n(key_sw[3]),.pressed(move_key_event));
wire signed [32:0] position_target_q16;
wire motion_busy, motion_target_valid, motion_range_rejected, motion_limit_active;
wire motion_profile_active;
move90 motion(
 .clk(clk_50m),.rst_n(rst_n),.enable(control_enable),.sample_tick(pos_tick),
 .load_target(recovery_load_target),.load_position(position),
 .start_event(move_key_event),.target_q16(position_target_q16),
 .busy(motion_busy),.target_valid(motion_target_valid),.range_rejected(motion_range_rejected),
 .motion_active(motion_profile_active));
// 保留原极性：误差=实际旋臂位置-目标位置；Q16小数直接参与外环P运算。
wire signed [33:0] position_error_full_q16 =
 $signed({position[16],position,16'b0}) - $signed({position_target_q16[32],position_target_q16});
wire signed [32:0] position_error_q16 =
 position_error_full_q16>34'sd4294901760 ? 33'sd4294901760 :
 position_error_full_q16< -34'sd4294967296 ? -33'sd4294967296 : position_error_full_q16[32:0];
assign position_error=position_error_q16>>>16; // 原串口位置误差字段跟随新运动目标

// 轨迹走完仍可能实际未到位：锁住小限幅，直到一次位置采样确认实际到达。
// 仅在本次运动中等待首次到位；到位后恢复原规则，不因后续扰动反复进入等待。
localparam signed [33:0] MOTION_ARRIVE_Q16 = MOTION_ARRIVE_COUNTS*34'sd65536;
wire motion_position_arrived = (position_error_full_q16 >= -MOTION_ARRIVE_Q16) &&
                               (position_error_full_q16 <= MOTION_ARRIVE_Q16);
wire motion_arrival_sample = pos_tick && !motion_profile_active && motion_position_arrived;
reg motion_arrival_wait=0;
always @(posedge clk_50m or negedge rst_n) begin
 if(!rst_n) motion_arrival_wait<=0;
 else if(!control_enable || recovery_load_target) motion_arrival_wait<=0;
 else if(motion_profile_active) motion_arrival_wait<=1;
 else if(motion_range_rejected || motion_arrival_sample) motion_arrival_wait<=0;
end
// 到位确认当拍即可恢复正常外环采样；不等待下一个采样，也不带回旧的大限幅计时。
assign motion_limit_active = motion_profile_active || (motion_arrival_wait && !motion_arrival_sample);


audit_old_position_controller #(
    .Kp_pos(OUTER_KP_Q), .Kd_pos(OUTER_KD_Q),
    .Ki_pos(OUTER_KI_Q), .I_POS_MAX_Q(OUTER_I_MAX_Q), .I_POS_SEP_THRESHOLD(OUTER_I_SEP_COUNTS),
    .FUZZY_ENABLE(1),.FUZZY_MAX_DELTA_Q12(FUZZY_MAX_DELTA_Q12),.FUZZY_SLEW_Q12(FUZZY_SLEW_Q12),
    .D_FILTER_SHIFT(OUTER_D_FILTER_SHIFT), .USE_Q16_POSITION(1), .D_ON_MEASUREMENT(1),
    .THETA_REF_MAX(OUTER_LIMIT_NEAR_ADC), .LIMIT_SWITCH_ENABLE(1),
    .THETA_REF_BOOST_MAX(OUTER_LIMIT_FAR_ADC),
    .LIMIT_POSITION_THRESHOLD(OUTER_LIMIT_POSITION_COUNTS),
    .LIMIT_BOOST_MIN_MS(OUTER_LIMIT_MIN_MS), .POSITION_SAMPLE_MS(OUTER_SAMPLE_MS),
    .STARTUP_BOOST_ENABLE(OUTER_STARTUP_LIMIT_ENABLE), .STARTUP_BOOST_MAX(OUTER_STARTUP_LIMIT_ADC),
    .DISTURB_LIMIT_ENABLE(OUTER_DISTURB_LIMIT_ENABLE),
    .DISTURB_LIMIT_MAX(OUTER_DISTURB_LIMIT_ADC), .DISTURB_LIMIT_RAMP_MS(OUTER_DISTURB_RAMP_MS)
) position_control (
    .clk            (clk_50m),
    .rst            (~rst_n),
    .enable         (control_enable),
    .sample_tick    (pos_tick),

    .position_error (position_error),
    .position_error_q16(position_error_q16), .position_measurement(position),
    .integral_clear(motion_profile_active), // 保留原清积分阶段；轨迹结束后允许I帮助消除到位静差
    .motion_active(motion_limit_active), // 轨迹完成且实际到位后才恢复双条件限幅
    .fuzzy_request(fuzzy_request),.fuzzy_gain_mon(fuzzy_gain_q12),
    .startup_boost_arm(startup_once_arm),

    .theta_ref      (theta_ref),
    .theta_ref_valid(theta_ref_valid),
    .p_pos_mon(outer_p_mon),
    .d_pos_mon(outer_d_mon),
    .i_pos_mon(outer_i_mon),
    .limited_mon(outer_limited), .active_limit_mon(outer_active_limit),
    .boost_active_mon(outer_boost_active), .limit_phase_mon(outer_limit_phase)
);

wire signed [16:0] error;
wire signed [16:0] outer_adc_offset;
wire signed [16:0] target_adc;
wire signed [16:0] actual_adc;

// INVERT=1时，外环正向目标角偏移对应更小的绝对ADC目标值。
// 外环提供中心角附近的偏移；内环接收合成后的目标ADC和实际ADC。
assign outer_adc_offset = -theta_ref;
assign target_adc = $signed({5'b0, UPRIGHT_ADC}) + outer_adc_offset;
assign actual_adc = $signed({5'b0, filtered_raw});

 wire signed [50:0] pid_sum;
 wire pid_valid;
 wire signed [15:0] p_mon;
 wire signed [15:0] i_mon;
 wire signed [15:0] d_mon;
 wire signed [16:0] duty;
 // Q16输出限幅由下方OUT_MAX_Q设置：实际电机指令上限为该值除以65536。
 // P/I输入误差限幅为±100 ADC；D使用实际测量值，串口保留未限幅误差。
 // 积分分离按实际误差判断：绝对值小于40才允许积分，否则清除积分。



 audit_old_pid_adc_controller #(
  .ADC_INVERT(1),
  .KP_Q(INNER_KP_Q), .KD_Q(INNER_KD_Q),
  .D_FILTER_SHIFT(INNER_D_FILTER_SHIFT),
  .OUT_MAX_Q(51'sd65536000),
  .KI_Q(INNER_KI_Q), // 当前关闭积分，内环采样周期为1ms
  .I_SEP_THRESHOLD(17'sd40), // 实际内环误差小于40才积分
  .ERROR_INPUT_LIMIT(17'sd150) // P/I输入误差限幅；设0关闭
) control(
  .clk(clk_50m), .rst(~rst_n), .enable(control_enable), .sample_tick(tick),
  .target_adc(target_adc), .actual_adc(actual_adc), .error_out(error),
  .pid_sum(pid_sum), .pid_valid(pid_valid),
  .p_mon(p_mon), .i_mon(i_mon), .d_mon(d_mon));
 // 起摆与PID共用一个PWM驱动，根据当前状态二选一，避免同时驱动电机。
 // 切入PID时，在第一组PID结果就绪前先清除旧的起摆驱动指令。
 reg balance_mode_d=0;
 always @(posedge clk_50m or negedge rst_n)
  if(!rst_n) balance_mode_d<=0;
  else balance_mode_d<=balance_active;
 wire signed [50:0] swing_sum=$signed({{34{swing_duty[16]}},swing_duty}) <<< 16;
 wire signed [50:0] motor_sum=balance_active ? pid_sum : swing_sum;
 wire motor_valid=balance_active ? (pid_valid || !balance_mode_d) : 1'b1;
 // PID模式保留角度停机保护；起摆需要经过大角度，因此起摆阶段绕过该保护。
 wire signed [12:0] motor_theta=balance_active ? theta : 13'sd0;
 motor_pwm #(.MOTOR_SIGN(1), .FALL_THRESH(STOP_THRESHOLD)) motor(
  .clk(clk_50m), .rst_n(rst_n), .enable(enable), .theta(motor_theta),
  .pid_sum(motor_sum), .pid_valid(motor_valid), .pwm_out(PWMA),
  .in1(AN1), .in2(AN2), .duty_out(duty));
 wire [15:0] monitor_duty=duty[15:0];
 assign PWMB=1'b0; assign BN1=1'b0; assign BN2=1'b0;
 // 传感器已重新安装：竖直向上ADC为1958，右侧区域小于1658，左侧区域大于2258。



 adc_v2 #(.OFFSET(UPRIGHT_ADC), .INVERT(1)) adc_inst(.clk_50m(clk_50m), .rst_n(rst_n),
  .adc_data_in(adc_data_in), .adc_clk(adc_clk), .adc_oe_n(adc_oe_n),
  .adc_stby_n(), .theta_raw(raw), .theta_filtered(filtered_raw), .theta(theta), .data_valid(adc_valid),
  .block_min(adc_block_min), .block_max(adc_block_max),
  .block_sum(adc_block_sum), .block_count(adc_block_count));
 reg [11:0] frame_raw=0;
 reg [15:0] frame_theta=0, frame_duty=0;
 reg [15:0] frame_err=0, frame_pos=0;
 reg [15:0] frame_p=0, frame_i=0, frame_d=0;
 reg [31:0] frame_err32=0, frame_pos32=0, frame_ref32=0, frame_pos_error32=0;
 reg [15:0] frame_speed=0;
 reg [31:0] frame_outer_p=0, frame_outer_d=0, frame_outer_i=0;
 reg [7:0] frame_flags=0;
 reg [7:0] frame_stop_reason=0, frame_stop_keys=8'd7;
 reg [15:0] frame_stop_theta=0;
 reg [15:0] frame_stop_raw=0, frame_stop_filtered_raw=0;
 reg [15:0] frame_stop_min=0, frame_stop_max=0;
 reg [31:0] frame_stop_sum=0;
 reg [7:0] frame_stop_count=0;
 reg [12:0] frame_fuzzy_gain=13'd4096;
 reg [7:0] frame_fuzzy_status=0; // bit0请求、bit1倍率>1、bit4:2限幅阶段
 reg [15:0] frame_active_limit=0;
 reg [8:0] baud_count=0;
 reg [3:0] bit_index=0;
 reg [6:0] byte_index=0;
 // 每帧开始时统一锁存数据，保证本帧各字段在发送期间保持不变。
 always @(posedge clk_50m or negedge rst_n)
  if(!rst_n) begin
   frame_theta<=0; frame_duty<=0; frame_err<=0; frame_pos<=0;
   frame_p<=0; frame_i<=0; frame_d<=0;
   frame_err32<=0; frame_pos32<=0; frame_ref32<=0; frame_pos_error32<=0;
   frame_speed<=0; frame_outer_p<=0; frame_outer_d<=0; frame_outer_i<=0; frame_flags<=0;
   frame_stop_reason<=0; frame_stop_theta<=0; frame_stop_keys<=7;
   frame_stop_raw<=0; frame_stop_filtered_raw<=0;
   frame_stop_min<=0; frame_stop_max<=0; frame_stop_sum<=0; frame_stop_count<=0;
   frame_fuzzy_gain<=13'd4096;frame_fuzzy_status<=0;frame_active_limit<=0;
  end
  else if(byte_index==0 && bit_index==0 && baud_count==0) begin
   frame_duty<=monitor_duty; frame_theta<={{3{theta[12]}},theta};
   frame_err<=error[15:0]; frame_pos<=position[15:0];
   frame_p<=p_mon; frame_i<=i_mon; frame_d<=d_mon;
   frame_err32<={{15{error[16]}},error};
   frame_pos32<={{15{position[16]}},position};
   frame_ref32<={{15{theta_ref[16]}},theta_ref};
   frame_pos_error32<={{15{position_error[16]}},position_error};
   frame_speed<=speed;
   frame_outer_p<=outer_p_mon; frame_outer_d<=outer_d_mon; frame_outer_i<=outer_i_mon;
   // 第6位仍表示自动起摆；第7位在起摆时表示脉冲，在PID时表示大限幅有效。
   // AA5D在AA5C数据上追加实时限幅，并在状态字节中加入限幅阶段。
   frame_flags<={(balance_active ? (pid_enable && outer_boost_active) : swing_pulse_active),
                 (enable && !balance_active),key2_released,key_sync[0],in_range,running,outer_limited,enable};
   frame_stop_reason<=stop_reason;
   frame_stop_theta<={{3{stop_theta[12]}},stop_theta};
   frame_stop_keys<={5'b0,stop_keys};
   frame_stop_raw<={4'b0,stop_raw};
   frame_stop_filtered_raw<={4'b0,stop_filtered_raw};
   frame_stop_min<={4'b0,stop_min}; frame_stop_max<={4'b0,stop_max};
   frame_stop_sum<={14'b0,stop_sum}; frame_stop_count<=stop_count;
   frame_fuzzy_gain<=fuzzy_gain_q12;
   frame_fuzzy_status<={3'b0,(control_enable ? outer_limit_phase : 3'd0),
                         (fuzzy_gain_q12>13'd4096),fuzzy_request};
   frame_active_limit<=control_enable ? outer_active_limit[15:0] : 16'd0;
  end
 wire [7:0] checksum=frame_theta[7:0] ^ frame_theta[15:8] ^
                      frame_err32[7:0] ^ frame_err32[15:8] ^ frame_err32[23:16] ^ frame_err32[31:24] ^
                      frame_pos32[7:0] ^ frame_pos32[15:8] ^ frame_pos32[23:16] ^ frame_pos32[31:24] ^
                      frame_duty[7:0] ^ frame_duty[15:8] ^
                      frame_p[7:0] ^ frame_p[15:8] ^ frame_i[7:0] ^ frame_i[15:8] ^ frame_d[7:0] ^ frame_d[15:8] ^
                      frame_ref32[7:0] ^ frame_ref32[15:8] ^ frame_ref32[23:16] ^ frame_ref32[31:24] ^
                      frame_pos_error32[7:0] ^ frame_pos_error32[15:8] ^ frame_pos_error32[23:16] ^ frame_pos_error32[31:24] ^
                      frame_speed[7:0] ^ frame_speed[15:8] ^
                      frame_outer_p[7:0] ^ frame_outer_p[15:8] ^ frame_outer_p[23:16] ^ frame_outer_p[31:24] ^
                      frame_outer_d[7:0] ^ frame_outer_d[15:8] ^ frame_outer_d[23:16] ^ frame_outer_d[31:24] ^ frame_flags ^
                      frame_stop_reason ^ frame_stop_theta[7:0] ^ frame_stop_theta[15:8] ^ frame_stop_keys ^
                      frame_stop_raw[7:0] ^ frame_stop_raw[15:8] ^
                      frame_stop_filtered_raw[7:0] ^ frame_stop_filtered_raw[15:8] ^
                      frame_stop_min[7:0] ^ frame_stop_min[15:8] ^
                      frame_stop_max[7:0] ^ frame_stop_max[15:8] ^
                      frame_stop_sum[7:0] ^ frame_stop_sum[15:8] ^
                      frame_stop_sum[23:16] ^ frame_stop_sum[31:24] ^ frame_stop_count ^
                      frame_outer_i[7:0] ^ frame_outer_i[15:8] ^ frame_outer_i[23:16] ^ frame_outer_i[31:24] ^
                      frame_fuzzy_gain[7:0] ^ {3'b0,frame_fuzzy_gain[12:8]} ^ frame_fuzzy_status ^
                      frame_active_limit[7:0] ^ frame_active_limit[15:8];
 // 帧头AA 5D，共66字节：63~64为实时限幅ADC，65为校验。
 // 串口连续发送，115200波特率、8位数据、无校验、1位停止位；每帧使用固定的数据快照。
 reg [7:0] data_byte;
 always @* begin
  case(byte_index)
   0: data_byte=8'hAA;
   1: data_byte=8'h5D;
   2: data_byte=frame_theta[7:0];
   3: data_byte=frame_theta[15:8];
   4: data_byte=frame_err32[7:0];
   5: data_byte=frame_err32[15:8];
   6: data_byte=frame_err32[23:16];
   7: data_byte=frame_err32[31:24];
   8: data_byte=frame_pos32[7:0];
   9: data_byte=frame_pos32[15:8];
   10: data_byte=frame_pos32[23:16];
   11: data_byte=frame_pos32[31:24];
   12: data_byte=frame_duty[7:0];
   13: data_byte=frame_duty[15:8];
   14: data_byte=frame_p[7:0];
   15: data_byte=frame_p[15:8];
   16: data_byte=frame_i[7:0];
   17: data_byte=frame_i[15:8];
   18: data_byte=frame_d[7:0];
   19: data_byte=frame_d[15:8];
   20: data_byte=frame_ref32[7:0];
   21: data_byte=frame_ref32[15:8];
   22: data_byte=frame_ref32[23:16];
   23: data_byte=frame_ref32[31:24];
   24: data_byte=frame_pos_error32[7:0];
   25: data_byte=frame_pos_error32[15:8];
   26: data_byte=frame_pos_error32[23:16];
   27: data_byte=frame_pos_error32[31:24];
   28: data_byte=frame_speed[7:0];
   29: data_byte=frame_speed[15:8];
   30: data_byte=frame_outer_p[7:0];
   31: data_byte=frame_outer_p[15:8];
   32: data_byte=frame_outer_p[23:16];
   33: data_byte=frame_outer_p[31:24];
   34: data_byte=frame_outer_d[7:0];
   35: data_byte=frame_outer_d[15:8];
   36: data_byte=frame_outer_d[23:16];
   37: data_byte=frame_outer_d[31:24];
   38: data_byte=frame_flags;
   39: data_byte=frame_stop_reason;
   40: data_byte=frame_stop_theta[7:0];
   41: data_byte=frame_stop_theta[15:8];
   42: data_byte=frame_stop_keys;
   43: data_byte=frame_stop_raw[7:0];
   44: data_byte=frame_stop_raw[15:8];
   45: data_byte=frame_stop_filtered_raw[7:0];
   46: data_byte=frame_stop_filtered_raw[15:8];
   47: data_byte=frame_stop_min[7:0];
   48: data_byte=frame_stop_min[15:8];
   49: data_byte=frame_stop_max[7:0];
   50: data_byte=frame_stop_max[15:8];
   51: data_byte=frame_stop_sum[7:0];
   52: data_byte=frame_stop_sum[15:8];
   53: data_byte=frame_stop_sum[23:16];
   54: data_byte=frame_stop_sum[31:24];
   55: data_byte=frame_stop_count;
   56: data_byte=frame_outer_i[7:0];
   57: data_byte=frame_outer_i[15:8];
   58: data_byte=frame_outer_i[23:16];
   59: data_byte=frame_outer_i[31:24];
   60: data_byte=frame_fuzzy_gain[7:0];
   61: data_byte={3'b0,frame_fuzzy_gain[12:8]};
   62: data_byte=frame_fuzzy_status;
   63: data_byte=frame_active_limit[7:0];
   64: data_byte=frame_active_limit[15:8];
   65: data_byte=checksum;
   default: data_byte=8'h00;
  endcase
 end
 always @(posedge clk_50m or negedge rst_n) begin
  if(!rst_n) begin baud_count<=0; bit_index<=0; byte_index<=0; end
  else if(baud_count==9'd433) begin
   baud_count<=0;
   if(bit_index==9) begin
    bit_index<=0;
    if(byte_index==65) byte_index<=0;
    else byte_index<=byte_index+1'b1;
   end else bit_index<=bit_index+1'b1;
  end else baud_count<=baud_count+1'b1;
 end
 assign uart_tx= !rst_n ? 1'b1 : bit_index==0 ? 1'b0 :
                 bit_index==9 ? 1'b1 : data_byte[bit_index-1'b1];
endmodule

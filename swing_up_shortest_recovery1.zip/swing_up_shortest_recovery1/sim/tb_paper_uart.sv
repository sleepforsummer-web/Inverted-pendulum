`timescale 1ns/1ps
module tb_paper_uart;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,rx=1; reg [7:0] data[0:10]; integer i;
 wire valid; wire [7:0] seq; wire signed [31:0] goal; wire [15:0] speed;
 uart_target_rx dut(.clk(clk),.rst_n(rst_n),.rx(rx),.command_valid(valid),.command_seq(seq),.command_goal_q8(goal),.command_step_q8(speed));
 task byte_send(input [7:0] b); integer j; begin
  rx=0;repeat(434)@(negedge clk);
  for(j=0;j<8;j=j+1) begin rx=b[j]; repeat(434)@(negedge clk);end
  rx=1;repeat(434)@(negedge clk);
 end endtask
 initial begin
  $readmemh("serial_commands.hex",data,0,10);
  #100;rst_n=1;#100;
  for(i=0;i<11;i=i+1) byte_send(data[i]);
  #100;if(seq!=17 || goal!=69120 || speed!=346)$fatal(1,"UART decode failed");
  $display("PASS paper UART real 115200 frame");$finish;
 end
endmodule

`timescale 1ns/1ps
module tb_serial_position;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,en=0,tick=0,allow=1,guard_ok=1,valid=0;
 reg [7:0] seq=1;reg signed [31:0] goal=0;reg [15:0] step=343;
 reg signed [32:0] anchor=0;
 wire signed [32:0] target;wire signed [31:0] goal_mon;
 wire busy,tv,done,accepted,active;wire [7:0] rs,st;
 serial_position dut(.clk(clk),.rst_n(rst_n),.enable(en),.sample_tick(tick),
  .allow_start(allow),.start_guard(guard_ok),.command_valid(valid),.command_seq(seq),
  .command_goal_q8(goal),.command_step_q8(step),.anchor_q16(anchor),.target_q16(target),
  .goal_q8(goal_mon),.busy(busy),.target_valid(tv),.finished(done),.accepted(accepted),
  .motion_active(active),.reply_seq(rs),.reply_status(st));
 task clocks(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
 task command(input integer g,s,expected);
  @(negedge clk);goal=g;step=s;seq=seq+1'b1;valid=1;clocks(1);
  @(negedge clk);valid=0;clocks(2);
  if(st!=expected || rs!=seq)$fatal(1,"command status %0d/%0d",st,expected);
 endtask
 task sample;
  @(negedge clk);tick=1;clocks(1);@(negedge clk);tick=0;clocks(10);
 endtask
 longint previous,previous_delta,delta,finish_target,dir,old_distance,old_remaining,old_steps,old_product;integer n;
 task travel(input integer goal_value,input integer step_value=343);
  command(goal_value,step_value,1);previous=target;previous_delta=0;
  finish_target=64'(goal_value)*256;dir=finish_target>previous ? 1 : -1;
  for(n=0;n<5000 && busy;n=n+1)begin
   old_distance=dut.brake_distance;old_remaining=dut.remaining;old_steps=dut.brake_steps;old_product=dut.brake_product;
   sample();delta=$signed(target)-previous;
   if(delta*dir<0 || delta>step_value*256 || delta< -step_value*256)$fatal(1,"speed/monotonic bound");
   if(delta-previous_delta>2048 || delta-previous_delta< -2048)
    $fatal(1,"acceleration bound goal%0d n%0d delta%0d previous%0d preRemaining%0d preDistance%0d steps%0d product%0d",goal_value,n,delta,previous_delta,old_remaining,old_distance,old_steps,old_product);
   if((finish_target-$signed(target))*dir<0)$fatal(1,"trajectory overshoot");
   previous=target;previous_delta=delta;
  end
  if(busy || target!==finish_target || st!=7)$fatal(1,"did not finish exactly n=%0d target=%0d/%0d",n,target,finish_target);
  anchor=target;repeat(5)sample();if(target!==finish_target || tv)$fatal(1,"endpoint not held");
 endtask
 initial begin
  clocks(3);@(negedge clk);rst_n=1;
  command(68672,343,2);if(busy)$fatal(1,"disabled command started motor");
  @(negedge clk);en=1;allow=0;command(68672,343,3);allow=1;
  guard_ok=0;command(68672,343,5);guard_ok=1;
  command(16776961,343,4);command(-16777217,343,4);command(0,0,4);command(0,2766,4);
  travel(68672);travel(-137344);travel(0);
  // 新上限必须能被接收，并在正反长行程中维持原加速度约束和精确终点。
  travel(6000*256,2765);travel(-6000*256,2765);travel(0,2765);
  command(68672,343,1);sample();@(negedge clk);en=0;clocks(3);
  if(busy || active || st!=8)$fatal(1,"stop did not cancel");
  @(negedge clk);en=1;repeat(5)sample();if(busy)$fatal(1,"old command resumed");
  command(68672,343,1);command(0,343,3);if(goal_mon!=68672)$fatal(1,"busy command replaced endpoint");
  @(negedge clk);rst_n=0;clocks(3);if(target || busy || st)$fatal(1,"reset retained motion");
  $display("PASS serial profile: signed absolute fractional targets,speed+acceleration limits,braking,no overshoot,range/guard/interlock,stop/reset,no auto resume");$finish;
 end
 initial begin #3000000;$fatal(1,"timeout");end
endmodule

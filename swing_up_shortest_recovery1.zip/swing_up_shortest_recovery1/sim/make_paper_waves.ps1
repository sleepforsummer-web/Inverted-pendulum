$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 $out='../paper_waves'
 New-Item -ItemType Directory -Force -Path $out | Out-Null
 & 'F:/ModelSim_10.4/win64/vsim.exe' -c -l "$out/compile.log" -do 'onerror {quit -code 1}; vlog -sv tb_paper_pid.sv tb_paper_io.sv tb_paper_uart.sv; quit -code 0' | Out-Null
 if($LASTEXITCODE -ne 0){throw 'compile failed'}
 $cases=@(
  @{name='pid'; top='tb_paper_pid'; paths=@('/tb_paper_pid/position','/tb_paper_pid/theta','/tb_paper_pid/dut/tick','/tb_paper_pid/dut/pos_tick','/tb_paper_pid/dut/theta_ref','/tb_paper_pid/dut/theta_ref_valid','/tb_paper_pid/dut/error','/tb_paper_pid/dut/pid_valid','/tb_paper_pid/dut/duty')},
  @{name='io'; top='tb_paper_io'; paths=@('/tb_paper_io/data','/tb_paper_io/adc_clk','/tb_paper_io/adc_valid','/tb_paper_io/raw','/tb_paper_io/filtered','/tb_paper_io/theta','/tb_paper_io/command','/tb_paper_io/valid','/tb_paper_io/duty','/tb_paper_io/pwm','/tb_paper_io/in1','/tb_paper_io/in2')},
  @{name='swing'; top='tb_swing_top'; paths=@('/tb_swing_top/adc','/tb_swing_top/angle','/tb_swing_top/dut/swing_state','/tb_swing_top/dut/swing_peak','/tb_swing_top/dut/swing_duty','/tb_swing_top/dut/balance_active','/tb_swing_top/dut/pid_enable','/tb_swing_top/dut/duty')},
  @{name='recovery'; top='tb_recovery_target'; paths=@('/tb_recovery_target/position','/tb_recovery_target/theta','/tb_recovery_target/dut/running','/tb_recovery_target/dut/recovery_waiting','/tb_recovery_target/dut/recovery_anchor_pending','/tb_recovery_target/dut/recovery_saved_target','/tb_recovery_target/dut/recovery_target_ready','/tb_recovery_target/dut/position_target_q16','/tb_recovery_target/dut/control_enable')},
  @{name='uart'; top='tb_paper_uart'; paths=@('/tb_paper_uart/rx','/tb_paper_uart/valid','/tb_paper_uart/seq','/tb_paper_uart/goal','/tb_paper_uart/speed')}
 )
 foreach($c in $cases){
  $commands="onerror {quit -code 1}; vcd file $out/$($c.name).vcd; "
  foreach($p in $c.paths){$commands+="log $p; vcd add $p; "}
  $commands+='run -all; quit -code 0'
  & 'F:/ModelSim_10.4/win64/vsim.exe' -c -voptargs=+acc -wlf "$out/$($c.name).wlf" -onfinish exit -l "$out/$($c.name).log" -do $commands "work.$($c.top)" | Out-Null
  $log=Get-Content -LiteralPath "$out/$($c.name).log" -Raw
  if($LASTEXITCODE -ne 0 -or $log -notmatch '# PASS' -or $log -match '\*\* (Error|Fatal):'){throw "simulation failed: $($c.name)"}
  Write-Output "PASS $($c.name)"
 }
}finally{Pop-Location}

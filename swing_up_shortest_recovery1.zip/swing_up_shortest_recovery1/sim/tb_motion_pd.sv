`timescale 1ns/1ps
module tb_motion_pd;
 reg clk=0; always #10 clk=~clk;
 reg rst=1, enable=0, tick=0;
 reg signed [16:0] actual=0;
 reg signed [32:0] err_q16=0;
 wire signed [16:0] err=err_q16>>>16;
 wire signed [16:0] target, cap;
 wire valid,limited,boosted;
 wire signed [31:0] pm,dm;
 position_controller #(.Kp_pos(19661),.Kd_pos(1114112),.D_FILTER_SHIFT(1),
  .LIMIT_SWITCH_ENABLE(1),.THETA_REF_BOOST_MAX(110),.USE_Q16_POSITION(1),.D_ON_MEASUREMENT(1)) dut(
  .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),.position_error(err),
  .position_error_q16(err_q16),.position_measurement(actual),.integral_clear(1'b0),.motion_active(1'b0),.i_pos_mon(),.theta_ref(target),
  .theta_ref_valid(valid),.p_pos_mon(pm),.d_pos_mon(dm),.limited_mon(limited),
  .active_limit_mon(cap),.boost_active_mon(boosted));
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 longint expected_p;
 task sample(input longint q16, input integer measurement);
  @(negedge clk); err_q16=q16; actual=measurement; tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(4);
  expected_p=(q16*64'sd19661)>>>24;
  if(!valid || pm!==expected_p) $fatal(1,"fractional P or pairing failed %0d/%0d",pm,expected_p);
 endtask
 integer n;
 initial begin
  clocks(3); @(negedge clk); rst=0; enable=1;
  sample(0,0);
  // 只有目标移动，实际位置不动：外环D必须为0，而小数P不能被丢弃。
  for(n=1;n<=300;n=n+1) begin
   sample(-n*64'sd56798,0);
   if(dm!==0) $fatal(1,"target motion leaked into D");
  end
  sample(0,0); if(cap!=40) $fatal(1,"elapsed and inside must restore low limit");
  sample(50*65536,0); if(boosted) $fatal(1,"inclusive boundary failed");
  sample(50*65536+1,0); if(!boosted || cap!=110) $fatal(1,"fractional threshold not applied");
  sample(0,2); if(dm!=4352) $fatal(1,"real movement D expected17 after1/2 filter, got%0d",dm);
  @(negedge clk); enable=0; clocks(4);
  if(target || dm || boosted || cap!=40) $fatal(1,"stop history not clear");
  @(negedge clk); enable=1;
  sample(-50*65536,0); if(boosted) $fatal(1,"negative inclusive boundary failed");
  sample(-50*65536-1,0); if(!boosted || dm) $fatal(1,"negative fractional threshold failed");
  $display("PASS motion PD: fractional P, D on measurement, real movement damping, signed threshold and preserved AND timer");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

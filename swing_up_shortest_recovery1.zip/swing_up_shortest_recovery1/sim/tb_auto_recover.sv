`timescale 1ns/1ps
module tb_auto_recover;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,tick=0,running=0,fault=0,cancel=0;
 reg signed [15:0] speed=0;
 wire waiting,request,disabled_wait,disabled_request;
 reg default_fault=0,default_tick=0,default_done=0;
 wire default_wait,default_request;
 auto_recover default_gate(
  .clk(clk),.rst_n(rst_n),.sample_tick(default_tick),.speed(16'sd0),.running(1'b0),
  .fault_event(default_fault),.cancel(1'b0),.waiting(default_wait),.restart_request(default_request));
 auto_recover #(.LOW_SAMPLES(3)) dut(
  .clk(clk),.rst_n(rst_n),.sample_tick(tick),.speed(speed),.running(running),
  .fault_event(fault),.cancel(cancel),.waiting(waiting),.restart_request(request));
 auto_recover #(.ENABLE(0),.LOW_SAMPLES(3)) disabled(
  .clk(clk),.rst_n(rst_n),.sample_tick(tick),.speed(speed),.running(running),
  .fault_event(fault),.cancel(cancel),.waiting(disabled_wait),.restart_request(disabled_request));
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task sample(input integer v);
  @(negedge clk); speed=v; tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(3);
  if(disabled_wait || disabled_request) $fatal(1,"disabled recovery triggered");
 endtask
 task fail_event;
  @(negedge clk); fault=1; running=1; clocks(1);
  @(negedge clk); fault=0; running=0; clocks(2);
  if(!waiting || request) $fatal(1,"fault did not arm fresh recovery");
 endtask
 integer n;
 initial begin : check_default_twenty_samples
  integer k;
  wait(rst_n);
  @(negedge clk); default_fault=1; clocks(1);
  @(negedge clk); default_fault=0;
  for(k=1;k<=20;k=k+1) begin
   @(negedge clk); default_tick=1; clocks(1);
   @(negedge clk); default_tick=0; clocks(3);
   if(default_request!==(k==20) || !default_wait)
    $fatal(1,"default recovery must require exactly20 fresh low-speed samples");
  end
  default_done=1;
 end
 initial begin
  clocks(3); @(negedge clk); rst_n=1;
  repeat(5) sample(0);
  if(waiting || request) $fatal(1,"boot/stopped system restarted without fault");
  fail_event();
  sample(32767); sample(-32768); sample(2); sample(-2);
  if(request || dut.low_count) $fatal(1,"high signed speed accepted");
  sample(1); clocks(100);
  if(request || dut.low_count!=1) $fatal(1,"old speed counted repeatedly without fresh ticks");
  sample(-1); if(request || dut.low_count!=2) $fatal(1,"inclusive speed boundary");
  sample(2); if(dut.low_count) $fatal(1,"high-speed sample did not reset consecutive count");
  sample(0); sample(0);
  // 最后一个采样模拟编码器同拍更新为高速，不能使用上一拍旧的低速。
  @(negedge clk); tick=1; @(posedge clk); speed<=16'sd2; #2;
  @(negedge clk); tick=0; clocks(3);
  if(request || dut.low_count) $fatal(1,"stale encoder speed caused early restart");
  sample(1); sample(-1); sample(0);
  if(!waiting || !request) $fatal(1,"qualified low speed did not request restart");
  clocks(10); if(!waiting || !request) $fatal(1,"request lost before top acknowledgment");
  @(negedge clk); running=1; clocks(2);
  if(waiting || request) $fatal(1,"restart acknowledgment did not clear waiting");
  fail_event(); sample(0); sample(0); sample(0);
  @(negedge clk); cancel=1; #1;
  if(request) $fatal(1,"cancel must immediately block restart request");
  clocks(2); @(negedge clk); cancel=0;
  repeat(5) sample(0);
  if(waiting || request) $fatal(1,"manual cancellation auto-restarted");
  @(negedge clk); fault=1; cancel=1; clocks(1);
  if(waiting || request) $fatal(1,"manual cancel must win simultaneous fault");
  @(negedge clk); fault=0; cancel=0;
  fail_event(); sample(0); @(negedge clk); rst_n=0; clocks(3);
  if(waiting || request || dut.low_count) $fatal(1,"reset failed to clear recovery");
  wait(default_done);
  $display("PASS recovery: default20 samples, signed speed bounds, fresh post-encoder samples, consecutive low count, cancel priority, acknowledgment, disable and reset");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

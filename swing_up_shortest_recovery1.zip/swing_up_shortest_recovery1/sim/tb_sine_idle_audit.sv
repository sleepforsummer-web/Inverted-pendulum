`timescale 1ns/1ps
// 两个顶层使用同一组测量输入：隔离传感器、机械和手扶动作差异。
// 除手动启动按键重映射外，不启动任何运动，逐次比较完整PID输出。
module tb_sine_idle_audit;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,mtick=0,ptick=0,dip=1;
 reg [3:0] new_keys=15,old_keys=15;
 reg signed [16:0] pos=0;
 reg signed [15:0] speed=0;
 reg signed [12:0] angle=0;
 reg [11:0] adc=1957;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.AUTO_RECOVER_ENABLE(0)) now_dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(new_keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 audit_old_pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.AUTO_RECOVER_ENABLE(0)) old_dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(old_keys),.fuzzy_sw_n(dip),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
 task reset_all;
  @(negedge clk);rst_n=0;new_keys=15;old_keys=15;angle=0;pos=0;speed=0;adc=1957;
  mtick=0;ptick=0;clocks(4);@(negedge clk);rst_n=1;clocks(12);
 endtask
 task start(input bit manual_mode);
  @(negedge clk);new_keys=manual_mode?13:14;old_keys=manual_mode?11:14;
  clocks(12);@(negedge clk);new_keys=15;old_keys=15;clocks(12);
 endtask
 integer index=0,inner=0,outer=0;
 integer compared=0;
 integer main_clocks_compared=0;
 // 额外逐50MHz主时钟比较执行输出，不能只看每个采样稳定后的数值。
 always @(posedge clk) begin
  #3;
  if(rst_n) begin
   if({now_dut.PWMA,now_dut.AN1,now_dut.AN2,now_dut.pid_valid,now_dut.pid_sum,now_dut.duty} !==
      {old_dut.PWMA,old_dut.AN1,old_dut.AN2,old_dut.pid_valid,old_dut.pid_sum,old_dut.duty})
    $fatal(1,"per-clock motor/inner result mismatch frame=%0d inner=%0d",index,inner);
   main_clocks_compared=main_clocks_compared+1;
  end
 end
 task check;
  if(now_dut.running!==old_dut.running || now_dut.control_enable!==old_dut.control_enable)
   $fatal(1,"enable mismatch frame=%0d inner=%0d",index,inner);
  if(now_dut.position_target_q16!==old_dut.position_target_q16 ||
     now_dut.motion_limit_active!==old_dut.motion_limit_active || now_dut.motion_profile_active!==0)
   $fatal(1,"unrequested motion / target mismatch frame=%0d",index);
  if({now_dut.theta_ref,now_dut.outer_p_mon,now_dut.outer_i_mon,now_dut.outer_d_mon,
      now_dut.outer_active_limit,now_dut.outer_limit_phase} !==
     {old_dut.theta_ref,old_dut.outer_p_mon,old_dut.outer_i_mon,old_dut.outer_d_mon,
      old_dut.outer_active_limit,old_dut.outer_limit_phase})
   $fatal(1,"outer mismatch frame=%0d inner=%0d newref=%0d oldref=%0d newP=%0d oldP=%0d newD=%0d oldD=%0d",index,inner,
    now_dut.theta_ref,old_dut.theta_ref,now_dut.outer_p_mon,old_dut.outer_p_mon,now_dut.outer_d_mon,old_dut.outer_d_mon);
  if({now_dut.error,now_dut.pid_sum,now_dut.duty,now_dut.p_mon,now_dut.i_mon,now_dut.d_mon} !==
     {old_dut.error,old_dut.pid_sum,old_dut.duty,old_dut.p_mon,old_dut.i_mon,old_dut.d_mon})
   $fatal(1,"inner mismatch frame=%0d inner=%0d duty new=%0d old=%0d",index,inner,now_dut.duty,old_dut.duty);
  compared=compared+1;
 endtask
 task pulse;
  @(negedge clk);mtick=1;ptick=(inner==0);clocks(1);
  @(negedge clk);mtick=0;ptick=0;clocks(63);check();
 endtask
 integer scenario,n;
 initial begin
  force now_dut.position=pos;force old_dut.position=pos;
  force now_dut.speed=speed;force old_dut.speed=speed;
  force now_dut.theta=angle;force old_dut.theta=angle;
  force now_dut.filtered_raw=adc;force old_dut.filtered_raw=adc;
  force now_dut.adc_valid=1'b1;force old_dut.adc_valid=1'b1;
  force now_dut.tick=mtick;force old_dut.tick=mtick;
  force now_dut.pos_tick=ptick;force old_dut.pos_tick=ptick;
  for(scenario=0;scenario<2;scenario=scenario+1)begin
   dip=1;reset_all();start(scenario==0);
   for(index=0;index<650;index=index+1)begin
    @(negedge clk);
    if(index<20)begin pos=0;speed=0;angle=0;end
    else if(index<140)begin pos=index<110 ? 1600 : 0;speed=index<80 ? 15 : -12;angle=index<80 ? 85 : -95;end
    else if(index<200)begin pos=0;speed=0;angle=0;end
    else begin
     pos=$signed($random)%1500;speed=$signed($random)%30;angle=$signed($random)%130;
    end
    adc=1957-angle;
    for(inner=0;inner<10;inner=inner+1)pulse();
   end
   if(!now_dut.control_enable)$fatal(1,"scenario never entered balance");
  end
  $display("PASS idle balance audit: %0d inner samples, %0d main clocks, manual+auto, fixed PD before/after removal, disturbances, no motion keys; outputs bit exact",compared,main_clocks_compared);
  $finish;
 end
 initial begin #40000000;$fatal(1,"audit timeout");end
endmodule

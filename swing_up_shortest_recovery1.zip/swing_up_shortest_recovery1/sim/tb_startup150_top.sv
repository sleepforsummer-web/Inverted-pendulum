`timescale 1ns/1ps
module tb_startup150_top;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,mtick=0,ptick=0;
 reg [3:0] keys=15;
 reg [11:0] adc=0;
 reg signed [12:0] angle=1957;
 reg signed [16:0] pos=0;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.RECOVER_LOW_SAMPLES(2)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),.PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 task clocks(input integer n);repeat(n)begin @(posedge clk);#2;end endtask
 task press(input integer key);
  @(negedge clk);keys=15^(1<<key);clocks(12);@(negedge clk);keys=15;clocks(12);
 endtask
 task ms(input integer n);
  repeat(n)begin @(negedge clk);mtick=1;clocks(1);@(negedge clk);mtick=0;clocks(4);end
 endtask
 task outer_sample(input integer expected_cap);
  @(negedge clk);ptick=1;clocks(1);@(negedge clk);ptick=0;clocks(40);
  if(dut.outer_active_limit!=expected_cap) $fatal(1,"top startup cap %0d/%0d",dut.outer_active_limit,expected_cap);
 endtask
 task upright;
  @(negedge clk);adc=dut.UPRIGHT_ADC;angle=0;ms(60);clocks(45);
  if(!dut.control_enable || dut.manual_mode) $fatal(1,"automatic capture failed");
 endtask
 integer n;
 initial begin
  force dut.filtered_raw=adc;force dut.theta=angle;force dut.adc_valid=1'b1;
  force dut.position=pos;force dut.speed=16'sd0;force dut.tick=mtick;force dut.pos_tick=ptick;
  clocks(3);@(negedge clk);rst_n=1;clocks(12);press(0);
  if(!dut.running || dut.control_enable) $fatal(1,"KEY1 did not start swing-up");
  upright();outer_sample(150);
  for(n=1;n<(dut.OUTER_STARTUP_LIMIT_MS+9)/10;n=n+1) outer_sample(150);
  // 满设定时长仍在区外，150也必须结束，直接转常规大限幅并重新计时。
  @(negedge clk);pos=dut.OUTER_LIMIT_POSITION_COUNTS+20;outer_sample(dut.OUTER_LIMIT_FAR_ADC);
  if(dut.outer_limit_phase!=7 || dut.position_control.startup_boost_active)
   $fatal(1,"startup150 continued beyond1s outside position window");
  @(negedge clk);pos=0;
  for(n=1;n<(dut.OUTER_LIMIT_MIN_MS+9)/10;n=n+1) outer_sample(dut.OUTER_LIMIT_FAR_ADC);
  outer_sample(40);
  @(negedge clk);pos=dut.OUTER_LIMIT_POSITION_COUNTS+20;outer_sample(dut.OUTER_LIMIT_FAR_ADC);
  repeat(110) outer_sample(dut.OUTER_LIMIT_FAR_ADC);
  @(negedge clk);pos=0;outer_sample(40);
  // 跌落后的自动恢复会重新捕获目标，并且只在新的接管时再执行一次150。
  @(negedge clk);adc=0;angle=dut.UPRIGHT_ADC;clocks(8);
  if(dut.running || !dut.recovery_waiting) $fatal(1,"fall did not request recovery");
  outer_sample(40);outer_sample(40);clocks(6);
  if(!dut.running || dut.control_enable) $fatal(1,"low-speed automatic recovery failed");
  @(negedge clk);pos=-70;
  upright();outer_sample(150);
  if(dut.position_error!=-70 || dut.position_target_q16!=0) $fatal(1,"recovery nearest target changed");
  // KEY2清除一次性状态，KEY3手动启动保持40/110，不强制150。
  press(0);clocks(5);
  if(dut.running || dut.position_control.startup_boost_active) $fatal(1,"stop failed to clear startup flag");
  @(negedge clk);pos=0;press(1);outer_sample(40);
  if(!dut.manual_mode) $fatal(1,"KEY3 manual start failed");
  @(negedge clk);pos=dut.OUTER_LIMIT_POSITION_COUNTS+20;outer_sample(dut.OUTER_LIMIT_FAR_ADC);
  $display("PASS top startup150: KEY1 capture, exact1s at zero, later110 only, fall/recovery150 with new target, KEY2 clear, KEY3 unchanged");$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

from pathlib import Path
import sys
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent))
from serial_commands import encode_position_command
data=encode_position_command(90,45,17)+encode_position_command(-180,360,18)
(here/'serial_commands.hex').write_text('\n'.join(f'{b:02x}' for b in data)+'\n',encoding='ascii')
print('Generated real Python command frames for RTL UART tests')

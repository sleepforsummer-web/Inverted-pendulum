`timescale 1ns/1ps
module tb_motion_load;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,enable=0,tick=0,event_in=0,load=0;
 reg signed [16:0] position=0;
 wire signed [32:0] target;
 wire busy,valid,rejected;
 move90 #(.MOVE_TICKS(3)) dut(
  .clk(clk),.rst_n(rst_n),.enable(enable),.sample_tick(tick),.start_event(event_in),
  .load_target(load),.load_position(position),.target_q16(target),.busy(busy),
  .target_valid(valid),.range_rejected(rejected),.motion_active());
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task anchor(input integer value);
  @(negedge clk); load=1; position=value; clocks(1);
  if(target!==(value*64'sd65536) || busy || !valid || rejected || dut.pending_start || dut.remaining)
   $fatal(1,"signed target load/clear failed %0d",value);
  @(negedge clk); load=0; enable=1; event_in=0; tick=0; clocks(3);
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(3);
 endtask
 initial begin
  clocks(3); @(negedge clk); rst_n=1;
  anchor(-700); // 即使enable=0，装载也必须优先，下一拍开启后保持。
  @(negedge clk); event_in=1; clocks(1);
  @(negedge clk); event_in=0; sample();
  if(!busy) $fatal(1,"motion not started after load");
  @(negedge clk); event_in=1; tick=1; // 装载优先于同拍旧运动更新/新按键。
  anchor(950); sample();
  if(target!=33'sd62259200 || busy) $fatal(1,"old pending motion survived load");
  anchor(65535); @(negedge clk); event_in=1; sample();
  if(!rejected || target!=33'sd4294901760 || busy) $fatal(1,"range guard ignored absolute loaded target");
  anchor(-65536); if(target!=-33'sd4294967296) $fatal(1,"negative extreme sign extension");
  @(negedge clk); load=1; position=100; rst_n=0; clocks(3);
  if(target || busy || valid) $fatal(1,"global reset must win target load");
  $display("PASS motion load: signed seed, enable/start/tick priority, task cancellation, range guard and reset");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

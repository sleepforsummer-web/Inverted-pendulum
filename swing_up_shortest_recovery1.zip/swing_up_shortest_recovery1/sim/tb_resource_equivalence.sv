`timescale 1ns/1ps
// 与本次修改前的固定备份比较，检查数值和valid逐时钟一致；非仅比较最终状态。
module resource_pid_case #(parameter integer FILTER=3, KI=65, IMAX=524288)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1,en=0,tick=0,clear_i=0,motion=0;
 reg signed [16:0] e=0,measure=0;
 reg signed [32:0] eq=0;
 wire signed [50:0] sum_n,sum_o;
 wire vn,vo; wire signed [15:0] pn,in_,dn,po,io_,do_;
 pid_controller #(.KP_Q(406323),.KD_Q(6029312),.KI_Q(KI),.D_FILTER_SHIFT(FILTER),.ERROR_INPUT_LIMIT(100)) n(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.error(e),.d_input(measure),
  .pid_sum(sum_n),.pid_valid(vn),.p_mon(pn),.i_mon(in_),.d_mon(dn));
 original_pid_controller #(.KP_Q(406323),.KD_Q(6029312),.KI_Q(KI),.D_FILTER_SHIFT(FILTER),.ERROR_INPUT_LIMIT(100)) o(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.error(e),.d_input(measure),
  .pid_sum(sum_o),.pid_valid(vo),.p_mon(po),.i_mon(io_),.d_mon(do_));
 wire signed [48:0] int_n,int_o; wire ivn,ivo;
 pid_i #(.Ki(KI),.I_MAX(IMAX),.I_SEP_THRESHOLD(65535)) ni(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.error(e),.i(int_n),.i_valid(ivn));
 original_pid_i #(.Ki(KI),.I_MAX(IMAX),.I_SEP_THRESHOLD(65535)) oi(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.error(e),.i(int_o),.i_valid(ivo));
 wire [132:0] outer_n,outer_o;
 position_controller #(.Kp_pos(19661),.Kd_pos(1114112),.Ki_pos(KI),.I_POS_MAX_Q(IMAX),
  .USE_Q16_POSITION(1),.D_ON_MEASUREMENT(1),.D_FILTER_SHIFT(FILTER),.LIMIT_SWITCH_ENABLE(1),
  .LIMIT_BOOST_MIN_MS(30),.POSITION_SAMPLE_MS(10)) np(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.position_error(e),.position_error_q16(eq),
  .position_measurement(measure),.integral_clear(clear_i),.motion_active(motion),
  .theta_ref(outer_n[132:116]),.theta_ref_valid(outer_n[115]),.p_pos_mon(outer_n[114:83]),
  .d_pos_mon(outer_n[82:51]),.i_pos_mon(outer_n[50:19]),.limited_mon(outer_n[18]),
  .active_limit_mon(outer_n[17:1]),.boost_active_mon(outer_n[0]));
 original_position_controller #(.Kp_pos(19661),.Kd_pos(1114112),.Ki_pos(KI),.I_POS_MAX_Q(IMAX),
  .USE_Q16_POSITION(1),.D_ON_MEASUREMENT(1),.D_FILTER_SHIFT(FILTER),.LIMIT_SWITCH_ENABLE(1),
  .LIMIT_BOOST_MIN_MS(30),.POSITION_SAMPLE_MS(10)) op(
  .clk(clk),.rst(rst),.enable(en),.sample_tick(tick),.position_error(e),.position_error_q16(eq),
  .position_measurement(measure),.integral_clear(clear_i),.motion_active(motion),
  .theta_ref(outer_o[132:116]),.theta_ref_valid(outer_o[115]),.p_pos_mon(outer_o[114:83]),
  .d_pos_mon(outer_o[82:51]),.i_pos_mon(outer_o[50:19]),.limited_mon(outer_o[18]),
  .active_limit_mon(outer_o[17:1]),.boost_active_mon(outer_o[0]));
 integer j; reg [31:0] random_state=32'h79213485;
 initial begin
  repeat(4) @(negedge clk);
  for(j=0;j<30000;j=j+1) begin
   random_state={random_state[30:0],random_state[31]^random_state[21]^random_state[1]^random_state[0]};
   rst=(j%1777==0); en=(j%131<124); tick=random_state[0] || (j%10==0);
   clear_i=(j%337<7); motion=(j%201<31);
   case(j%32)
    0:e=-65536; 1:e=65535; 2:e=-1; 3:e=0; 4:e=1;
    5:e=-50; 6:e=50; 7:e=-49; 8:e=49;
    default:e=random_state[16:0];
   endcase
   measure=(j%2) ? -65536 : 65535;
   if(j%7>3) measure=random_state[16:0];
   eq=$signed({e,16'b0})+$signed({17'b0,random_state[15:0]});
   @(posedge clk); #2;
   if({sum_n,vn,pn,in_,dn} !== {sum_o,vo,po,io_,do_})
    $fatal(1,"inner mismatch FILTER=%0d KI=%0d j=%0d",FILTER,KI,j);
   if({int_n,ivn} !== {int_o,ivo}) $fatal(1,"integral mismatch KI=%0d I_MAX=%0d j=%0d",KI,IMAX,j);
   if(outer_n !== outer_o) $fatal(1,"outer mismatch FILTER=%0d KI=%0d j=%0d",FILTER,KI,j);
   @(negedge clk);
  end
  done=1;
 end
endmodule

module resource_swing_case #(parameter integer PERIOD=20,PULSE=100,START=200)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,en=0,tick=0,valid=0;
 reg [11:0] adc=0;
 wire [24:0] n,o;
 swing_up #(.SAMPLE_PERIOD_MS(PERIOD),.PULSE_MS(PULSE),.START_KICK_MS(START)) sn(
  .clk(clk),.rst_n(rst_n),.enable(en),.tick_1ms(tick),.adc_valid(valid),.adc_value(adc),
  .balance_mode(n[24]),.pulse_active(n[23]),.duty_command(n[22:6]),.state(n[5:3]),.peak_event(n[2]),.peak_region(n[1:0]));
 original_swing_up #(.SAMPLE_PERIOD_MS(PERIOD),.PULSE_MS(PULSE),.START_KICK_MS(START)) so(
  .clk(clk),.rst_n(rst_n),.enable(en),.tick_1ms(tick),.adc_valid(valid),.adc_value(adc),
  .balance_mode(o[24]),.pulse_active(o[23]),.duty_command(o[22:6]),.state(o[5:3]),.peak_event(o[2]),.peak_region(o[1:0]));
 integer j;
 initial begin
  repeat(4) @(negedge clk);
  for(j=0;j<12000;j=j+1) begin
   rst_n=(j%3001!=0); en=(j%2400<2350); tick=(j%4!=0); valid=(j%3==0);
   if(j%2400<450) adc=0;
   else case((j/40)%8)
    0:adc=3000;1:adc=2500;2:adc=3000;3:adc=900;
    4:adc=1400;5:adc=900;default:adc=1958;
   endcase
   @(posedge clk); #2;
   if(n !== o) $fatal(1,"swing mismatch PERIOD=%0d PULSE=%0d START=%0d j=%0d",PERIOD,PULSE,START,j);
   @(negedge clk);
  end
  done=1;
 end
endmodule

module resource_top_case(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0;
 reg [3:0] keys=15; reg [9:0] adc=488;
 reg [1:0] encoder=0;
 reg tick=0,ptick=0;
 wire [8:0] n,o;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.RECOVER_LOW_SAMPLES(3)) nt(
  .clk_50m(clk),.rst_n(rst_n),.key_sw(keys),.adc_data_in(adc),.enc_a(encoder[1]),.enc_b(encoder[0]),
  .adc_clk(n[8]),.adc_oe_n(n[7]),.uart_tx(n[6]),.PWMA(n[5]),.AN1(n[4]),.AN2(n[3]),.PWMB(n[2]),.BN1(n[1]),.BN2(n[0]));
 original_pid_trial #(.KEY_DEBOUNCE_CYCLES(4),.RECOVER_LOW_SAMPLES(3)) ot(
  .clk_50m(clk),.rst_n(rst_n),.key_sw(keys),.adc_data_in(adc),.enc_a(encoder[1]),.enc_b(encoder[0]),
  .adc_clk(o[8]),.adc_oe_n(o[7]),.uart_tx(o[6]),.PWMA(o[5]),.AN1(o[4]),.AN2(o[3]),.PWMB(o[2]),.BN1(o[1]),.BN2(o[0]));
 integer j,phase; integer states=0; integer frames=0;
 initial begin
  force nt.tick=tick; force ot.tick=tick; force nt.pos_tick=ptick; force ot.pos_tick=ptick;
  repeat(4) @(negedge clk);
  for(j=0;j<650000;j=j+1) begin
   rst_n=(j%100000!=0); tick=(j%7==0); ptick=(j%70==0);
   phase=j%100000; keys=15;
   if(phase>=30 && phase<50) keys=11; // KEY3手动PID。
   if(phase>=3000 && phase<3020) keys=7; // KEY4轨迹。
   if(phase>=15000 && phase<15020) keys=13; // KEY2停机。
   if(phase>=36000 && phase<36020) keys=14; // 等32us块平均和IIR均稳定到底部后KEY1起摆。
   if(phase>=80000 && phase<80020) keys=14; // 人工停止/再次启动。
   if(phase<16000 || phase>55000) adc=488+(j/113)%9-4;
   else if(phase<41000) adc=0;
   else case((phase/350)%6)
    0:adc=750;1:adc=650;2:adc=750;3:adc=225;4:adc=350;5:adc=225;
   endcase
   case((j/50)%4)
    0:encoder=0;1:encoder=1;2:encoder=3;3:encoder=2;
   endcase
   @(posedge clk); #2;
   states=states|(1<<nt.swing_state);
   if(nt.byte_index==0 && nt.bit_index==0 && nt.baud_count==0) frames=frames+1;
   if(n !== o) $fatal(1,"top external outputs differ at j=%0d",j);
   if({nt.running,nt.duty,nt.theta_ref,nt.outer_p_mon,nt.outer_i_mon,nt.outer_d_mon,
       nt.pid_sum,nt.pid_valid,nt.p_mon,nt.i_mon,nt.d_mon,nt.stop_reason,nt.stop_theta} !==
      {ot.running,ot.duty,ot.theta_ref,ot.outer_p_mon,ot.outer_i_mon,ot.outer_d_mon,
       ot.pid_sum,ot.pid_valid,ot.p_mon,ot.i_mon,ot.d_mon,ot.stop_reason,ot.stop_theta})
    $fatal(1,"top controller/diagnostic outputs differ at j=%0d",j);
   @(negedge clk);
  end
  if(frames<2 || !(states&16) || !(states&32) || !(states&128))
   $fatal(1,"inadequate top coverage frames=%0d states=%h",frames,states);
  $display("PASS differential top:650000 cycles, complete UART/PWM pins, PID/trajectory/swing/recovery state mask=%h frames=%0d",states,frames);
  done=1;
 end
endmodule

module tb_resource_equivalence;
 wire [12:0] done;
 resource_pid_case #(.FILTER(0),.KI(0),.IMAX(0)) p0(done[0]);
 resource_pid_case #(.FILTER(1),.KI(65),.IMAX(524288)) p1(done[1]);
 resource_pid_case #(.FILTER(3),.KI(-65),.IMAX(1)) p3(done[2]);
 resource_pid_case #(.FILTER(8),.KI(2147483647),.IMAX(6553600)) p8(done[3]);
 resource_pid_case #(.FILTER(3),.KI(-2147483648),.IMAX(6553600)) pn(done[4]);
 resource_pid_case #(.FILTER(3),.KI(6029312),.IMAX(2147483647)) pm(done[5]);
 resource_swing_case #(.PERIOD(1),.PULSE(1),.START(1)) s1(done[6]);
 resource_swing_case #(.PERIOD(20),.PULSE(100),.START(200)) s20(done[7]);
 resource_swing_case #(.PERIOD(257),.PULSE(513),.START(300)) s257(done[8]);
 resource_swing_case #(.PERIOD(0),.PULSE(0),.START(0)) s0(done[9]);
 resource_swing_case #(.PERIOD(-1),.PULSE(1),.START(0)) sn(done[10]);
 resource_swing_case #(.PERIOD(40),.PULSE(100),.START(100)) s40(done[11]);
 resource_top_case top(done[12]);
 initial begin wait(&done);
  $display("PASS resource equivalence:6 PID/I parameter sets x30000 cycles,6 swing settings x12000 cycles,650000-cycle top/UART/PWM comparison to immutable original");
  $finish;
 end
 initial begin #20000000; $fatal(1,"equivalence timeout"); end
endmodule

`timescale 1ns/1ps
module sine_equivalence_case #(parameter integer T=800, A=90)(output reg done=0);
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,en=0,tick=0,key=0,load=0;
 reg signed [16:0] position=0;
 reg signed [15:0] speed=0;
 reg signed [12:0] theta=0;
 wire signed [32:0] target,ref_target;
 wire busy,valid,rejected,active,arrived,request_rejected,stop_pending;
 wire rb,rv,rr,ra,rarr,rreq,rstop;
 wire [2:0] state,rs;
 sine_motion #(.AMPLITUDE_DEG(A),.PERIOD_TICKS(T)) dut(
  .clk(clk),.rst_n(rst_n),.enable(en),.sample_tick(tick),.start_event(key),.start_anchor_q16(33'sd0),
  .load_target(load),.load_position(position),.actual_speed(speed),.theta(theta),
  .target_q16(target),.busy(busy),.target_valid(valid),.range_rejected(rejected),
  .motion_active(active),.arrived(arrived),.request_rejected(request_rejected),
  .stop_pending_mon(stop_pending),.state_mon(state));
 sine_reference #(.AMPLITUDE_DEG(A),.PERIOD_TICKS(T)) reference(
  .clk(clk),.rst_n(rst_n),.enable(en),.sample_tick(tick),.start_event(key),
  .load_target(load),.load_position(position),.actual_speed(speed),.theta(theta),
  .target_q16(ref_target),.busy(rb),.target_valid(rv),.range_rejected(rr),
  .motion_active(ra),.arrived(rarr),.request_rejected(rreq),.stop_pending_mon(rstop),.state_mon(rs));
 always @(posedge clk)begin
  #2;
  if(rst_n && ({target,busy,valid,rejected,active,request_rejected,stop_pending,state} !==
              {ref_target,rb,rv,rr,ra,rreq,rstop,rs}))
   $fatal(1,"sine optimization changed output T%0d A%0d phase%0d target%0d/%0d state%0d/%0d valid%0d/%0d",
     T,A,dut.cycle_tick,target,ref_target,state,rs,valid,rv);
 end
 task clocks(input integer n);repeat(n)begin @(posedge clk);#3;end endtask
 task sample;@(negedge clk);tick=1;clocks(1);@(negedge clk);tick=0;clocks(12);endtask
 task press;@(negedge clk);key=1;clocks(1);@(negedge clk);key=0;clocks(3);endtask
 task anchor(input integer value);
  @(negedge clk);load=1;position=value;clocks(1);@(negedge clk);load=0;clocks(5);
 endtask
 integer n;
 longint max_abs,mag;
 initial begin
  clocks(3);@(negedge clk);rst_n=1;en=1;clocks(4);
  // 正负边界包含，超界拒绝；不满足启动条件不能排队。
  theta=101;press();sample();if(!request_rejected||busy)$fatal(1,"angle rejection");
  theta=0;speed=4;press();sample();if(!request_rejected||busy)$fatal(1,"speed rejection");
  speed=0;press();sample();max_abs=0;
  for(n=0;n<3*T;n=n+1)begin
   sample();mag=target<0 ? -target : target;if(mag>max_abs)max_abs=mag;
  end
  if(state!=2 || max_abs<dut.AMPLITUDE_Q16*99/100 || max_abs>dut.AMPLITUDE_Q16)
   $fatal(1,"wrong steady sine amplitude");
  press();repeat(2*T+10)sample();
  if(state!=0||target!=0||!arrived)$fatal(1,"smooth stop did not hold center");
  // 渐入中请求停止也要按原周期边界渐出，不突跳目标。
  anchor(-100);press();sample();repeat(7)sample();press();repeat(3*T+20)sample();
  if(target!=(-100*64'sd65536)||busy)$fatal(1,"fade-in stop/negative center");
  anchor(65535);press();sample();if(!rejected||busy)$fatal(1,"range guard failed");
  anchor(-65536);press();sample();if(!rejected||busy)$fatal(1,"negative range guard failed");
  anchor(12);press();repeat(10)sample();
  @(negedge clk);en=0;clocks(4);if(target||busy||valid)$fatal(1,"disable failed");
  @(negedge clk);rst_n=0;clocks(3);done=1;
 end
endmodule
module tb_sine_equivalence;
 wire a,b,c;
 sine_equivalence_case #(.T(800),.A(90)) c0(a);
 sine_equivalence_case #(.T(137),.A(30)) c1(b);
 sine_equivalence_case #(.T(100),.A(180)) c2(c);
 initial begin wait(a&&b&&c);
  $display("PASS optimized sine: bit-exact targets/valid/state versus supplied original at800/137/100ticks, amplitudes90/30/180, start guards, fade-in/out, range/load/reset");$finish;
 end
 initial begin #20000000;$fatal(1,"timeout");end
endmodule

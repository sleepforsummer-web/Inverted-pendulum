`timescale 1ns/1ps
module tb_shortest_recovery;
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0, enable=0;
 reg signed [32:0] saved=0;
 reg signed [16:0] position=0;
 wire signed [32:0] result;
 wire ready;
 shortest_recovery dut(.clk(clk),.rst_n(rst_n),.enable(enable),.saved_target_q16(saved),.position(position),.result_q16(result),.ready(ready));
 task clocks(input integer n); repeat(n) begin @(posedge clk); #2; end endtask
 task check(input longint target_q, input integer actual, input longint expected_q);
  @(negedge clk); enable=0; clocks(2);
  @(negedge clk); saved=target_q; position=actual; enable=1; clocks(40);
  if(!ready || $signed(result)!==expected_q)
   $fatal(1,"target=%0d position=%0d expected=%0d got=%0d ready=%0d",target_q,actual,expected_q,$signed(result),ready);
 endtask
 initial begin
  clocks(2); rst_n=1;
  check(0,800,1080*65536);
  check(0,280,0);
  check(0,-800,-1080*65536);
  check(0,-280,0);
  check(0,540,0);
  check(0,-540,0);
  check(0,541,1080*65536);
  check(0,-541,-1080*65536);
  check(100*65536+16384,2260,2260*65536+16384);
  check(-100*65536-16384,-2260,-2260*65536-16384);
  check(0,65535,64800*65536);
  check(0,-65536,-64800*65536);
  @(negedge clk); enable=0; clocks(2);
  @(negedge clk); enable=1; clocks(10); enable=0; clocks(3);
  if(ready) $fatal(1,"cancellation retained result");
  check(0,1090,1080*65536);
  $display("PASS shortest recovery: signed, multi-turn, half-turn ties, fractional targets, range limits, cancellation");
  $finish;
 end
 initial begin #200000; $fatal(1,"timeout"); end
endmodule

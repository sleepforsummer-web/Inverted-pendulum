// ============================================================
// sine_motion.v
//
// 每10ms更新一次位置目标。
// KEY4：启动 / 请求平滑停止。
//
// 正常运行：
// target = anchor + amplitude * sin(2*pi*t/T)
//
// 启动：一个周期内使用余弦包络逐渐增加幅值。
// 停止：等到周期边界，再用一个周期逐渐减小幅值。
// 最终保持anchor，不关闭平衡控制。
//
// load_target：自动恢复后重设anchor，取消旧运动。
// !enable：取消运动，target和anchor恢复为0，
//          与原顶层首次启动保留复位零点的逻辑一致。
//
// 参数要求：
// COUNTS_PER_REV > 0
// AMPLITUDE_DEG > 0
// PERIOD_TICKS >= 100
// PERIOD_TICKS不应大到超出32位计数范围。
//
// 当前推荐：1073计数/圈，±30°，8秒周期。
// ============================================================

module sine_reference #(
    parameter integer COUNTS_PER_REV = 1073,
    parameter integer AMPLITUDE_DEG = 30,

    // 每个节拍10ms：800对应8秒。
    parameter integer PERIOD_TICKS = 800,

    // 启动请求允许的实际状态范围。
    parameter integer START_THETA_ADC = 100,
    parameter integer START_SPEED = 3
)(
    input wire clk,
    input wire rst_n,
    input wire enable,
    input wire sample_tick,
    input wire start_event,

    input wire load_target,
    input wire signed [16:0] load_position,

    input wire signed [15:0] actual_speed,
    input wire signed [12:0] theta,

    output reg signed [32:0] target_q16,
    output wire busy,
    output reg target_valid,

    output reg range_rejected,
    output wire motion_active,

    output reg arrived,
    output reg request_rejected,
    output wire stop_pending_mon,
    output wire [2:0] state_mon
);

    localparam [2:0] IDLE    = 3'd0;
    localparam [2:0] FADE_IN = 3'd1;
    localparam [2:0] RUN     = 3'd2;
    localparam [2:0] FADE_OUT= 3'd3;

    localparam integer SAFE_PERIOD =
        (PERIOD_TICKS >= 100) ? PERIOD_TICKS : 100;

    // 编码器计数，保留16位小数。
    localparam signed [63:0] AMPLITUDE_Q16 =
        (64'sd65536 * COUNTS_PER_REV * AMPLITUDE_DEG) / 360;

    localparam signed [63:0] TARGET_MAX =
        64'sd4294901760;

    localparam signed [63:0] TARGET_MIN =
        -64'sd4294967296;

    reg [2:0] state;
    reg sample_d;

    reg signed [32:0] anchor_q16;

    reg start_pending;
    reg stop_pending;

    reg [31:0] cycle_tick;
    reg [31:0] envelope_tick;

    assign busy =
        enable && (start_pending || state != IDLE);

    assign motion_active =
        enable && !load_target &&
        (start_pending || state != IDLE);

    assign stop_pending_mon = stop_pending;
    assign state_mon = state;

    wire start_angle_ok =
        ($signed(theta) >= -START_THETA_ADC) &&
        ($signed(theta) <=  START_THETA_ADC);

    wire start_speed_ok =
        ($signed(actual_speed) >= -START_SPEED) &&
        ($signed(actual_speed) <=  START_SPEED);

    wire signed [63:0] anchor_ext = $signed(anchor_q16);

    // 在开始动作前检查整个左右摆幅，避免运动中目标溢出。
    wire trajectory_in_range =
        (anchor_ext + AMPLITUDE_Q16 <= TARGET_MAX) &&
        (anchor_ext - AMPLITUDE_Q16 >= TARGET_MIN);

    // --------------------------------------------------------
    // 四分之一正弦查找表，数值范围0~32768。
    // 对应0、pi/32、2*pi/32……pi/2。
    // --------------------------------------------------------
    function [15:0] quarter_lut;
        input [4:0] index;
        begin
            case(index)
                5'd0:  quarter_lut = 16'd0;
                5'd1:  quarter_lut = 16'd3212;
                5'd2:  quarter_lut = 16'd6393;
                5'd3:  quarter_lut = 16'd9512;
                5'd4:  quarter_lut = 16'd12540;
                5'd5:  quarter_lut = 16'd15447;
                5'd6:  quarter_lut = 16'd18205;
                5'd7:  quarter_lut = 16'd20788;
                5'd8:  quarter_lut = 16'd23170;
                5'd9:  quarter_lut = 16'd25330;
                5'd10: quarter_lut = 16'd27246;
                5'd11: quarter_lut = 16'd28899;
                5'd12: quarter_lut = 16'd30274;
                5'd13: quarter_lut = 16'd31357;
                5'd14: quarter_lut = 16'd32138;
                5'd15: quarter_lut = 16'd32610;
                default: quarter_lut = 16'd32768;
            endcase
        end
    endfunction

    // --------------------------------------------------------
    // 1024相位点的完整正弦。
    //
    // phase=0    -> 0
    // phase=256  -> +32768
    // phase=512  -> 0
    // phase=768  -> -32768
    //
    // 输出17位有符号，实际值=输出/32768。
    // --------------------------------------------------------
    function signed [16:0] sine_q15;
        input [9:0] phase;

        reg [8:0] coordinate;
        reg [4:0] index;
        reg [3:0] fraction;

        reg [15:0] value0;
        reg [15:0] value1;
        reg [15:0] difference;

        reg [31:0] interpolation;
        reg [31:0] magnitude_calc;
        reg [16:0] magnitude;
        begin
            case(phase[9:8])
                2'd0:
                    coordinate = {1'b0, phase[7:0]};
                2'd1:
                    coordinate =
                        9'd256 - {1'b0, phase[7:0]};
                2'd2:
                    coordinate = {1'b0, phase[7:0]};
                default:
                    coordinate =
                        9'd256 - {1'b0, phase[7:0]};
            endcase

            index = coordinate[8:4];
            fraction = coordinate[3:0];

            if(coordinate == 9'd256) begin
                magnitude = 17'd32768;
            end
            else begin
                value0 = quarter_lut(index);
                value1 = quarter_lut(index + 5'd1);
                difference = value1 - value0;

                interpolation = difference * fraction;

                magnitude_calc =
                   {16'b0, value0} +
                   ((interpolation + 32'd8) >> 4);

                magnitude = magnitude_calc[16:0];
            end

            if(phase[9])
                sine_q15 = -$signed(magnitude);
            else
                sine_q15 = $signed(magnitude);
        end
    endfunction

    // --------------------------------------------------------
    // 计算流水线：
    // 1. 锁存相位；
    // 2. 查表；
    // 3. 计算幅值包络；
    // 4. 幅值乘正弦；
    // 5. 乘包络；
    // 6. 输出位置目标。
    //
    // 全部由50MHz主时钟驱动。
    // --------------------------------------------------------
    reg [5:0] valid_pipe;

    reg [9:0] phase_reg;
    reg [9:0] envelope_phase_reg;

    reg signed [16:0] sine_reg;
    reg signed [16:0] envelope_cos_reg;

    reg [16:0] envelope_q16_reg;
    reg [16:0] envelope_aligned_reg;

    reg signed [63:0] sine_distance_reg;
    reg signed [63:0] enveloped_distance_reg;

    wire [63:0] cycle_phase_calc =
        (64'd1024 * cycle_tick) / SAFE_PERIOD;

    // 渐入/渐出进度映射到0~pi，对应相位0~512。
    wire [63:0] envelope_phase_calc =
        (64'd512 * envelope_tick) / SAFE_PERIOD;

    wire [9:0] envelope_cos_phase =
        envelope_phase_reg + 10'd256;

    // 1-cos(pi*u)：从0平滑增加到2。
    wire signed [18:0] fade_in_q16 =
        19'sd32768 -
        $signed({{2{envelope_cos_reg[16]}},
                 envelope_cos_reg});

    // 1+cos(pi*u)：从2平滑减小到0。
    wire signed [18:0] fade_out_q16 =
        19'sd32768 +
        $signed({{2{envelope_cos_reg[16]}},
                 envelope_cos_reg});

    reg [2:0] state_d0;
    reg [2:0] state_d1;

    wire signed [63:0] sine_extended =
        $signed(sine_reg);

    wire signed [63:0] envelope_extended =
        $signed({1'b0, envelope_aligned_reg});

    wire signed [63:0] final_offset_q16 =
        enveloped_distance_reg >>> 16;

    wire signed [63:0] final_target_q16 =
        anchor_ext + final_offset_q16;

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state <= IDLE;
            sample_d <= 0;
            anchor_q16 <= 0;

            start_pending <= 0;
            stop_pending <= 0;

            cycle_tick <= 0;
            envelope_tick <= 0;

            target_q16 <= 0;
            target_valid <= 0;

            arrived <= 0;
            range_rejected <= 0;
            request_rejected <= 0;

            valid_pipe <= 0;
            phase_reg <= 0;
            envelope_phase_reg <= 0;

            sine_reg <= 0;
            envelope_cos_reg <= 0;
            envelope_q16_reg <= 0;
            envelope_aligned_reg <= 0;

            sine_distance_reg <= 0;
            enveloped_distance_reg <= 0;

            state_d0 <= IDLE;
            state_d1 <= IDLE;
        end
        else if(load_target) begin
            state <= IDLE;
            sample_d <= 0;

            anchor_q16 <=
                $signed({load_position, 16'b0});
            target_q16 <=
                $signed({load_position, 16'b0});

            start_pending <= 0;
            stop_pending <= 0;
            cycle_tick <= 0;
            envelope_tick <= 0;

            target_valid <= 1;
            arrived <= 0;
            range_rejected <= 0;
            request_rejected <= 0;

            valid_pipe <= 0;
            phase_reg <= 0;
            envelope_phase_reg <= 0;
            sine_reg <= 0;
            envelope_cos_reg <= 0;
            envelope_q16_reg <= 0;
            envelope_aligned_reg <= 0;
            sine_distance_reg <= 0;
            enveloped_distance_reg <= 0;
            state_d0 <= IDLE;
            state_d1 <= IDLE;
        end
        else if(!enable) begin
            state <= IDLE;
            sample_d <= 0;
            anchor_q16 <= 0;
            target_q16 <= 0;

            start_pending <= 0;
            stop_pending <= 0;

            cycle_tick <= 0;
            envelope_tick <= 0;

            target_valid <= 0;
            arrived <= 0;
            range_rejected <= 0;
            request_rejected <= 0;

            valid_pipe <= 0;
            phase_reg <= 0;
            envelope_phase_reg <= 0;
            sine_reg <= 0;
            envelope_cos_reg <= 0;
            envelope_q16_reg <= 0;
            envelope_aligned_reg <= 0;
            sine_distance_reg <= 0;
            enveloped_distance_reg <= 0;
            state_d0 <= IDLE;
            state_d1 <= IDLE;
        end
        else begin
            // 延迟一拍读取编码器更新后的speed。
            sample_d <= sample_tick;

            target_valid <= 0;
            valid_pipe <= {valid_pipe[4:0], 1'b0};

            // KEY4：空闲时启动，运行时请求平滑停止。
            if(start_event) begin
                if(state == IDLE && !start_pending) begin
                    start_pending <= 1;
                    request_rejected <= 0;
                end
                else if(state == FADE_IN || state == RUN) begin
                    stop_pending <= 1;
                end
                // 渐出期间重复按键忽略。
            end

            // 查表阶段。
            if(valid_pipe[0]) begin
                sine_reg <= sine_q15(phase_reg);
                envelope_cos_reg <=
                    sine_q15(envelope_cos_phase);
                state_d1 <= state_d0;
            end

            // 包络计算阶段。
            if(valid_pipe[1]) begin
                if(state_d1 == FADE_IN)
                    envelope_q16_reg <= fade_in_q16[16:0];
                else if(state_d1 == FADE_OUT)
                    envelope_q16_reg <= fade_out_q16[16:0];
                else
                    envelope_q16_reg <= 17'd65536;
            end

            // 正弦乘幅值。
            if(valid_pipe[2]) begin
                sine_distance_reg <=
                    (AMPLITUDE_Q16 * sine_extended) >>> 15;

                envelope_aligned_reg <= envelope_q16_reg;
            end

            // 乘启停幅值包络。
            if(valid_pipe[3]) begin
                enveloped_distance_reg <=
                    sine_distance_reg * envelope_extended;
            end

            // 输出位置目标。
            if(valid_pipe[4]) begin
                if(final_target_q16 > TARGET_MAX)
                    target_q16 <= TARGET_MAX[32:0];
                else if(final_target_q16 < TARGET_MIN)
                    target_q16 <= TARGET_MIN[32:0];
                else
                    target_q16 <= final_target_q16[32:0];

                target_valid <= 1;
            end

            if(sample_d) begin
                if(state == IDLE) begin
                    if(start_pending) begin
                        start_pending <= 0;

                        if(!start_angle_ok ||
                           !start_speed_ok) begin
                            request_rejected <= 1;
                        end
                        else if(!trajectory_in_range) begin
                            range_rejected <= 1;
                            request_rejected <= 1;
                        end
                        else begin
                            state <= FADE_IN;
                            cycle_tick <= 0;
                            envelope_tick <= 0;

                            stop_pending <= 0;
                            arrived <= 0;
                            range_rejected <= 0;
                            request_rejected <= 0;
                        end
                    end
                end
                else begin
                    // 本次10ms采样的相位和状态。
                    phase_reg <= cycle_phase_calc[9:0];
                    envelope_phase_reg <=
                        envelope_phase_calc[9:0];
                    state_d0 <= state;

                    valid_pipe[0] <= 1;

                    if(cycle_tick >= SAFE_PERIOD - 1)
                        cycle_tick <= 0;
                    else
                        cycle_tick <= cycle_tick + 1'b1;

                    case(state)
                        FADE_IN: begin
                            if(envelope_tick >= SAFE_PERIOD) begin
                                state <= RUN;
                                envelope_tick <= 0;
                            end
                            else
                                envelope_tick <=
                                    envelope_tick + 1'b1;
                        end

                        RUN: begin
                            envelope_tick <= 0;

                            // 从周期边界开始渐出，
                            // 使停止过程与完整正弦周期对齐。
                            if(stop_pending &&
                               cycle_tick == 0) begin
                                state <= FADE_OUT;
                                envelope_tick <= 1;
                            end
                        end

                        FADE_OUT: begin
                            if(envelope_tick >= SAFE_PERIOD) begin
                                state <= IDLE;
                                stop_pending <= 0;
                                envelope_tick <= 0;
                                cycle_tick <= 0;
                                arrived <= 1;

                                // 丢弃后续流水线结果，
                                // 最后精确保持运动中心。
                                valid_pipe <= 0;
                                target_q16 <= anchor_q16;
                                target_valid <= 1;
                            end
                            else
                                envelope_tick <=
                                    envelope_tick + 1'b1;
                        end

                        default: begin
                            state <= IDLE;
                            valid_pipe <= 0;
                        end
                    endcase
                end
            end
        end
    end

endmodule
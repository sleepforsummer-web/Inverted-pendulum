`timescale 1ns/1ps
module outer_integral_case #(parameter integer SHIFT=1, KI=65536)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst=1,enable=0,tick=0,clear_i=0;
 reg signed [32:0] error_q16=0;
 wire signed [16:0] error=error_q16>>>16;
 wire signed [16:0] target;
 wire valid;
 wire signed [31:0] im;
 position_controller #(.Kp_pos(0),.Kd_pos(0),.Ki_pos(KI),.D_FILTER_SHIFT(SHIFT),
  .USE_Q16_POSITION(1),.D_ON_MEASUREMENT(1)) dut(
  .clk(clk),.rst(rst),.enable(enable),.sample_tick(tick),.position_error(error),
  .position_error_q16(error_q16),.position_measurement(17'sd0),.integral_clear(clear_i),.motion_active(1'b0),
  .theta_ref(target),.theta_ref_valid(valid),.p_pos_mon(),.d_pos_mon(),.i_pos_mon(im),
  .limited_mon(),.active_limit_mon(),.boost_active_mon());
 integer write_n=0, read_n=0;
 integer expected[0:255];
 always @(posedge clk) begin
  #2;
  if(enable && valid) begin
   if(read_n>=write_n || target!==expected[read_n] || im!==expected[read_n]*256)
    $fatal(1,"I alignment shift=%0d Ki=%0d n=%0d target=%0d expected=%0d I=%0d",SHIFT,KI,read_n,target,expected[read_n],im);
   read_n=read_n+1;
  end
 end
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #3; end
 endtask
 task sample(input longint q16, input integer want, gap, input bit clear);
  @(negedge clk); error_q16=q16; tick=1; clear_i=clear;
  expected[write_n]=(KI==0) ? 0 : want; write_n=write_n+1; clocks(1);
  if(gap>0) begin @(negedge clk); tick=0; clocks(gap); end
 endtask
 task drain;
  @(negedge clk); tick=0; clocks(8);
  if(read_n!=write_n) $fatal(1,"missing I output");
 endtask
 initial begin
  clocks(3); @(negedge clk); rst=0; enable=1;
  sample(3*65536,3,6,0); sample(3*65536,6,0,0); sample(3*65536,8,0,0);
  sample(3*65536,8,0,0); sample(0,8,0,0); sample(-2*65536,6,0,0);
  sample(50*65536,0,0,0); sample(-3*65536,-3,0,0); sample(-3*65536,-6,0,0);
  sample(-3*65536,-8,0,0); sample(-50*65536,0,0,0);
  sample(16384,0,0,0); sample(-16384,0,0,0); // +/-0.25均不积累
  sample(32768,1,0,0); sample(-32768,0,0,0); // +/-0.5对称四舍五入
  sample(3*65536,3,0,0); sample(3*65536,0,0,1); // 运动时清零
  sample(3*65536,0,0,1); sample(3*65536,3,0,0); drain();
  @(negedge clk); enable=0; clocks(4);
  if(target || im || valid) $fatal(1,"disable retained integral");
  @(negedge clk); enable=1; sample(-1*65536,-1,6,0); drain();
  @(negedge clk); rst=1; clocks(4);
  if(target || im || valid) $fatal(1,"reset retained integral");
  done=1;
 end
endmodule
module tb_outer_integral;
 wire a,b,c;
 outer_integral_case #(.SHIFT(0)) direct_i(a);
 outer_integral_case #(.SHIFT(1)) filtered_i(b);
 outer_integral_case #(.SHIFT(1),.KI(0)) disabled_i(c);
 initial begin wait(a&&b&&c);
  $display("PASS outer integral: reused pid_i, signed accumulation, +/-8 clamp, separation, symmetric rounding, motion clear, pipeline pairing and Ki=0");
  $finish;
 end
 initial begin #1000000; $fatal(1,"timeout"); end
endmodule

"""从修改前备份迁移旧顶层回归的按键含义：手动KEY3->KEY2，主动停机KEY2->KEY1。"""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
backup=root.parent/'backups/before_sine_keys_20261025/sim'
for source in backup.glob('tb*.sv'):
    text=source.read_text(encoding='utf-8-sig')
    if 'pid_trial ' not in text:
        continue
    text=re.sub(r'\bpress\((1|2)\)',lambda m:'press('+{'1':'0','2':'1'}[m[1]]+')',text)
    text=re.sub(r"keys\s*=\s*4'b(1011|1101)",lambda m:"keys=4'b"+{'1011':'1101','1101':'1110'}[m[1]],text)
    # 仅三位按键向量使用这些十进制常量；KEY4四位向量用7表示按下，不改。
    if re.search(r'reg\s+\[2:0\]\s+keys',text):
        text=re.sub(r'keys\s*=\s*(2|3|5)(?=\s*;)',lambda m:'keys='+{'2':'4','3':'5','5':'6'}[m[1]],text)
    text=text.replace('stop_reason!=2','stop_reason!=1').replace('stop_reason!=4','stop_reason!=1')
    (root/source.name).write_text(text,encoding='utf-8')
print('Migrated top testbench key events; specialized behavior cases require explicit review.')

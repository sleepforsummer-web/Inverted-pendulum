`timescale 1ns/1ps
module motion_arrival_case #(parameter integer DISTANCE=1073, BOUND_SIGN=1)(output reg done=0);
 reg clk=0; always #10 clk=~clk;
 reg rst_n=0,tick=0;
 reg [3:0] keys=15;
 reg signed [16:0] pos=0;
 pid_trial #(.KEY_DEBOUNCE_CYCLES(4)) dut(
  .clk_50m(clk),.rst_n(rst_n),.adc_data_in(10'd0),.key_sw(keys),
  .enc_a(1'b0),.enc_b(1'b0),.adc_clk(),.adc_oe_n(),.uart_tx(),
  .PWMA(),.AN1(),.AN2(),.PWMB(),.BN1(),.BN2());
 defparam dut.motion.STEP_COUNTS=DISTANCE;
 defparam dut.motion.MOVE_TICKS=4;
 defparam dut.position_control.THETA_REF_BOOST_MAX=110;
 task clocks(input integer n);
  repeat(n) begin @(posedge clk); #2; end
 endtask
 task sample;
  @(negedge clk); tick=1; clocks(1);
  @(negedge clk); tick=0; clocks(8);
 endtask
 task press(input integer index);
  @(negedge clk); keys=15^(1<<index); clocks(12);
  @(negedge clk); keys=15; clocks(12);
 endtask
 integer n;
 initial begin
  force dut.position=pos; force dut.theta=13'sd0;
  force dut.filtered_raw=dut.UPRIGHT_ADC; force dut.adc_valid=1'b1;
  force dut.pos_tick=tick;
  clocks(3); @(negedge clk); rst_n=1; clocks(12); press(1); sample();
  press(3); sample();
  // 轨迹尚在运行，即使实际误差在当前目标附近，也不能提前退出运动限制。
  @(negedge clk); pos=dut.position_target_q16>>>16; sample();
  if(!dut.motion_limit_active || dut.outer_active_limit!=40) $fatal(1,"early passage released motion mode");
  @(negedge clk); pos=0; sample(); sample();
  if(dut.motion_busy || !dut.motion_limit_active || !dut.motion_arrival_wait)
   $fatal(1,"trajectory completion lost arrival wait");
  repeat(130) sample();
  if(!dut.motion_limit_active || dut.outer_active_limit!=40 || dut.outer_boost_active)
   $fatal(1,"waiting arrival timed out");
  @(negedge clk); pos=DISTANCE+BOUND_SIGN*(dut.MOTION_ARRIVE_COUNTS+1); sample();
  if(!dut.motion_limit_active) $fatal(1,"outside signed tolerance accepted");
  @(negedge clk); pos=DISTANCE+BOUND_SIGN*dut.MOTION_ARRIVE_COUNTS; clocks(5);
  if(!dut.motion_limit_active) $fatal(1,"arrival not synchronized to position sample");
  sample();
  if(dut.motion_limit_active || dut.motion_arrival_wait ||
     dut.outer_active_limit!=(dut.MOTION_ARRIVE_COUNTS>dut.OUTER_LIMIT_POSITION_COUNTS ? 110 : 40) ||
     dut.outer_boost_active!=(dut.MOTION_ARRIVE_COUNTS>dut.OUTER_LIMIT_POSITION_COUNTS))
   $fatal(1,"signed inclusive arrival failed");
  @(negedge clk); pos=DISTANCE+60; sample();
  if(dut.motion_limit_active || dut.outer_active_limit!=110 || !dut.outer_boost_active)
   $fatal(1,"disturbance after arrival re-entered motion mode");
  // 第二次运动重新建立到位等待；停机与复位均清除。
  press(3); repeat(4) sample();
  if(!dut.motion_arrival_wait) $fatal(1,"second motion did not re-arm arrival");
  press(0); clocks(5);
  if(dut.motion_limit_active || dut.motion_arrival_wait || dut.duty) $fatal(1,"stop retained arrival wait");
  @(negedge clk); pos=0; press(1); sample();
  if(dut.motion_arrival_wait) $fatal(1,"restart inherited arrival wait");
  // 恢复时装载新目标，不继承旧运动等待。
  force dut.recovery_load_target=1'b1;
  force dut.recovery_nearest_target=$signed({pos,16'b0});
  @(negedge clk); pos=DISTANCE>0 ? 65535 : -65536; clocks(3);
  release dut.recovery_load_target; release dut.recovery_nearest_target; clocks(3);
  press(3); sample();
  if(!dut.motion_range_rejected || dut.motion_arrival_wait || dut.motion_limit_active)
   $fatal(1,"rejected target left permanent arrival wait");
  @(negedge clk); rst_n=0; clocks(5);
  if(dut.motion_limit_active || dut.motion_arrival_wait) $fatal(1,"reset retained arrival wait");
  done=1;
 end
endmodule
module tb_motion_arrival_top;
 wire a,b;
 motion_arrival_case #(.DISTANCE(1073),.BOUND_SIGN(1)) positive_case(a);
 motion_arrival_case #(.DISTANCE(-1073),.BOUND_SIGN(-1)) negative_case(b);
 initial begin wait(a && b);
  $display("PASS actual arrival: +/-turns, +/-10 inclusive, +/-11 excluded, sampled release, no early/time release, one-shot, repeat, stop/reset/load/rejected-target clearing");
  $finish;
 end
 initial begin #5000000; $fatal(1,"timeout"); end
endmodule

"""生成可在 ModelSim GUI 中重新仿真并打开 Wave 的快捷方式。"""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
out = root / 'paper_waves'
cases = {
 '01_pid': ('tb_paper_pid', [
  ('clk','bin'), ('dut.tick','bin'), ('dut.pos_tick','bin'), ('position','signed'),
  ('theta','signed'), ('dut.theta_ref','signed'), ('dut.theta_ref_valid','bin'),
  ('dut.error','signed'), ('dut.pid_valid','bin'), ('dut.duty','signed')], 'ms'),
 '02_adc': ('tb_paper_io', [('clk','bin'),('adc_clk','bin'),('data','unsigned'),
  ('raw','unsigned'),('filtered','unsigned'),('theta','signed'),('adc_valid','bin')], 'us'),
 '03_pwm': ('tb_paper_io', [('clk','bin'),('valid','bin'),('command','signed'),
  ('duty','signed'),('pwm','bin'),('in1','bin'),('in2','bin')], 'us'),
 '04_swing': ('tb_swing_top', [('clk','bin'),('tick','bin'),('adc','unsigned'),
  ('dut.swing_state','unsigned'),('dut.swing_peak','bin'),('dut.swing_duty','signed'),
  ('dut.pid_enable','bin'),('dut.duty','signed')], 'us'),
 '05_recovery': ('tb_recovery_target', [('clk','bin'),('position','signed'),('theta','signed'),
  ('dut.running','bin'),('dut.recovery_waiting','bin'),('dut.recovery_anchor_pending','bin'),
  ('dut.recovery_saved_target','signed'),('dut.recovery_target_ready','bin'),
  ('dut.position_target_q16','signed'),('dut.control_enable','bin')], 'us'),
 '06_uart': ('tb_paper_uart', [('clk','bin'),('rx','bin'),('valid','bin'),
  ('seq','unsigned'),('goal','signed'),('speed','unsigned')], 'us'),
}

for name,(top,signals,units) in cases.items():
    commands = [
      'onerror {resume}',
      'if {![file exists work]} {vlib work}',
      'eval vlog [glob ../src/*.v]',
      f'vlog -sv {top}.sv',
      f'vsim -voptargs=+acc -onfinish stop work.{top}',
      'view wave',
    ]
    for path,radix in signals:
        commands.append(f'add wave -noupdate -color Green -radix {radix} sim:/{top}/'+path.replace('.','/'))
    commands += [f'configure wave -timelineunits {units}', 'update', 'run -all', 'wave zoom full']
    (out/(name+'.do')).write_text('\n'.join(commands)+'\n', encoding='ascii')
    cmd = ('@echo off\r\ncd /d "%~dp0..\\sim"\r\n'
           f'start "" "F:\\ModelSim_10.4\\win64\\vsim.exe" -do "../paper_waves/{name}.do"\r\n')
    (out/(name+'.cmd')).write_bytes(cmd.encode('ascii'))
print('Generated six ModelSim GUI waveform launchers')
